# WP06 single benchmark build -- corrected constraint handling
# argv: N PERIOD_NS TAG
set N [lindex $argv 0]
set PERIOD [lindex $argv 1]
set TAG [lindex $argv 2]

set script_dir [file dirname [file normalize [info script]]]
set root [file normalize "$script_dir/../.."]
set part "xc7a100tcsg324-1"
set top "wp04_impl_wrapper"

if {[current_project -quiet] ne ""} { catch {close_project} }

file mkdir "$root/vivado/projects"
file mkdir "$root/vivado/reports/${TAG}"
file mkdir "$root/vivado/generated_constraints"

set projdir "$root/vivado/projects/${TAG}"

# Generate a per-run XDC. This avoids calling create_clock before a design is open.
set xdcfile "$root/vivado/generated_constraints/${TAG}.xdc"
set xfh [open $xdcfile w]
puts $xfh "create_clock -name clk -period $PERIOD \[get_ports clk\]"
close $xfh

create_project -force wp06_bench "$projdir" -part $part

add_files [list \
  "$root/rtl/tridiagonal_decoder_wp03_frozen.sv" \
  "$root/rtl/wp04_encoder.sv" \
  "$root/rtl/wp04_top.sv" \
  "$root/rtl/wp04_impl_wrapper.sv"]

add_files -fileset constrs_1 $xdcfile
set_property top $top [current_fileset]

synth_design -top $top -part $part \
  -generic W=32 -generic FRAC=16 -generic N=$N \
  -directive PerformanceOptimized

report_utilization -file "$root/vivado/reports/${TAG}/post_synth_utilization.rpt"

opt_design
place_design
phys_opt_design
route_design

report_utilization -file "$root/vivado/reports/${TAG}/post_impl_utilization.rpt"
report_timing_summary -file "$root/vivado/reports/${TAG}/post_impl_timing.rpt"
report_power -file "$root/vivado/reports/${TAG}/post_impl_power.rpt"
report_clock_utilization -file "$root/vivado/reports/${TAG}/clock_utilization.rpt"
report_methodology -file "$root/vivado/reports/${TAG}/methodology.rpt"
write_checkpoint -force "$root/vivado/reports/${TAG}/routed.dcp"

set wns [get_property SLACK [get_timing_paths -setup -max_paths 1]]
set fmhz [expr {1000.0 / double($PERIOD)}]

set fh [open "$root/vivado/reports/${TAG}/acceptance.txt" w]
puts $fh "WP06_TAG=$TAG"
puts $fh "N=$N"
puts $fh "W=32"
puts $fh "FRAC=16"
puts $fh "PERIOD_NS=$PERIOD"
puts $fh "TARGET_FREQ_MHZ=$fmhz"
puts $fh "WNS_NS=$wns"

if {$wns >= 0.0} {
  puts $fh "TIMING_STATUS=PASS"
  puts "WP06_BENCH_PASS TAG=$TAG N=$N PERIOD_NS=$PERIOD FREQ_MHZ=$fmhz WNS=$wns"
} else {
  puts $fh "TIMING_STATUS=FAIL"
  puts "WP06_BENCH_FAIL TAG=$TAG N=$N PERIOD_NS=$PERIOD FREQ_MHZ=$fmhz WNS=$wns"
}
close $fh

puts "WP06_BENCH_COMPLETE TAG=$TAG"
