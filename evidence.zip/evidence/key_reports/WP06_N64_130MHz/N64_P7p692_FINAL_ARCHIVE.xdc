create_clock -name clk -period 7.692 [get_ports clk]
