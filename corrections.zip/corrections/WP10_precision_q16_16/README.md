# WP12 Precision-Summary Correction Overlay

This overlay does **not** replace or alter the original frozen archive. Preserve the original `WP12_FINAL_FROZEN.zip` unchanged with SHA-256:

`21cf97ae3ef8db104c9ab18ec37e0984fca506a72d75f241bcf5aff1fe66716b`

## Why this overlay exists

The original WP12 derived summary records the Q16.16 mean relative L2 error as `0.000950407667768426`. Rerunning the exact archived WP10 script (`frozen_packages/WP10_FINAL_FROZEN.zip/python/run_precision_ablation.py`) with its stated seed and 500 cases reproduces:

`0.009050407667768426`

The Q24.8 and Q20.12 means and all reported maxima reproduce. The manuscript therefore uses the rerun Q16.16 mean value.

## Corrected public-facing files

- `data/Table_7_Precision_Ablation.csv`
- `figures/Fig_4_Precision_Ablation.png`
- `WP10_RERUN_OUTPUT.json`

For a public GitHub/Zenodo release, either apply these corrected derived outputs and generate a new release manifest/hash, or publish this overlay alongside the immutable original frozen archive with an explicit correction notice.
