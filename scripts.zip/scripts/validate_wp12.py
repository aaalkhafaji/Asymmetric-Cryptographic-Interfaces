from pathlib import Path
import csv
ROOT=Path(__file__).resolve().parents[1]
req=["source_packages/WP01","source_packages/WP02","source_packages/WP03","source_packages/WP04","source_packages/WP05","source_packages/WP06","source_packages/WP09","source_packages/WP10","source_packages/WP11","data/Table_3_FPGA_Scaling.csv","data/Table_5_Controlled_Robustness.csv","data/Table_6_Interface_Ablation.csv","data/Table_7_Precision_Ablation.csv","data/Table_8_Masking_Ablation.csv","latex/sections/end_to_end_fpga_results.tex"]
for x in req:
    if not (ROOT/x).exists(): raise SystemExit("MISSING: "+x)
with (ROOT/"data/Table_5_Controlled_Robustness.csv").open(newline="",encoding="utf-8") as f: rob=list(csv.DictReader(f))
if len(rob)!=10 or any(x["status"]!="PASS" for x in rob): raise SystemExit("Robustness validation failed.")
with (ROOT/"data/Table_6_Interface_Ablation.csv").open(newline="",encoding="utf-8") as f: abl=list(csv.DictReader(f))
if sum(int(float(x["cases"])) for x in abl)!=400: raise SystemExit("Ablation case count != 400.")
print("WP12_VALIDATION_PASS")

# Q16.16 corrected precision check
with (ROOT/"data/Table_7_Precision_Ablation.csv").open(newline="",encoding="utf-8") as f: prec=list(csv.DictReader(f))
q16=next(x for x in prec if x["precision"]=="Q16.16")
if abs(float(q16["mean_rel_l2"])-0.009050407667768426)>1e-15: raise SystemExit("Q16.16 precision correction mismatch.")
