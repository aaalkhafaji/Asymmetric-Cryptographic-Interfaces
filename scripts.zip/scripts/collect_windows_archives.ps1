param([string]$Repository="C:\CWP12\WP12_ADNAN_LATEX_REPRODUCIBILITY_READY")
$ErrorActionPreference="Stop"
$repo=[IO.Path]::GetFullPath($Repository)
$map=@{
"WP06_N64_130MHz"="C:\CWP06\WP06_FPGA_Benchmarking_READY_FOR_VIVADO\WP12_ARCHIVE\WP06_N64_130MHz";
"WP05_100_GROUP_RAW_LOGS"="C:\CWP05\WP05_Large_Scale_Randomized_RTL_Verification_READY_FOR_VIVADO\WP12_ARCHIVE\WP05_100_GROUP_RAW_LOGS";
"WP09_ROBUSTNESS_RAW_LOGS"="C:\CWP09\WP09_Controlled_Robustness_READY_FOR_VIVADO\WP12_ARCHIVE\WP09_ROBUSTNESS_RAW_LOGS"}
foreach($k in $map.Keys){$src=$map[$k];$dst=Join-Path $repo ("archival_evidence\"+$k);if(-not(Test-Path $src)){throw "Missing $src"};New-Item -ItemType Directory -Force $dst|Out-Null;Copy-Item (Join-Path $src "*") $dst -Recurse -Force}
$wp05=(Get-ChildItem (Join-Path $repo "archival_evidence\WP05_100_GROUP_RAW_LOGS") -Directory | ? Name -like "xsim_wp05_FULL_N64_G*").Count
$wp09=(Get-ChildItem (Join-Path $repo "archival_evidence\WP09_ROBUSTNESS_RAW_LOGS") -Directory).Count
Write-Host "WP05_FULL_GROUP_DIRS=$wp05"; Write-Host "WP09_CONDITION_DIRS=$wp09"
if($wp05-ne100){throw "WP05 count !=100"}; if($wp09-ne10){throw "WP09 count !=10"}
Write-Host "WP12_ARCHIVAL_COLLECTION_PASS"
