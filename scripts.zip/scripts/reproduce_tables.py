from pathlib import Path
import csv
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/"data"; OUT=ROOT/"latex"/"tables"; OUT.mkdir(parents=True,exist_ok=True)
def rows(n):
    with (DATA/n).open(newline="",encoding="utf-8") as f: return list(csv.DictReader(f))
def w(n,t): (OUT/n).write_text(t.strip()+"\n",encoding="utf-8")

w("table_decoder.tex", r"""
\begin{table}[t]\centering
\caption{Global tridiagonal decoder verification and post-route implementation results.}
\label{tab:decoder_arch_c}
\begin{tabular}{lr}\toprule
Metric & Result\\\midrule
Randomized systems tested & 10,000\\
Failures & 0\\
Maximum RTL/reference mismatch & 0 LSB\\
Slice LUTs & 955\\
Flip-flops & 612\\
RAMB18 & 5\\
DSP48E1 & 4\\
Clock frequency & 100 MHz\\
WNS & +2.002 ns\\
Vivado estimated total power & 0.139 W\\
\bottomrule\end{tabular}\end{table}
""")

r=[x for x in rows("Table_3_FPGA_Scaling.csv") if abs(float(x["clock_mhz"])-100)<1e-9]
body="\n".join(f'{x["N"]} & {int(float(x["lut"])):,} & {int(float(x["lutram"])):,} & {int(float(x["ff"])):,} & {int(float(x["ramb18"]))} & {int(float(x["dsp"]))} & {float(x["wns_ns"]):+.3f} & {float(x["power_w"]):.3f}\\\\' for x in r)
w("table_fpga_scaling.tex", rf"""
\begin{{table*}}[t]\centering
\caption{{Post-route FPGA scaling of the complete digital transceiver at 100 MHz.}}
\label{{tab:fpga_scaling}}
\begin{{tabular}}{{rrrrrrrr}}\toprule
$N$ & LUT & LUTRAM & FF & RAMB18 & DSP48E1 & WNS (ns) & Est. Power (W)\\\midrule
{body}
\bottomrule\end{{tabular}}\end{{table*}}
""")

w("table_headline_fpga.tex", r"""
\begin{table}[t]\centering
\caption{Principal $N=64$ routed implementation at the validated 130.005 MHz operating point.}
\label{tab:headline_fpga}
\begin{tabular}{lr}\toprule
Metric & Result\\\midrule
FPGA & Artix-7 XC7A100T-CSG324-1\\
Arithmetic & signed Q16.16\\
Validated routed frequency & 130.005 MHz\\
WNS & +0.157 ns\\
LUTs & 3,614\\
LUTRAM & 132\\
Flip-flops & 6,079\\
RAMB18 & 5\\
DSP48E1 & 16\\
Vivado estimated total power & 0.159 W\\
Estimated dynamic power & 0.068 W\\
Estimated static power & 0.091 W\\
\bottomrule\end{tabular}\end{table}
""")

lat=[x for x in rows("Table_4_Latency_Throughput.csv") if abs(float(x["clock_mhz"])-100)<1e-9]
body="\n".join(f'{x["N"]} & {int(float(x["block_cycles"])):,} & {int(float(x["decoder_cycles"])):,} & {float(x["block_latency_us"]):.2f} & {float(x["decoder_latency_us"]):.2f}\\\\' for x in lat)
w("table_latency.tex", rf"""
\begin{{table}}[t]\centering
\caption{{Measured RTL block and decoder latency at 100 MHz.}}
\label{{tab:latency}}
\begin{{tabular}}{{rrrrr}}\toprule
$N$ & Block cycles & Decoder cycles & Block ($\mu$s) & Decoder ($\mu$s)\\\midrule
{body}
\bottomrule\end{{tabular}}\end{{table}}
""")

rob=rows("Table_5_Controlled_Robustness.csv")
body="\n".join(f'{x["condition"].replace("_"," ")} & {x["N"]} & {int(float(x["word_checks"])):,} & {x["status"]}\\\\' for x in rob)
w("table_robustness.tex", rf"""
\begin{{table}}[t]\centering
\caption{{Controlled digital, numerical, and RTL robustness campaign.}}
\label{{tab:robustness}}
\begin{{tabular}}{{lrrl}}\toprule
Condition & $N$ & Word checks & Result\\\midrule
{body}
\bottomrule\end{{tabular}}\end{{table}}
""")

abl=rows("Table_6_Interface_Ablation.csv")
body="\n".join(f'{x["contrast"]} & {int(float(x["cases"]))} & {float(x["interface_aware_mean_rel_l2"]):.3e} & {float(x["ordinary_mean_rel_l2"]):.4f} & {float(x["ordinary_max_rel_l2"]):.4f}\\\\' for x in abl)
w("table_interface_ablation.tex", rf"""
\begin{{table*}}[t]\centering
\caption{{Interface-aware versus ordinary-stencil reconstruction ablation for $N=64$.}}
\label{{tab:interface_ablation}}
\begin{{tabular}}{{lrrrr}}\toprule
Contrast & Cases & Interface-aware mean rel. $L_2$ & Ordinary mean rel. $L_2$ & Ordinary max rel. $L_2$\\\midrule
{body}
\bottomrule\end{{tabular}}\end{{table*}}
""")

prec=rows("Table_7_Precision_Ablation.csv")
body="\n".join(f'{x["precision"]} & {int(float(x["cases"]))} & {float(x["mean_rel_l2"]):.4g} & {float(x["max_rel_l2"]):.4g}\\\\' for x in prec)
w("table_precision.tex", rf"""
\begin{{table}}[t]\centering
\caption{{Fixed-point precision sensitivity.}}
\label{{tab:precision_ablation}}
\begin{{tabular}}{{lrrr}}\toprule
Format & Cases & Mean rel. $L_2$ & Max rel. $L_2$\\\midrule
{body}
\bottomrule\end{{tabular}}\end{{table}}
""")

w("table_masking.tex", r"""
\begin{table}[t]\centering
\caption{Modular masking/unmasking functional validation.}
\label{tab:masking}
\begin{tabular}{lr}\toprule
Metric & Result\\\midrule
Blocks & 2,000\\
32-bit words & 128,000\\
Exact mask/unmask recoveries & 128,000/128,000\\
Masked words differing from inputs & 128,000/128,000\\
Exact recovery fraction & 1.0\\
Changed-word fraction & 1.0\\
\bottomrule\end{tabular}\end{table}
""")

w("table_claim_evidence.tex", r"""
\begin{table*}[t]\centering
\caption{Final claim--evidence separation after the completed validation campaign.}
\label{tab:claim_evidence}
\begin{tabular}{p{0.28\textwidth}p{0.64\textwidth}}\toprule
Claim & Final evidence/status\\\midrule
Global operator invertibility & Theoretical SPD/M-matrix and pivot-margin results.\\
Raw finite-noise leakage & Analytic leakage theorem plus Monte Carlo model validation.\\
Perfect/$\epsilon$ secrecy & Conditional theorem requiring validated conditional min-entropy and fresh-pad nonreuse.\\
Physical entropy quality & Not established in the present campaign; WP07/WP08 were not performed.\\
Controlled extractor behavior & Synthetic/controlled privacy-amplification validation only.\\
Forward interface transform RTL & Implemented and verified.\\
Modular mask/unmask RTL & Implemented and end-to-end verified.\\
Global tridiagonal decryptor RTL & Implemented; 10,000/10,000 randomized systems passed.\\
Complete digital transceiver & Implemented; 204,800 exact RTL/reference word checks with zero failures.\\
FPGA timing/resource feasibility & Post-route Artix-7 implementation and explicit frequency characterization.\\
Controlled digital robustness & 10/10 conditions passed; 8,960 exact checks.\\
Physical/environmental robustness & Not tested.\\
Active/side-channel security & Not claimed; requires authenticated composition and implementation-specific evaluation.\\
\bottomrule\end{tabular}\end{table*}
""")
print("REPRODUCE_TABLES_PASS")
