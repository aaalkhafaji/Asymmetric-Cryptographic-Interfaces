from pathlib import Path
import csv, hashlib, json, sys
ROOT=Path(__file__).resolve().parents[1]

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

# Correction value must be the independently reproducible value.
with (ROOT/'data/Table_7_Precision_Ablation.csv').open(newline='',encoding='utf-8') as f:
    rows=list(csv.DictReader(f))
q=next(r for r in rows if r['precision']=='Q16.16')
if abs(float(q['mean_rel_l2'])-0.009050407667768426)>1e-15:
    raise SystemExit('Q16.16 corrected mean mismatch')

# Original provenance hash must be recorded exactly.
prov=(ROOT/'provenance/ORIGINAL_WP12_ARCHIVE_SHA256.txt').read_text().split()[0]
if prov!='21cf97ae3ef8db104c9ab18ec37e0984fca506a72d75f241bcf5aff1fe66716b': raise SystemExit('Original WP12 provenance hash mismatch')

# Full release evidence checks when raw evidence is present.
arch=ROOT/'archival_evidence'
if arch.exists():
    wp05=arch/'WP05_100_GROUP_RAW_LOGS'
    groups=[p for p in wp05.iterdir() if p.is_dir() and p.name.startswith('xsim_wp05_FULL_N64_G')] if wp05.exists() else []
    if len(groups)!=100: raise SystemExit(f'Expected 100 WP05 raw groups, found {len(groups)}')
    wp09=arch/'WP09_ROBUSTNESS_RAW_LOGS'
    dirs=[p for p in wp09.iterdir() if p.is_dir()] if wp09.exists() else []
    if len(dirs)!=10: raise SystemExit(f'Expected 10 WP09 raw directories, found {len(dirs)}')
    for n in ['post_impl_timing.rpt','post_impl_utilization.rpt','post_impl_power.rpt','methodology.rpt']:
        if not (arch/'WP06_N64_130MHz'/n).exists(): raise SystemExit('Missing WP06 evidence: '+n)

# Verify release manifest (manifest intentionally excludes itself and FILE_INVENTORY.tsv).
man=ROOT/'manifest/SHA256SUMS.txt'
if man.exists():
    for line in man.read_text(encoding='utf-8-sig').splitlines():
        if not line.strip(): continue
        digest,rel=line.split(None,1); rel=rel.strip()
        p=ROOT/rel
        if not p.exists(): raise SystemExit('Manifest missing file: '+rel)
        if sha(p)!=digest: raise SystemExit('Manifest hash mismatch: '+rel)
print('PUBLIC_RELEASE_VERIFY_PASS')
