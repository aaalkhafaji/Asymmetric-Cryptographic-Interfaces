from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
for s in ["reproduce_tables.py","reproduce_figures.py","validate_wp12.py"]:
    subprocess.run([sys.executable,str(ROOT/"scripts"/s)],check=True)
print("WP12_REPRODUCE_ALL_PASS")
