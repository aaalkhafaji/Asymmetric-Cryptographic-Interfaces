# WP10 Final Results — Frozen

## 1. Interface-aware vs ordinary-stencil ablation
- N = 64
- Cases = 400
- Interface-aware mean relative L2 error = **8.576e-15**
- Ordinary-stencil mean relative L2 error = **0.21146**
- Ordinary/interface-aware error ratio = **2.466e13**

By contrast:
- none: ordinary mean rel. L2 = **0.01504**
- low: ordinary mean rel. L2 = **0.08103**
- medium: ordinary mean rel. L2 = **0.30293**
- high: ordinary mean rel. L2 = **0.44682**

The interface-aware formulation stayed near numerical precision throughout the 400-case campaign.

## 2. Precision ablation
500 cases per tested precision:
- Q24.8: mean rel. L2 = **9.9200**, max = **1282.806**
- Q20.12: mean rel. L2 = **0.14681**, max = **0.74231**
- Q16.16: mean rel. L2 = **9.050e-3**, max = **0.05207**

## 3. Masking ablation
- Blocks = **2,000**
- Words = **128,000**
- Exact mask→unmask recovery = **128,000 / 128,000**
- Masked words differing from unmasked words = **128,000 / 128,000**
- Exact recovery fraction = **1.0**
- Changed fraction = **1.0**
- Status = **PASS**

## 4. Hardware baseline context
- Decoder-only Architecture C: 955 LUTs, 612 FFs, 5 RAMB18, 4 DSP48E1
- Full N=16 @ 100 MHz: 2,478 LUTs, 2,749 FFs
- Full N=32 @ 100 MHz: 2,813 LUTs, 3,788 FFs
- Full N=64 @ 100 MHz: 3,536 LUTs, 5,861 FFs
- Full N=64 @ 130.005 MHz: 3,614 LUTs, 6,079 FFs, WNS +0.157 ns

**WP10 = COMPLETE / ABLATIONS AND BASELINES VERIFIED / FROZEN**
