#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, csv
from pathlib import Path
import numpy as np


def interface_tau(beta_minus: float, beta_plus: float, theta: float) -> float:
    if beta_minus <= 0 or beta_plus <= 0:
        raise ValueError("permeabilities must be positive")
    if not (0.0 < theta < 1.0):
        raise ValueError("use 0 < theta < 1 for a subcell interface")
    return 1.0 / (theta / beta_minus + (1.0-theta) / beta_plus)


def edge_weights_from_regions(n: int, region_betas, interfaces):
    """Return N+1 normalized edge transmissibilities.

    interfaces: sorted iterable of (edge_k, theta), meaning gamma lies inside
    [x_k,x_{k+1}] at x_k+theta*h. There must be len(region_betas)-1 interfaces.
    For WP01/WP03 v2, at most one interface per edge.
    """
    region_betas=np.asarray(region_betas,dtype=float)
    if n < 2 or len(region_betas) < 1 or np.any(region_betas <= 0):
        raise ValueError("invalid n/region_betas")
    inter=sorted([(int(k),float(t)) for k,t in interfaces], key=lambda z:z[0]+z[1])
    if len(inter) != len(region_betas)-1:
        raise ValueError("need exactly len(region_betas)-1 interfaces")
    if len({k for k,_ in inter}) != len(inter):
        raise ValueError("v2 validation allows at most one interface per edge")
    for k,t in inter:
        if not (0 <= k <= n) or not (0.0 < t < 1.0):
            raise ValueError("interface outside grid or theta not in (0,1)")
    pos=[k+t for k,t in inter]
    if any(pos[i] >= pos[i+1] for i in range(len(pos)-1)):
        raise ValueError("interfaces must be strictly ordered")

    w=np.empty(n+1,float)
    by_edge={k:(idx,t) for idx,(k,t) in enumerate(inter)}
    for k in range(n+1):
        if k in by_edge:
            idx,t=by_edge[k]
            w[k]=interface_tau(region_betas[idx],region_betas[idx+1],t)
        else:
            midpoint=k+0.5
            ridx=sum(p < midpoint for p in pos)
            w[k]=region_betas[ridx]
    return w


def assemble_A_from_edges(w):
    """Assemble A=h^2 B for N interior unknowns from N+1 positive edge weights."""
    w=np.asarray(w,dtype=float)
    if len(w)<2 or np.any(w<=0): raise ValueError("edge weights must be positive")
    n=len(w)-1
    A=np.zeros((n,n),float)
    for j in range(n):
        A[j,j]=w[j]+w[j+1]
        if j>0: A[j,j-1]=-w[j]
        if j<n-1: A[j,j+1]=-w[j+1]
    return A


def build_operator(n:int, region_betas=(2.0,1.0), interfaces=None, h:float=1.0, normalized:bool=True):
    if interfaces is None: interfaces=[(n//2,0.35)]
    w=edge_weights_from_regions(n,region_betas,interfaces)
    A=assemble_A_from_edges(w)
    return (A if normalized else A/h**2), w


def thomas(a,b,c,d, pivot_tol=0.0):
    a=np.asarray(a,float).copy(); b=np.asarray(b,float).copy(); c=np.asarray(c,float).copy(); d=np.asarray(d,float).copy()
    n=len(b); pivots=np.empty(n,float); pivots[0]=b[0]
    if pivots[0] <= pivot_tol: raise ArithmeticError(f"pivot 0 <= tolerance: {pivots[0]}")
    for i in range(1,n):
        m=a[i-1]/b[i-1]
        b[i]-=m*c[i-1]; d[i]-=m*d[i-1]; pivots[i]=b[i]
        if pivots[i] <= pivot_tol: raise ArithmeticError(f"pivot {i} <= tolerance: {pivots[i]}")
    x=np.empty(n,float); x[-1]=d[-1]/b[-1]
    for i in range(n-2,-1,-1): x[i]=(d[i]-c[i]*x[i+1])/b[i]
    return x,pivots


def tridiagonals(A): return np.diag(A,-1),np.diag(A),np.diag(A,1)


def quantize_to_words(x,q=32,frac=16):
    scale=1<<frac; mod=1<<q
    z=np.rint(np.asarray(x)*scale).astype(np.int64)
    if np.max(np.abs(z)) >= (1<<(q-1)): raise OverflowError('increase q or reduce scale')
    return np.mod(z,mod).astype(np.uint64), scale


def words_to_signed(words,q,scale):
    w=np.asarray(words,dtype=np.uint64); mod=1<<q; half=1<<(q-1)
    z=w.astype(np.int64); z=np.where(z>=half,z-mod,z)
    return z.astype(float)/scale


def mask(words,key,q): return (np.asarray(words,dtype=np.uint64)+np.asarray(key,dtype=np.uint64)) % (1<<q)
def unmask(cipher,key,q): return (np.asarray(cipher,dtype=np.uint64)-np.asarray(key,dtype=np.uint64)) % (1<<q)


def run(seed=20260904,n=128,q=32,frac=16):
    rng=np.random.default_rng(seed)
    # Current paper-type example: two distinct interior interfaces / three positive regions.
    interfaces=[(n//3,0.42),(2*n//3,0.63)]
    A,w=build_operator(n, region_betas=(1.7,0.8,1.25), interfaces=interfaces, normalized=True)
    P=rng.normal(0,.05,n); S=A@P
    X,scale=quantize_to_words(S,q,frac); K=rng.integers(0,1<<q,size=n,dtype=np.uint64)
    Y=mask(X,K,q); X2=unmask(Y,K,q)
    S2=words_to_signed(X2,q,scale); a,b,c=tridiagonals(A)
    P2,piv=thomas(a,b,c,S2)
    return A,w,P,S,X,K,Y,P2,piv


def self_test(out:Path):
    out.mkdir(parents=True,exist_ok=True)
    A,w,P,S,X,K,Y,P2,piv=run(); a,b,c=tridiagonals(A)
    direct=np.linalg.solve(A,S)
    x_exact,piv_exact=thomas(a,b,c,S)
    assert np.allclose(A,A.T,atol=0,rtol=0)
    assert np.min(np.linalg.eigvalsh(A)) > 0
    assert np.max(np.abs(x_exact-direct)) < 1e-10
    assert np.array_equal(unmask(Y,K,32),X)
    assert np.min(piv_exact) > np.min(w) - 1e-12
    err=float(np.max(np.abs(P-P2)))
    np.savetxt(out/'golden_vector_v2.csv',np.c_[P,S,X,K,Y,P2],delimiter=',',header='P,S,X,K,Y,P_recovered',comments='')
    np.savetxt(out/'matrix_A_v2.csv',A,delimiter=',')
    np.savetxt(out/'edge_weights_v2.csv',w,delimiter=',')
    summary={'version':'2.0','n':len(P),'interfaces':2,'min_edge_weight':float(np.min(w)),
             'min_thomas_pivot_exact':float(np.min(piv_exact)),
             'max_float_solver_error':float(np.max(np.abs(direct-P))),
             'max_fixed_point_reconstruction_error':err,
             'condition_number_2':float(np.linalg.cond(A)),
             'matrix_symmetric':bool(np.allclose(A,A.T)),
             'matrix_spd':bool(np.min(np.linalg.eigvalsh(A))>0)}
    (out/'summary_v2.json').write_text(json.dumps(summary,indent=2))
    for name in ['golden_vector_v2.csv','matrix_A_v2.csv','edge_weights_v2.csv','summary_v2.json']:
        sha=hashlib.sha256((out/name).read_bytes()).hexdigest()
        with (out/'SHA256SUMS_v2.txt').open('a') as f: f.write(f'{sha}  {name}\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--self-test',action='store_true'); ap.add_argument('--out',default='results/validated_v2'); args=ap.parse_args()
    if args.self_test: self_test(Path(args.out))
