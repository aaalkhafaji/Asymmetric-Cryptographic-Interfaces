#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'reference_snapshots'))
import wp01_reference_pipeline_frozen as wp01

def qround(x,frac): return np.rint(np.asarray(x)*(1<<frac))/(1<<frac)
def run(cases,seed,out):
    rng=np.random.default_rng(seed); res={}
    for frac in (8,12,16):
        errs=[]
        for k in range(cases):
            n=64
            betas=tuple(rng.uniform(0.6,1.9,3))
            j1,j2=n//3,2*n//3
            A,_=wp01.build_operator(n,region_betas=betas,
                                    interfaces=[(j1,float(rng.uniform(.25,.8))),(j2,float(rng.uniform(.25,.8)))],
                                    normalized=True)
            p=rng.normal(0,.02,n)
            Aq=qround(A,frac); pq=qround(p,frac); d=qround(Aq@pq,frac)
            try: x=np.linalg.solve(Aq,d)
            except np.linalg.LinAlgError: errs.append(float("inf")); continue
            errs.append(float(np.linalg.norm(p-x)/(np.linalg.norm(p)+1e-30)))
        res[f"Q{32-frac}.{frac}"]={"cases":cases,"mean_rel_l2":float(np.mean(errs)),"max_rel_l2":float(np.max(errs))}
    Path(out).parent.mkdir(parents=True,exist_ok=True)
    Path(out).write_text(json.dumps(res,indent=2))
    print(json.dumps(res,indent=2)); print("WP10_PRECISION_ABLATION_COMPLETE")
if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--cases",type=int,default=200); ap.add_argument("--seed",type=int,default=20260910); ap.add_argument("--out",default="results/precision_ablation.json"); a=ap.parse_args(); run(a.cases,a.seed,a.out)
