#!/usr/bin/env python3
from pathlib import Path
import argparse,json,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'reference_snapshots'))
import wp01_reference_pipeline_frozen as wp01
def main(blocks,seed,out):
    rng=np.random.default_rng(seed); words=0; exact=0; changed=0
    for _ in range(blocks):
        n=64; x=rng.integers(0,2**32,n,dtype=np.uint64); k=rng.integers(0,2**32,n,dtype=np.uint64)
        c=wp01.mask(x,k,32); r=wp01.unmask(c,k,32)
        exact += int(np.sum(r==x)); changed += int(np.sum(c!=x)); words += n
    d={"blocks":blocks,"words":words,"mask_unmask_exact_words":exact,"cipher_words_different_from_unmasked":changed,
       "exact_fraction":exact/words,"changed_fraction":changed/words,
       "interpretation":"Functional transparency only; not an entropy or security-strength claim."}
    Path(out).parent.mkdir(parents=True,exist_ok=True);Path(out).write_text(json.dumps(d,indent=2))
    print(json.dumps(d,indent=2));print("WP10_MASKING_ABLATION_PASS" if exact==words else "WP10_MASKING_ABLATION_FAIL")
if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("--blocks",type=int,default=1000);ap.add_argument("--seed",type=int,default=20260910);ap.add_argument("--out",default="results/masking_ablation.json");a=ap.parse_args();main(a.blocks,a.seed,a.out)
