#!/usr/bin/env python3
import subprocess,sys
cmds=[
 [sys.executable,"python/run_interface_ablation.py","--cases","400","--out","results/interface_full"],
 [sys.executable,"python/run_precision_ablation.py","--cases","500","--out","results/precision_ablation.json"],
 [sys.executable,"python/run_masking_ablation.py","--blocks","2000","--out","results/masking_ablation.json"],
 [sys.executable,"python/compile_hardware_baselines.py"],
]
for c in cmds:
    print("RUN:", " ".join(c)); subprocess.run(c,check=True)
print("WP10_FULL_COMPUTATIONAL_CAMPAIGN_COMPLETE")
