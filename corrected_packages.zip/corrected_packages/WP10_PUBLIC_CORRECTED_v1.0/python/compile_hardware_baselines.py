#!/usr/bin/env python3
from pathlib import Path
import json,csv
ROOT=Path(__file__).resolve().parents[1]
d=json.loads((ROOT/'results/frozen_context.json').read_text())
rows=[
 {"configuration":"WP03 decoder-only Architecture C, Nmax=128","lut":955,"ff":612,"ramb18":5,"dsp":4,"clock_mhz":100.0,"wns_ns":2.002,"power_w":0.139,"scope":"decoder only"},
 {"configuration":"WP06 full end-to-end N=16","lut":2478,"ff":2749,"ramb18":5,"dsp":16,"clock_mhz":100.0,"wns_ns":1.445,"power_w":0.133,"scope":"complete RTL"},
 {"configuration":"WP06 full end-to-end N=32","lut":2813,"ff":3788,"ramb18":5,"dsp":16,"clock_mhz":100.0,"wns_ns":1.520,"power_w":0.133,"scope":"complete RTL"},
 {"configuration":"WP06 full end-to-end N=64","lut":3536,"ff":5861,"ramb18":5,"dsp":16,"clock_mhz":100.0,"wns_ns":1.228,"power_w":0.147,"scope":"complete RTL"},
 {"configuration":"WP06 full end-to-end N=64 validated high clock","lut":3614,"ff":6079,"ramb18":5,"dsp":16,"clock_mhz":130.005,"wns_ns":0.157,"power_w":0.159,"scope":"complete RTL"},
]
with (ROOT/'results/hardware_baselines.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
(ROOT/'results/hardware_baselines.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows,indent=2));print("WP10_HARDWARE_BASELINES_COMPLETE")
