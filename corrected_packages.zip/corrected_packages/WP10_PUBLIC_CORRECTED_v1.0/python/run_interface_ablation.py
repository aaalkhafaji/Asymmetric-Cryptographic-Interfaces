#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, csv, sys
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'reference_snapshots'))
import wp01_reference_pipeline_frozen as wp01

def ordinary_operator(n, beta_eff):
    # Baseline: homogeneous ordinary tridiagonal stencil with no interface correction.
    # A homogeneous model has one region, hence zero interfaces.
    return wp01.build_operator(n, region_betas=(beta_eff,),
                               interfaces=[], normalized=True)[0]

def rel_l2(x,y):
    den=np.linalg.norm(x)
    return float(np.linalg.norm(x-y)/(den if den>0 else 1.0))

def run(cases, seed, outdir, n=64):
    rng=np.random.default_rng(seed)
    rows=[]
    contrast_levels=[
        ("none",(1.0,1.0,1.0),(0.50,0.50)),
        ("low",(0.90,1.00,1.10),(0.45,0.60)),
        ("medium",(0.70,1.20,1.55),(0.35,0.70)),
        ("high",(0.55,1.30,1.95),(0.25,0.80)),
    ]
    for k in range(cases):
        label,betas,thetas=contrast_levels[k%len(contrast_levels)]
        # jitter within condition so this is not a repeated deterministic case
        bj=np.array(betas,dtype=float)*rng.uniform(0.97,1.03,3)
        th=np.clip(np.array(thetas)+rng.normal(0,0.015,2),0.15,0.85)
        if k%7==5:
            j1,j2=1,n-2
            placement="boundary"
        elif k%7==6:
            j1,j2=n//2-1,n//2
            placement="close"
        else:
            j1=int(rng.integers(2,max(3,n//2-2)))
            j2=int(rng.integers(max(j1+2,n//2),n-2))
            placement="interior"

        A,_=wp01.build_operator(n,region_betas=tuple(float(v) for v in bj),
                                interfaces=[(j1,float(th[0])),(j2,float(th[1]))],
                                normalized=True)
        p=rng.normal(0.0,0.02,n)
        d=A@p

        # Correct/interface-aware decode
        p_if=np.linalg.solve(A,d)

        # Ordinary-stencil ablation: ignores interface locations and jump factors.
        beta_eff=float(np.mean(bj))
        A0=ordinary_operator(n,beta_eff)
        p_ord=np.linalg.solve(A0,d)

        rows.append({
            "case":k,"contrast":label,"placement":placement,
            "beta_min":float(np.min(bj)),"beta_max":float(np.max(bj)),
            "interface_aware_rel_l2":rel_l2(p,p_if),
            "ordinary_rel_l2":rel_l2(p,p_ord),
            "interface_aware_max_abs":float(np.max(np.abs(p-p_if))),
            "ordinary_max_abs":float(np.max(np.abs(p-p_ord))),
        })

    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    with (outdir/"interface_ablation_cases.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)

    summary={}
    for label in ["none","low","medium","high"]:
        rr=[r for r in rows if r["contrast"]==label]
        summary[label]={
            "cases":len(rr),
            "interface_aware_mean_rel_l2":float(np.mean([r["interface_aware_rel_l2"] for r in rr])),
            "ordinary_mean_rel_l2":float(np.mean([r["ordinary_rel_l2"] for r in rr])),
            "ordinary_median_rel_l2":float(np.median([r["ordinary_rel_l2"] for r in rr])),
            "ordinary_max_rel_l2":float(np.max([r["ordinary_rel_l2"] for r in rr])),
        }
    all_if=np.array([r["interface_aware_rel_l2"] for r in rows])
    all_ord=np.array([r["ordinary_rel_l2"] for r in rows])
    overall={
        "N":n,"cases":cases,"seed":seed,
        "interface_aware_mean_rel_l2":float(all_if.mean()),
        "ordinary_mean_rel_l2":float(all_ord.mean()),
        "ordinary_vs_interface_error_ratio":float(all_ord.mean()/max(all_if.mean(),1e-30)),
        "conditions":summary,
        "interpretation":"Ordinary stencil is a deliberately interface-unaware baseline; it is not cryptographic security evidence."
    }
    (outdir/"interface_ablation_summary.json").write_text(json.dumps(overall,indent=2))
    print(json.dumps(overall,indent=2))
    print("WP10_INTERFACE_ABLATION_PASS")

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--cases",type=int,default=40)
    ap.add_argument("--seed",type=int,default=20260910)
    ap.add_argument("--out",default="results/interface_smoke")
    args=ap.parse_args()
    run(args.cases,args.seed,args.out)
