# WP10 FINAL FROZEN — Ablations and Baselines

Headline results:
- 400-case interface ablation: PASS
- Interface-aware mean relative L2 error: 8.576e-15
- Ordinary-stencil mean relative L2 error: 0.21146
- 500-case precision study completed for Q24.8, Q20.12, Q16.16
- 128,000/128,000 exact mask/unmask recoveries
- 128,000/128,000 masked words differed from the unmasked words
- Frozen hardware baseline context included

Do not edit this archive; use a copy for later experiments.
