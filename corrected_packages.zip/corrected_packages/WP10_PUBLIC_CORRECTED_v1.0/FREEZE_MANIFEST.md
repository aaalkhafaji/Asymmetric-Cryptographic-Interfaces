# WP10 Freeze Manifest

Work package: WP10 — Ablations and Baselines
Status: PASS / FROZEN

Frozen evidence:
- 400-case interface-aware vs ordinary-stencil comparison
- 500-case-per-format precision sensitivity comparison
- 2,000-block / 128,000-word masking experiment
- frozen hardware baseline context from WP03 and WP06

Key results:
- interface-aware mean rel. L2 = 8.576e-15
- ordinary-stencil mean rel. L2 = 0.21146
- Q16.16 mean rel. L2 = 9.050e-3
- mask/unmask exact words = 128,000 / 128,000
- changed masked words = 128,000 / 128,000
