# WP10 Scientific Notes

1. The ordinary stencil is an interface-unaware ablation baseline, not a competing cryptosystem.
2. The precision study compares numerical behavior at Q24.8, Q20.12, and Q16.16.
3. The masking test establishes exact reversibility and altered masked representation across the tested words.
4. External Ascon hardware comparison is not included in the frozen WP10 result.
5. WP07/WP08 remain outside project scope.
