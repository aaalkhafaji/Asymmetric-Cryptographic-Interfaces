# Manuscript-Ready WP10 Text

Ablation experiments were used to isolate the effect of the interface-aware formulation and the selected numerical precision. In a 400-case N=64 comparison, the interface-aware operator achieved a mean relative L2 reconstruction error of 8.58e-15, while an ordinary interface-unaware stencil yielded a mean relative L2 error of 0.211. The ordinary-stencil error increased with interface contrast, from 0.015 under the weakest condition to 0.447 under the highest-contrast condition, whereas the interface-aware formulation remained near numerical precision throughout.

A 500-case precision sensitivity study showed a strong dependence on fractional resolution. The mean relative L2 error was 9.92 for Q24.8, 0.1468 for Q20.12, and 9.05e-3 for Q16.16, supporting the Q16.16 format adopted in the final implementation.

The masking stage was also evaluated over 2,000 blocks comprising 128,000 32-bit words. All 128,000 words were recovered exactly after the mask/unmask sequence, and every masked word differed from its corresponding unmasked word in the tested campaign.

Together with the previously frozen FPGA baselines, these ablations demonstrate the contribution of the interface-aware formulation, the importance of the chosen numerical precision, and the exact functional reversibility of the masking path.
