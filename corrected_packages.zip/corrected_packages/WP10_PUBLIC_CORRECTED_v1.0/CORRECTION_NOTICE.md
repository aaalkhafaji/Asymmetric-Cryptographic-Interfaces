# Q16.16 precision correction

This public package is derived from the immutable `WP10_FINAL_FROZEN.zip` retained in `frozen_packages/`.
The original frozen summary transcribed the Q16.16 500-case mean relative L2 error as approximately `9.50e-4`.
Re-running the frozen script `python/run_precision_ablation.py` with `--cases 500 --seed 20260910` reproduces:

`0.00905040766776842552`

The maximum Q16.16 relative L2 error remains `0.05207473149848442`. The Q24.8 and Q20.12 rows reproduce unchanged.
Only derived summaries/tables/figures are corrected; the original frozen package remains unmodified for provenance.
