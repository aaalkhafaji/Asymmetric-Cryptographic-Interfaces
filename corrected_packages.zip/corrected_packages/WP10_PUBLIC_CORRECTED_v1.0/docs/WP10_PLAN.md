# WP10 — Ablations and Baselines

Scope is deliberately limited to comparisons supported by the frozen evidence.

## Primary ablations
1. **Interface-aware operator vs ordinary interface-unaware stencil**
   - same generated interface data
   - compare reconstruction relative L2 error
   - contrast levels: none, low, medium, high
   - includes boundary and closely spaced interfaces

2. **Fixed-point precision sensitivity (software-only)**
   - 32-bit arithmetic representation with 8, 12, or 16 fractional bits
   - numerical sensitivity only; no claim that lower-precision variants were synthesized in RTL

3. **Masking functional transparency**
   - mask/unmask exactness over randomized 32-bit words
   - report how often masked words differ from unmasked structural words
   - no entropy/security-strength claim

## Frozen engineering baselines
- WP03 decoder-only Architecture C
- WP06 complete N=16/32/64 end-to-end configurations
- N=64 at validated 130 MHz
- WP05 exact RTL/reference equivalence
- WP09 controlled robustness

## Explicitly omitted
- physical entropy/extractor-length ablations requiring WP07/WP08
- environmental sensor baselines
- claims of replacing standardized AEAD
- unverified external Ascon hardware comparison unless a matched source/device/flow is later added
