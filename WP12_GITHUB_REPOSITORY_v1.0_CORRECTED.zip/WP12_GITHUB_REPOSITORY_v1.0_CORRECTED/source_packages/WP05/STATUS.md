# WP05 Status
- Package generated: YES
- Frozen WP04 RTL included: YES
- Frozen WP01/WP02 reference snapshots included: YES
- Smoke vectors generated: YES
- Smoke XSim: PENDING USER RUN
- Full randomized campaign: PENDING
- WP05 frozen: NO
