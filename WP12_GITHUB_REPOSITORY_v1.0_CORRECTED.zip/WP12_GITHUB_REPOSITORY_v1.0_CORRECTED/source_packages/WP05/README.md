# WP05 — Large-Scale Randomized RTL Verification

This package verifies the frozen WP04 end-to-end RTL against independent Python golden vectors.

## FIRST RUN — smoke only
Extract to a short path, e.g.
`C:\CWP05\WP05_Large_Scale_Randomized_RTL_Verification_READY_FOR_VIVADO`

In Vivado Tcl:
```
cd {C:/CWP05/WP05_Large_Scale_Randomized_RTL_Verification_READY_FOR_VIVADO}
source vivado/scripts/run_wp05_smoke.tcl
```

Expected end:
```
WP05_PAD_REUSE_NEGATIVE_PASS
WP05_SUMMARY N=64 CASES=16 TX_MATCH=1024 RX_MATCH=1024 WORD_CHECKS=2048 FAILURES=0
WP05_PASS
```

Do not start the full 100-group campaign until the smoke group passes.

## FULL N=64 campaign (after smoke)
Generate vectors:
```
python python/generate_wp05_campaign.py --N 64 --groups 100 --cases-per-group 16 --seed 20260905 --out results/full_N64
```

Then in Vivado Tcl:
```
source vivado/scripts/run_wp05_full_N64.tcl
```

Afterward:
```
python python/summarize_wp05.py
```

Target: 1,600 valid blocks and 204,800 exact TX/RX word comparisons, plus 100 pad-reuse negative tests.
