# Issues / Scientific Notes for Corresponding Author
- WP05 does not modify the frozen WP04 architecture; it is a verification package.
- The main extractor-backed campaign uses N=64 because frozen WP02 currently provides 2048 extracted bits = 64 x 32-bit pad words.
- Physical-source entropy parameters remain provisional until WP08.
- The 100-group target provides 204,800 exact end-to-end word comparisons, exceeding the requested ~100,000-check scale.
- Vivado/XSim results are RTL simulation evidence, not physical FPGA measurements.
