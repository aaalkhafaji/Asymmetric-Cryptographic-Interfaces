# WP06 — FPGA Benchmarking

This package benchmarks the frozen WP04 end-to-end architecture after WP05 verification.

## FIRST RUN ONLY
Extract to:
`C:\CWP06\WP06_FPGA_Benchmarking_READY_FOR_VIVADO`

In Vivado Tcl:
```
cd {C:/CWP06/WP06_FPGA_Benchmarking_READY_FOR_VIVADO}
set argv {16 10.000 N16_P10p000}
source vivado/scripts/build_one_wp06.tcl
```

Expected end:
```
WP06_BENCH_PASS TAG=N16_P10p000 N=16 PERIOD_NS=10.000 FREQ_MHZ=100.0 WNS=...
WP06_BENCH_COMPLETE TAG=N16_P10p000
```

Do not run the scaling or Fmax sweep until this first build is confirmed.

Later:
- `source vivado/scripts/run_scaling_100MHz.tcl`
- `set N 64; source vivado/scripts/run_fmax_sweep.tcl`
- `python python\parse_wp06_reports.py`

WP06 is not frozen until scaling, explicit Fmax characterization, latency/throughput, and final report extraction are complete.
