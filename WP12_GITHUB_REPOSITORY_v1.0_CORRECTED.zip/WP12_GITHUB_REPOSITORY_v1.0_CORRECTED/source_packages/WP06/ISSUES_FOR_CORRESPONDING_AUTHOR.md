# WP06 Scientific Notes
- Benchmark is device-level on XC7A100T-CSG324-1; no physical board is claimed.
- Fixed-point precision remains Q16.16 to preserve the frozen verified design.
- Scaling is performed over N rather than changing precision, avoiding unverified arithmetic variants.
- Achievable Fmax will be based on explicit routed timing sweeps, not inferred from WNS.
- Power is Vivado post-implementation estimated power unless later measured physically.
