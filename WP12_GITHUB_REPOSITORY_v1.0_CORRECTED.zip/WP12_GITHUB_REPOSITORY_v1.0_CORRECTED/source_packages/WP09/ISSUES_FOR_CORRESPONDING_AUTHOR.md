# WP09 Scientific Notes
- WP07 and WP08 are omitted from the project by agreement; WP09 therefore does not report physical entropy or environmental sensor robustness.
- All robustness claims must be labeled algorithmic/numerical/RTL.
- Synthetic extractor completion is not evidence of physical entropy quality.
- Poor operating conditions, if any, must be retained rather than hidden.
