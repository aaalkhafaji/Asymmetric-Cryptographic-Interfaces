# WP09 — Controlled Robustness READY FOR VIVADO

This package tests robustness of the frozen end-to-end architecture under controlled algorithmic and numerical variation.

## First run only
Extract to:
`C:\CWP09\WP09_Controlled_Robustness_READY_FOR_VIVADO`

In Vivado Tcl:
```
cd {C:/CWP09/WP09_Controlled_Robustness_READY_FOR_VIVADO}
source vivado/scripts/run_wp09_smoke.tcl
```

Expected:
```
WP09_PAD_REUSE_NEGATIVE_PASS
WP09_SUMMARY N=64 CASES=8 TX_MATCH=512 RX_MATCH=512 WORD_CHECKS=1024 FAILURES=0
WP09_PASS
```

Do not run the full 10-condition campaign until the baseline smoke passes.

After smoke:
```
source vivado/scripts/run_wp09_full.tcl
```

Then in Windows Command Prompt:
```
python python\summarize_wp09.py
```
