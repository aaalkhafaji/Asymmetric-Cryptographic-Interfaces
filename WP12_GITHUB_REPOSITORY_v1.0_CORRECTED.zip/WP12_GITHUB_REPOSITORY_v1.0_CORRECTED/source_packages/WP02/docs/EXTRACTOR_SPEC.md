# Frozen WP02 Software Extractor Convention

## Input
- Raw binary vector `x` of length `n` bits.
- Public independent seed `s` of length `n+m-1` bits.
- Conservative min-entropy lower bound `k` bits for the raw block.
- Security target `epsilon`.

## Output-length rule

The software package accepts `m` only when

`m <= floor(k - 2*log2(1/epsilon))`.

This is used as a conservative implementation gate. The entropy lower bound itself is **not** estimated by WP02.

## Two-universal family

The seed defines an `m x n` Toeplitz matrix over GF(2). The extracted output is

`y = T_s x (mod 2)`.

The seed is public and is saved alongside every vector.

## Pad conversion

The first `floor(m/q)*q` extracted bits are packed MSB-first into `q`-bit words. Any remainder bits are preserved in the result metadata but are not silently used as a partial pad word.

## Masking

For modulus `M=2^q`:

`c = (z + r) mod M`

`z = (c - r) mod M`

where `z` is a q-bit structural/plain word and `r` is the extracted pad word.
