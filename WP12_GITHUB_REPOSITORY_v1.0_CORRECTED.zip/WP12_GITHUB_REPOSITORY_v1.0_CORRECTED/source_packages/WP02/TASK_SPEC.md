# WP02 Task Specification

1. Accept raw binary source material or a reproducible synthetic/file-backed source.
2. Accept a conservative min-entropy lower bound `k` supplied by the entropy-analysis stage.
3. Compute/check a safe extracted length using a leftover-hash-lemma style security bound.
4. Implement seeded two-universal Toeplitz hashing over GF(2).
5. Treat the extractor seed as public and preserve it in every vector.
6. Convert extracted bits to finite-group pad words of configurable width `q`.
7. Implement exact modular masking/unmasking modulo `2^q`.
8. Save raw input, extractor input, public seed, extracted bits, pad words, masked words, recovered words, configuration, random seed, and hashes.
9. Reject parameter sets whose requested extractor length exceeds the configured entropy/security bound.
10. Provide deterministic vectors suitable for later RTL design/verification.
