# WP02 Acceptance Criteria

- Toeplitz extractor output matches explicit dense GF(2) multiplication for >= 1,000 randomized small/medium cases.
- Deterministic same-input/same-seed reproducibility is exact.
- Changing public seed changes the extracted output in the randomized campaign except for statistically possible collisions; collision count is reported, not hidden.
- Unsafe requested output lengths are rejected by the configured entropy/security bound.
- >= 100,000 random modular mask/unmask words recover exactly modulo `2^q` across several word widths.
- Bit packing/unpacking is lossless for complete q-bit words.
- >= 200 end-to-end extractor->pad->mask->unmask randomized blocks pass with zero unexplained failures.
- Golden vectors preserve raw input, public seed, extractor output, pad words, plaintext words, ciphertext words, recovered words, configuration, random seed, and SHA-256.
- Synthetic-source distribution diagnostics are clearly labeled non-certifying.
- Tool/environment versions, logs, results, status, issues, and checksums are included.
