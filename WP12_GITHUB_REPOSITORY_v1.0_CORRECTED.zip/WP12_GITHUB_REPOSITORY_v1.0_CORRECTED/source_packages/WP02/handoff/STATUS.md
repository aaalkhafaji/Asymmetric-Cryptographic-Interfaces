# STATUS

- Assignee: Faycal Znidi — empirical/computational implementation lead
- Start date: 2026-09-04
- Completion date: 2026-09-04
- Overall status: COMPLETE — SOFTWARE REFERENCE
- Hardware used: None for WP02
- Software/tool versions: recorded in `results/validation/environment.json`
- Authoritative upstream dependency: WP01 frozen v2 conservative assembly; old WP01 convention disregarded
- Extractor: seeded two-universal Toeplitz hashing over GF(2)
- Masking group: additive modulo `2^q`, configurable `q`
- Security-bound gate: `m <= floor(k - 2 log2(1/epsilon))`
- Entropy-source status: physical min-entropy NOT established by WP02; final `k` and final `m` await WP07/WP08

## Completed validation

- 1,000 randomized Toeplitz outputs compared with explicit dense GF(2) multiplication: 0 failures
- 35 entropy/security-bound acceptance/rejection checks: 0 violations
- 120,000 modular mask/unmask words across q={4,8,12,16,24,32}: 0 failures
- 12 packing/unpacking width cases through q=63: 0 failures
- 500 same-input/same-seed reproducibility checks: 0 failures
- 500 different-seed diagnostics: 0 observed full-output collisions (collisions are theoretically possible and would not by themselves indicate a bug)
- 220 randomized end-to-end extractor -> pad -> mask -> unmask blocks: 0 failures
- 220 golden-vector NPZ files plus JSON metadata, seeds, and SHA-256 hashes
- extractor output-length sweeps over several n, k/n, and epsilon values
- synthetic Bernoulli diagnostics clearly marked non-certifying
- unit tests: PASS

## Deviations / scope boundaries

- WP02 does not claim that the synthetic source has physical entropy suitable for cryptographic use.
- WP02 does not perform SP 800-90B entropy estimation; that belongs to WP08.
- Final physical-source extractor length must be re-frozen after WP08 supplies a conservative min-entropy lower bound.
- The software package is the reference for later RTL decisions; a synthesizable Toeplitz extractor can be implemented after final n/m/q parameters are known.
