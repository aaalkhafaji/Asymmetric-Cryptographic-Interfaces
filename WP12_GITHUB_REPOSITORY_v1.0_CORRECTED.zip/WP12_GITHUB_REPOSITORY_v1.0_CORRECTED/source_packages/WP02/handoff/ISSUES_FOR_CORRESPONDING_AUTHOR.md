# Issues for Corresponding Author

## Blocking issues

None for freezing the **software implementation and algorithmic convention** of WP02.

## Parameter freeze required after WP08

The final physical-source configuration cannot yet be frozen because WP08 has not supplied the conservative min-entropy lower bound `k`. Once WP08 is complete, the final tuple

`(raw block length n, conservative k, epsilon, extracted length m, pad width q)`

should be recorded and approved. The included `scripts/freeze_parameters_from_wp08.py` generates a proposed configuration while rounding `m` down to a whole number of q-bit pad words.

## RTL recommendation

Do not hard-code the current demonstration values (`n=4096`, `m=2048`, `q=16`) into the final hardware extractor. They are software-reference values only. Keep the RTL architecture parameterized until WP08 freezes the physical-source entropy budget.

## Seed handling

The Toeplitz seed is public, but it must be independently generated for the extractor family and preserved with each reproducibility vector. Public does not mean reusable without regard to the extractor assumptions; the experiment should record seed provenance and block association.

## Cryptographic claim boundary

WP02 validates privacy-amplification mechanics and exact finite-group masking. It does not establish confidentiality of the complete system by itself, and it does not replace the manuscript's leakage/security analysis or standardized authenticated encryption.
