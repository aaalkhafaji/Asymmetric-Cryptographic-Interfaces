from __future__ import annotations
import hashlib, json, math
from dataclasses import dataclass
from pathlib import Path
import numpy as np


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def bits_to_bytes(bits: np.ndarray) -> bytes:
    b = np.asarray(bits, dtype=np.uint8).reshape(-1)
    if b.size == 0:
        return b""
    return np.packbits(b, bitorder="big").tobytes()


def safe_output_length(k_bits: float, epsilon: float) -> int:
    if k_bits < 0:
        raise ValueError("min-entropy lower bound must be nonnegative")
    if not (0.0 < epsilon < 1.0):
        raise ValueError("epsilon must be in (0,1)")
    return max(0, int(math.floor(k_bits - 2.0 * math.log2(1.0 / epsilon))))


def validate_extractor_parameters(n: int, k_bits: float, m: int, epsilon: float) -> int:
    if n <= 0 or m <= 0:
        raise ValueError("n and m must be positive")
    if k_bits > n:
        raise ValueError("declared min-entropy cannot exceed raw input length")
    max_m = safe_output_length(k_bits, epsilon)
    if m > max_m:
        raise ValueError(f"requested output m={m} exceeds safe configured bound {max_m}")
    return max_m


def toeplitz_dense_from_seed(seed_bits: np.ndarray, m: int, n: int) -> np.ndarray:
    s = np.asarray(seed_bits, dtype=np.uint8).reshape(-1)
    if s.size != n + m - 1:
        raise ValueError(f"seed must have n+m-1={n+m-1} bits")
    # Parameterization: s[0:n] is first row; s[n:] extends first column downward.
    first_row = s[:n]
    first_col = np.concatenate(([s[0]], s[n:]))
    T = np.empty((m, n), dtype=np.uint8)
    for i in range(m):
        for j in range(n):
            T[i, j] = first_row[j-i] if j >= i else first_col[i-j]
    return T


def toeplitz_hash(bits: np.ndarray, seed_bits: np.ndarray, m: int) -> np.ndarray:
    x = np.asarray(bits, dtype=np.uint8).reshape(-1) & 1
    n = x.size
    T = toeplitz_dense_from_seed(seed_bits, m, n)
    return (T.astype(np.uint32) @ x.astype(np.uint32) & 1).astype(np.uint8)


def toeplitz_hash_convolution(bits: np.ndarray, seed_bits: np.ndarray, m: int) -> np.ndarray:
    # Independent implementation using the Toeplitz diagonal definition, optimized by XORing selected columns.
    x = np.asarray(bits, dtype=np.uint8).reshape(-1) & 1
    n = x.size
    s = np.asarray(seed_bits, dtype=np.uint8).reshape(-1)
    if s.size != n + m - 1:
        raise ValueError("wrong seed length")
    first_row = s[:n]
    first_col = np.concatenate(([s[0]], s[n:]))
    out = np.zeros(m, dtype=np.uint8)
    ones = np.flatnonzero(x)
    for j in ones:
        # Column j has T[i,j] = row[j-i] for i<=j, else col[i-j].
        upto = min(m, j + 1)
        if upto:
            idx = j - np.arange(upto)
            out[:upto] ^= first_row[idx]
        if m > j + 1:
            d = np.arange(1, m - j)
            out[j+1:] ^= first_col[d]
    return out


def pack_bits_to_words(bits: np.ndarray, q: int) -> tuple[np.ndarray, np.ndarray]:
    if q <= 0 or q > 63:
        raise ValueError("q must be between 1 and 63")
    b = np.asarray(bits, dtype=np.uint8).reshape(-1) & 1
    nwords = b.size // q
    used = b[:nwords*q]
    remainder = b[nwords*q:]
    words = np.zeros(nwords, dtype=np.uint64)
    for i in range(nwords):
        w = 0
        for bit in used[i*q:(i+1)*q]:
            w = (w << 1) | int(bit)
        words[i] = w
    return words, remainder.copy()


def unpack_words_to_bits(words: np.ndarray, q: int) -> np.ndarray:
    w = np.asarray(words, dtype=np.uint64).reshape(-1)
    bits = np.empty(w.size*q, dtype=np.uint8)
    k = 0
    for value in w:
        iv = int(value)
        for shift in range(q-1, -1, -1):
            bits[k] = (iv >> shift) & 1
            k += 1
    return bits


def modular_mask(words: np.ndarray, pad: np.ndarray, q: int) -> np.ndarray:
    if q <= 0 or q > 63:
        raise ValueError("q must be between 1 and 63")
    z = np.asarray(words, dtype=np.uint64)
    r = np.asarray(pad, dtype=np.uint64)
    if z.shape != r.shape:
        raise ValueError("words and pad must have same shape")
    mask = (1 << q) - 1
    return (z + r) & np.uint64(mask)


def modular_unmask(cipher: np.ndarray, pad: np.ndarray, q: int) -> np.ndarray:
    c = np.asarray(cipher, dtype=np.uint64)
    r = np.asarray(pad, dtype=np.uint64)
    if c.shape != r.shape:
        raise ValueError("cipher and pad must have same shape")
    mask = (1 << q) - 1
    return (c - r) & np.uint64(mask)


def generate_raw_bits(cfg: dict, rng: np.random.Generator) -> np.ndarray:
    n = int(cfg["raw_bits"])
    source = cfg.get("source", {"type":"synthetic_uniform"})
    typ = source.get("type", "synthetic_uniform")
    if typ in ("synthetic_uniform", "synthetic_bernoulli"):
        p = float(source.get("p_one", 0.5))
        if not (0 <= p <= 1):
            raise ValueError("p_one must be in [0,1]")
        return (rng.random(n) < p).astype(np.uint8)
    if typ == "file_bits":
        path = Path(source["path"])
        raw = np.frombuffer(path.read_bytes(), dtype=np.uint8)
        bits = np.unpackbits(raw, bitorder="big")
        if bits.size < n:
            raise ValueError("file does not contain enough bits")
        return bits[:n].astype(np.uint8)
    raise ValueError(f"unknown source type: {typ}")


@dataclass
class ExtractorResult:
    raw_bits: np.ndarray
    public_seed: np.ndarray
    extracted_bits: np.ndarray
    pad_words: np.ndarray
    remainder_bits: np.ndarray
    max_safe_output_bits: int


def extract_pad(cfg: dict, rng: np.random.Generator) -> ExtractorResult:
    n = int(cfg["raw_bits"])
    k = float(cfg["declared_min_entropy_bits"])
    eps = float(cfg["epsilon"])
    m = int(cfg["requested_output_bits"])
    q = int(cfg["pad_word_bits"])
    max_m = validate_extractor_parameters(n, k, m, eps)
    raw = generate_raw_bits(cfg, rng)
    public_seed = rng.integers(0, 2, size=n+m-1, dtype=np.uint8)
    out = toeplitz_hash_convolution(raw, public_seed, m)
    words, rem = pack_bits_to_words(out, q)
    return ExtractorResult(raw, public_seed, out, words, rem, max_m)


def result_metadata(cfg: dict, res: ExtractorResult) -> dict:
    return {
        "config": cfg,
        "max_safe_output_bits": res.max_safe_output_bits,
        "raw_sha256": sha256_bytes(bits_to_bytes(res.raw_bits)),
        "public_seed_sha256": sha256_bytes(bits_to_bytes(res.public_seed)),
        "extracted_sha256": sha256_bytes(bits_to_bytes(res.extracted_bits)),
        "pad_words": int(res.pad_words.size),
        "remainder_bits": int(res.remainder_bits.size),
    }
