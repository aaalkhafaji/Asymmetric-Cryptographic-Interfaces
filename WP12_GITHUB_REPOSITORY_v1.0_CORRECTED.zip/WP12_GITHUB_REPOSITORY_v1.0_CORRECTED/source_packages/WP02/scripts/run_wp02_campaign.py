from __future__ import annotations
import csv, hashlib, json, math, os, platform, subprocess, sys, time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'src'))
from wp02 import *
OUT=ROOT/'results'/'validation'; GOLD=ROOT/'results'/'golden_vectors'; FIG=ROOT/'results'/'figures'; LOG=ROOT/'logs'
for p in [OUT,GOLD,FIG,LOG]: p.mkdir(parents=True, exist_ok=True)
MASTER_SEED=2026090402
rng=np.random.default_rng(MASTER_SEED)
summary={"master_seed":MASTER_SEED}

def write_csv(path, rows, fields):
    with Path(path).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)

def sha(path):
    h=hashlib.sha256();
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''): h.update(chunk)
    return h.hexdigest()

# 1) Toeplitz parity: optimized/reference implementation vs explicit dense GF(2)
rows=[]; failures=0; t0=time.perf_counter()
for case in range(1000):
    n=int(rng.integers(8,257)); m=int(rng.integers(4,min(129,n+1)))
    x=rng.integers(0,2,n,dtype=np.uint8); s=rng.integers(0,2,n+m-1,dtype=np.uint8)
    a=toeplitz_hash(x,s,m); b=toeplitz_hash_convolution(x,s,m); ok=bool(np.array_equal(a,b)); failures+=not ok
    rows.append({"case":case,"n":n,"m":m,"pass":int(ok)})
write_csv(OUT/'toeplitz_parity_1000.csv',rows,['case','n','m','pass'])
summary['toeplitz_parity']={"cases":1000,"failures":int(failures),"seconds":time.perf_counter()-t0}

# 2) Bound accept/reject tests across k and epsilon
rows=[]; violations=0
for k in [64,128,256,512,1024,2048,3072]:
  for exponent in [16,24,32,40,64]:
    eps=2.0**(-exponent); maxm=safe_output_length(k,eps)
    accepted=True
    if maxm>0:
        try: validate_extractor_parameters(max(k,1),k,maxm,eps)
        except Exception: accepted=False
    rejected=True
    try: validate_extractor_parameters(max(k,1),k,maxm+1,eps); rejected=False
    except ValueError: pass
    if maxm==0: accepted=True
    violations += int(not accepted or not rejected)
    rows.append({"k_bits":k,"epsilon_power":exponent,"epsilon":eps,"max_safe_m":maxm,"max_accepted":int(accepted),"max_plus_one_rejected":int(rejected)})
write_csv(OUT/'security_bound_tests.csv',rows,list(rows[0].keys())); summary['security_bound']={"rows":len(rows),"violations":violations}

# 3) 100k exact modular recovery across widths
rows=[]; total=0; failures=0
for q in [4,8,12,16,24,32]:
    count=20000; mod=1<<q; z=rng.integers(0,mod,count,dtype=np.uint64); r=rng.integers(0,mod,count,dtype=np.uint64)
    c=modular_mask(z,r,q); x=modular_unmask(c,r,q); fail=int(np.count_nonzero(z!=x)); failures+=fail; total+=count
    rows.append({"q":q,"words":count,"failures":fail,"pass":int(fail==0)})
write_csv(OUT/'modular_recovery_120k.csv',rows,list(rows[0].keys())); summary['modular_recovery']={"words":total,"failures":failures}

# 4) Packing parity
rows=[]; failures=0
for q in [1,2,4,8,12,16,24,32,40,48,56,63]:
    b=rng.integers(0,2,257*q+7,dtype=np.uint8); w,rem=pack_bits_to_words(b,q); ub=unpack_words_to_bits(w,q)
    used=(len(b)//q)*q; ok=bool(np.array_equal(ub,b[:used]) and np.array_equal(rem,b[used:])); failures+=not ok
    rows.append({"q":q,"words":257,"remainder_bits":len(rem),"pass":int(ok)})
write_csv(OUT/'packing_tests.csv',rows,list(rows[0].keys())); summary['packing']={"cases":len(rows),"failures":int(failures)}

# 5) Determinism and seed-change collision diagnostics
rows=[]; collisions=0; det_fail=0
for case in range(500):
    n=256; m=128; x=rng.integers(0,2,n,dtype=np.uint8); s1=rng.integers(0,2,n+m-1,dtype=np.uint8); s2=rng.integers(0,2,n+m-1,dtype=np.uint8)
    y1=toeplitz_hash_convolution(x,s1,m); y1b=toeplitz_hash_convolution(x,s1,m); y2=toeplitz_hash_convolution(x,s2,m)
    deterministic=np.array_equal(y1,y1b); collision=np.array_equal(y1,y2); det_fail+=not deterministic; collisions+=collision
    rows.append({"case":case,"deterministic":int(deterministic),"different_seed_collision":int(collision)})
write_csv(OUT/'seed_reproducibility.csv',rows,list(rows[0].keys())); summary['seed_reproducibility']={"cases":500,"determinism_failures":int(det_fail),"different_seed_collisions":int(collisions)}

# 6) >=200 end-to-end blocks + golden vectors
rows=[]; failures=0
q_options=[8,12,16,24,32]
for case in range(220):
    seed=int(rng.integers(0,2**32-1)); crng=np.random.default_rng(seed)
    q=int(crng.choice(q_options)); n=int(crng.choice([256,384,512,768,1024]))
    k_fraction=float(crng.uniform(0.72,0.95)); k=math.floor(n*k_fraction); eps=2.0**(-int(crng.choice([16,24,32])))
    maxm=safe_output_length(k,eps)
    if maxm < q*4: # enforce usable vector
        k=min(n, max(k, q*4 + int(2*math.log2(1/eps)) + 2)); maxm=safe_output_length(k,eps)
    m=(maxm//q)*q
    # cap for campaign runtime while preserving validated bound
    m=min(m,(256//q)*q)
    if m < q: m=q
    cfg={"raw_bits":n,"declared_min_entropy_bits":k,"epsilon":eps,"requested_output_bits":m,"pad_word_bits":q,"random_seed":seed,"source":{"type":"synthetic_bernoulli","p_one":0.5}}
    res=extract_pad(cfg,crng); mod=1<<q; plain=crng.integers(0,mod,res.pad_words.size,dtype=np.uint64); cipher=modular_mask(plain,res.pad_words,q); rec=modular_unmask(cipher,res.pad_words,q)
    ok=bool(np.array_equal(plain,rec)); failures+=not ok
    npz=GOLD/f'case_{case:04d}.npz'; np.savez_compressed(npz,raw_bits=res.raw_bits,public_seed=res.public_seed,extracted_bits=res.extracted_bits,pad_words=res.pad_words,remainder_bits=res.remainder_bits,plaintext_words=plain,ciphertext_words=cipher,recovered_words=rec)
    meta=result_metadata(cfg,res); meta.update({"case":case,"seed":seed,"pass":ok,"npz_sha256":sha(npz)}); (GOLD/f'case_{case:04d}.json').write_text(json.dumps(meta,indent=2))
    rows.append({"case":case,"seed":seed,"n":n,"k":k,"epsilon":eps,"m":m,"q":q,"pad_words":len(res.pad_words),"pass":int(ok),"npz_sha256":meta['npz_sha256']})
write_csv(OUT/'end_to_end_220_blocks.csv',rows,list(rows[0].keys())); summary['end_to_end']={"blocks":len(rows),"failures":int(failures)}

# 7) output-length/security sweep
rows=[]
for n in [256,512,1024,2048,4096]:
  for frac in [0.5,0.6,0.7,0.8,0.9,1.0]:
    k=n*frac
    for exp in [16,32,64]: rows.append({"n":n,"k_fraction":frac,"k_bits":k,"epsilon_power":exp,"safe_output_bits":safe_output_length(k,2.0**-exp)})
write_csv(OUT/'extractor_length_sweep.csv',rows,list(rows[0].keys()))

# 8) synthetic diagnostics only: ones rate and empirical most-common-bit min-entropy for Bernoulli p (NOT security estimate)
rows=[]
for p in [0.50,0.52,0.55,0.60,0.70,0.80,0.90]:
    bits=(rng.random(200000)<p).astype(np.uint8); p1=float(bits.mean()); pmax=max(p1,1-p1); diagnostic=-math.log2(pmax)
    rows.append({"configured_p_one":p,"sample_count":len(bits),"observed_p_one":p1,"diagnostic_most_common_bit_hmin":diagnostic,"certifying":0})
write_csv(OUT/'synthetic_source_diagnostics.csv',rows,list(rows[0].keys()))
summary['synthetic_diagnostics_note']='diagnostic only; not a physical-source entropy estimate or SP 800-90B result'

# Figures
try:
    import matplotlib.pyplot as plt
    data=np.genfromtxt(OUT/'extractor_length_sweep.csv',delimiter=',',names=True)
    for exp in [16,32,64]:
        fig=plt.figure(); ax=fig.add_subplot(111)
        for n in [256,512,1024,2048,4096]:
            sel=(data['n']==n)&(data['epsilon_power']==exp); ax.plot(data['k_fraction'][sel],data['safe_output_bits'][sel],marker='o',label=f'n={n}')
        ax.set_xlabel('Declared min-entropy fraction k/n'); ax.set_ylabel('Maximum accepted output bits m'); ax.set_title(f'Extractor output bound, epsilon=2^-{exp}'); ax.legend(); fig.tight_layout(); fig.savefig(FIG/f'extractor_bound_eps_2m{exp}.png',dpi=180); plt.close(fig)
except Exception as e:
    summary['figure_error']=repr(e)

# environment and logs
summary['overall_pass']=all([
 summary['toeplitz_parity']['failures']==0, summary['security_bound']['violations']==0, summary['modular_recovery']['failures']==0,
 summary['packing']['failures']==0, summary['seed_reproducibility']['determinism_failures']==0, summary['end_to_end']['failures']==0])
(OUT/'campaign_summary.json').write_text(json.dumps(summary,indent=2))
env={"python":sys.version,"platform":platform.platform(),"numpy":np.__version__}
try:
 import matplotlib; env['matplotlib']=matplotlib.__version__
except Exception: pass
(OUT/'environment.json').write_text(json.dumps(env,indent=2))
print(json.dumps(summary,indent=2))
if not summary['overall_pass']: raise SystemExit(1)
