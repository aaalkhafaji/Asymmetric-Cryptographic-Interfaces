from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from wp02 import *

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config', default=str(ROOT/'configs/default_wp02.json')); ap.add_argument('--out', default=str(ROOT/'results/reference_example')); args=ap.parse_args()
    cfg=json.loads(Path(args.config).read_text()); rng=np.random.default_rng(int(cfg['random_seed']))
    res=extract_pad(cfg,rng); q=int(cfg['pad_word_bits']); mod=1<<q
    plaintext=rng.integers(0,mod,size=res.pad_words.size,dtype=np.uint64)
    cipher=modular_mask(plaintext,res.pad_words,q); recovered=modular_unmask(cipher,res.pad_words,q)
    if not np.array_equal(plaintext,recovered): raise RuntimeError('modular recovery failed')
    out=Path(args.out); out.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out/'reference_vector.npz',raw_bits=res.raw_bits,public_seed=res.public_seed,extracted_bits=res.extracted_bits,pad_words=res.pad_words,remainder_bits=res.remainder_bits,plaintext_words=plaintext,ciphertext_words=cipher,recovered_words=recovered)
    meta=result_metadata(cfg,res); meta['exact_modular_recovery']=True; (out/'metadata.json').write_text(json.dumps(meta,indent=2))
    with (out/'words.csv').open('w',newline='') as f:
        w=csv.writer(f); w.writerow(['index','pad','plaintext','ciphertext','recovered']);
        for i,(r,z,c,x) in enumerate(zip(res.pad_words,plaintext,cipher,recovered)): w.writerow([i,int(r),int(z),int(c),int(x)])
    print(json.dumps(meta,indent=2))
if __name__=='__main__': main()
