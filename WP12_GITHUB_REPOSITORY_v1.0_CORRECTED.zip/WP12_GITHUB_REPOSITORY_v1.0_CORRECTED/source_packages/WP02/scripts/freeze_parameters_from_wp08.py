from __future__ import annotations
import argparse, json, math, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'src'))
from wp02 import safe_output_length
ap=argparse.ArgumentParser(description='Create a proposed WP02 physical-source configuration from a WP08 min-entropy lower bound.')
ap.add_argument('--raw-bits',type=int,required=True); ap.add_argument('--min-entropy-bits',type=float,required=True); ap.add_argument('--epsilon-power',type=int,default=64,help='epsilon=2^-power'); ap.add_argument('--pad-word-bits',type=int,default=16); ap.add_argument('--out',default=str(ROOT/'configs/proposed_from_wp08.json')); a=ap.parse_args()
eps=2.0**(-a.epsilon_power); maxm=safe_output_length(a.min_entropy_bits,eps); m=(maxm//a.pad_word_bits)*a.pad_word_bits
cfg={'raw_bits':a.raw_bits,'declared_min_entropy_bits':a.min_entropy_bits,'epsilon':eps,'epsilon_power':a.epsilon_power,'requested_output_bits':m,'pad_word_bits':a.pad_word_bits,'source':{'type':'file_bits','path':'REPLACE_WITH_WP07_RAW_OR_PROCESSED_BINARY_PATH'},'status':'PROPOSED_FROM_WP08_REQUIRES_CORRESPONDING_AUTHOR_FREEZE'}
Path(a.out).write_text(json.dumps(cfg,indent=2)); print(json.dumps({'max_safe_output_bits':maxm,'whole_pad_word_output_bits':m,'config':a.out},indent=2))
