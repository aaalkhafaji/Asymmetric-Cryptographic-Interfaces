# Contribution Boundary

WP02 implements the software reference for privacy amplification and modular masking. It does not alter the SPDE/IIM mathematics, prove physical-source entropy, or claim NIST certification. The final `k` used for a physical source must come from WP08 and be approved by the corresponding author.
