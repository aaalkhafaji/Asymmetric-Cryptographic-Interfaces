import json, sys, unittest
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'src'))
from wp02 import *
class T(unittest.TestCase):
    def test_bound(self):
        self.assertEqual(safe_output_length(256,2**-20),216)
        with self.assertRaises(ValueError): validate_extractor_parameters(256,256,217,2**-20)
    def test_toeplitz_parity(self):
        rng=np.random.default_rng(1)
        for _ in range(50):
            n=int(rng.integers(4,40)); m=int(rng.integers(2,30)); x=rng.integers(0,2,n,dtype=np.uint8); s=rng.integers(0,2,n+m-1,dtype=np.uint8)
            a=toeplitz_hash(x,s,m); b=toeplitz_hash_convolution(x,s,m); self.assertTrue(np.array_equal(a,b))
    def test_pack(self):
        rng=np.random.default_rng(2)
        for q in [1,4,8,16,32]:
            b=rng.integers(0,2,100*q+3,dtype=np.uint8); w,r=pack_bits_to_words(b,q); used=(len(b)//q)*q; self.assertTrue(np.array_equal(unpack_words_to_bits(w,q),b[:used])); self.assertTrue(np.array_equal(r,b[used:]))
    def test_mask(self):
        rng=np.random.default_rng(3)
        for q in [4,8,12,16,24,32]:
            z=rng.integers(0,1<<q,1000,dtype=np.uint64); r=rng.integers(0,1<<q,1000,dtype=np.uint64); c=modular_mask(z,r,q); x=modular_unmask(c,r,q); self.assertTrue(np.array_equal(z,x))
if __name__=='__main__': unittest.main()
