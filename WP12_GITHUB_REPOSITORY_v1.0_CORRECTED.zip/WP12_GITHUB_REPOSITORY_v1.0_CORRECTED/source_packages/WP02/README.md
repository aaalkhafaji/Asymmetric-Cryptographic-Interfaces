# WP02 — Extractor and Modular Masking (Complete Software Reference)

This package implements the software-reference cryptographic-conditioning boundary for the SPDE/IIM project.

## Scope

Implemented chain:

`raw bits -> extractor input -> public Toeplitz seed -> two-universal hash -> extracted bits -> q-bit pad words -> modular mask -> exact modular unmask`

The extractor is a seeded two-universal Toeplitz hash over GF(2). The output length is constrained using a leftover-hash-lemma style bound

`m <= floor(k - 2*log2(1/epsilon))`,

where `k` is a conservative *declared* min-entropy lower bound for the raw input block and `epsilon` is the configured statistical-distance target. WP02 does **not** estimate physical-source min-entropy; WP07/WP08 must supply that bound for the final physical configuration.

## Quick start

```bash
python scripts/run_wp02_reference.py --config configs/default_wp02.json
python scripts/run_wp02_campaign.py
python -m unittest discover -s tests -v
```

## Outputs

- deterministic reference vectors in CSV/NPZ/JSON
- randomized extractor/masking verification
- exact modular recovery validation
- Toeplitz implementation parity against an explicit dense GF(2) matrix
- security-bound acceptance/rejection tests
- extractor-length sweep and mask-word packing results
- synthetic-source diagnostics (diagnostic only; not an entropy certification)
- SHA-256 manifests
- completed `handoff/STATUS.md`
- completed `handoff/ISSUES_FOR_CORRESPONDING_AUTHOR.md`

## Scientific claim boundary

This package demonstrates correctness of the extractor and modular-masking *implementation*. It does not establish that any real physical source has the declared entropy. Final extractor parameters must be re-frozen after WP08.
