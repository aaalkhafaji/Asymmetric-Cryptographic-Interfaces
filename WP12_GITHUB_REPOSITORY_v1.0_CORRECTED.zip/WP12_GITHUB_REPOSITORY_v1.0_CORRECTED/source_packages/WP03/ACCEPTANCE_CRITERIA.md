# WP03 v2 — Frozen conservative interface assembly

**Use `docs/MATHEMATICAL_ASSEMBLY_SPEC.md`. Consume WP01-v2 golden vectors; older one-row-overwrite vectors are superseded.**

# Acceptance Criteria

- >=10,000 randomized valid systems agree with the software fixed-point model within 1 LSB (or justified tolerance).
- All declared corner cases have pass/fail records.
- Overflow/pivot error is explicit, never silently saturated without logging.
- Synthesis completes for the target FPGA part.
- Latency, initiation interval, LUT/FF/DSP/BRAM, Fmax, and fixed-point format are reported.
