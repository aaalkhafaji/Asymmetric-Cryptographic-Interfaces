# WP03 — RTL Tridiagonal Decoder — RTL READY FOR VIVADO

Authoritative source: Adnan's `WP03_RTL_Tridiagonal_Decoder_v2_Frozen`; older one-row-overwrite conventions are superseded.

## Frozen architecture
- Global Thomas tridiagonal solver (not a local inverse stencil).
- Normalized conservative matrix `A=h^2B`.
- Signed parameterized Q-format; nominal `W=32, FRAC=16` (Q16.16).
- Sequential forward elimination/back substitution.
- Deterministic truncation toward zero for fixed-point multiply/divide.
- Explicit pivot and overflow flags; no silent pivot clamping.
- Hardware target: AMD Artix-7 XC7A100T-CSG324-1; Vivado 2025.2.

## Included
- Synthesizable core and scalar-load wrapper under `rtl/`.
- Bit-accurate Python fixed-point model.
- 10,000-case nominal regression dataset (2,500 each for N=16,32,64,128).
- XSim testbench that compares every output to the software fixed-point expected vector and requires <=1 LSB.
- Corner/stress model records.
- Vivado batch simulation and implementation Tcl scripts plus 100-MHz XDC.

## Why status is not yet COMPLETE
Vivado/XSim is not installed in the current build environment. Therefore no synthesis, implementation, timing, resource, or XSim pass claim is fabricated. Run `RUN_VIVADO_WP03.bat` on the Vivado 2025.2 machine. Return the `logs/` and `vivado/reports/` files to finalize WP03.
