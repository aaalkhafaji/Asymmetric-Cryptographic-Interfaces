# WP03 v2 — Frozen conservative interface assembly

**Use `docs/MATHEMATICAL_ASSEMBLY_SPEC.md`. Consume WP01-v2 golden vectors; older one-row-overwrite vectors are superseded.**

# Starter Validation

Golden-vector generator executed successfully on 2026-09-03 and a 100-case floating-point decoder vector file is included. RTL datapath remains the assignee task.
