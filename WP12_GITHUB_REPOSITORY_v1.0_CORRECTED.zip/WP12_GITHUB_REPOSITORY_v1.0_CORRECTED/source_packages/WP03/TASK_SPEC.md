# WP03 v2 — Frozen conservative interface assembly

**Use `docs/MATHEMATICAL_ASSEMBLY_SPEC.md`. Consume WP01-v2 golden vectors; older one-row-overwrite vectors are superseded.**

# Tasks

1. Implement a sequential or pipelined Thomas/tridiagonal solver for the declared fixed-point format.
2. Support the same coefficient/vector convention as WP01.
3. Define division implementation (DSP divider, reciprocal approximation, LUT/Newton, etc.).
4. Detect zero/near-zero pivots and overflow.
5. Verify against WP01 golden vectors.
6. Sweep word length and fractional bits; report reconstruction error and failures.
7. Produce synthesizable RTL, testbench, timing/resource reports.

Mathematical requirement: this must be a global tridiagonal solve, not a local inverse stencil.
