# WP04 Design Decisions

1. **WP01 is authoritative for ordering.** The frozen Python model first forms the structural vector `S=A P`, quantizes it, then masks the resulting finite words. Therefore the RTL follows structural transform -> modular mask; the receiver performs unmask -> global solve.
2. **Q16.16 arithmetic.** Hardware operands are signed 32-bit Q16.16. Products truncate toward zero, matching the frozen WP03 arithmetic convention.
3. **Modulo masking.** Ciphertext is `(structural_word + pad) mod 2^32`; unmasking is subtraction modulo `2^32`.
4. **WP03 stays frozen.** The Architecture-C decoder source is copied unchanged and instantiated directly.
5. **Extractor boundary.** WP04 accepts/exercises extracted pad words; it does not synthesize the Toeplitz extractor itself because physical min-entropy and final output length are not frozen until WP08.
6. **N=64 extractor-backed smoke test.** Frozen WP02's 2048-bit output naturally yields 64 x 32-bit pad words. N=128 would require 4096 extracted bits and is not scientifically supportable under the current provisional entropy declaration.
7. **Pad reuse.** The experimental top level contains a bounded 16-entry pad-ID history CAM. Reusing a retained pad ID causes block rejection. This is a test/experimental safety mechanism, not a complete production key-management system.
8. **Error semantics.** Encoder arithmetic overflow, decoder pivot/overflow errors, and pad reuse are separately visible.
