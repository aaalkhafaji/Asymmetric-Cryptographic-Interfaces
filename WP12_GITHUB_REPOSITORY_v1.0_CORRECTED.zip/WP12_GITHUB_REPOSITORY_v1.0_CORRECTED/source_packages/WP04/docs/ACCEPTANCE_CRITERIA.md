# WP04 Acceptance Criteria

WP04 may be frozen only after all of the following are observed in Vivado/XSim:

- 64/64 transmitted ciphertext words exactly equal independent Python golden vectors.
- 64/64 receiver words exactly equal the independent fixed-point Python receiver model.
- No encoder overflow on the positive smoke vector.
- No WP03 decoder error, pivot error, or overflow error on the positive smoke vector.
- Reusing the same `pad_id` for a second block is deliberately rejected.
- RTL simulation terminates with `WP04_PASS`.
- Synthesis and implementation complete for the target Artix-7 device.
- Timing/utilization/power reports are preserved for later WP06 benchmarking.

Note: recovered plaintext need not be identical to the originally quantized plaintext word-for-word because the forward fixed-point operator followed by the fixed-point global inverse introduces finite-word reconstruction error. The RTL receiver must instead exactly match the independent fixed-point reference result. The supplied vector has a 46-LSB maximum plaintext-to-recovered difference while RTL-vs-reference target is 0 LSB.
