set script_dir [file dirname [file normalize [info script]]]
set root [file normalize "$script_dir/../.."]
set N 64
set DATADIR [file normalize "$root/results/smoke_N64"]
if {[llength $argv] >= 1} { set N [lindex $argv 0] }
if {[llength $argv] >= 2} { set DATADIR [file normalize [lindex $argv 1]] }
create_project -force wp04_xsim "$root/vivado/xsim_N${N}" -part xc7a100tcsg324-1
add_files -fileset sources_1 [list "$root/rtl/tridiagonal_decoder_wp03_frozen.sv" "$root/rtl/wp04_encoder.sv" "$root/rtl/wp04_top.sv"]
add_files -fileset sim_1 "$root/tb/tb_wp04_end_to_end.sv"
set_property top tb_wp04_end_to_end [get_filesets sim_1]
set_property generic "W=32 FRAC=16 N=$N" [get_filesets sim_1]
set_property -name {xsim.simulate.xsim.more_options} -value "-testplusarg DATADIR=$DATADIR" -objects [get_filesets sim_1]
launch_simulation
run all
puts "WP04_XSIM_COMPLETE N=$N"
