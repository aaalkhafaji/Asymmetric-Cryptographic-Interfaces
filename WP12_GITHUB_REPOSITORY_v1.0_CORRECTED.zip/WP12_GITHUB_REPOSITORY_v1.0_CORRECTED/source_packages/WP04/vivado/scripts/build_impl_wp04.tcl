set script_dir [file dirname [file normalize [info script]]]
set root [file normalize "$script_dir/../.."]
set part "xc7a100tcsg324-1"
set N 64
if {[llength $argv] >= 1} { set N [lindex $argv 0] }
create_project -force wp04_impl "$root/vivado/wp04_impl_N${N}" -part $part
add_files [list "$root/rtl/tridiagonal_decoder_wp03_frozen.sv" "$root/rtl/wp04_encoder.sv" "$root/rtl/wp04_top.sv"]
set_property top wp04_top [current_fileset]
read_xdc "$root/vivado/constraints/wp04_clock.xdc"
synth_design -top wp04_top -part $part -generic W=32 -generic FRAC=16 -generic N=$N -directive PerformanceOptimized
opt_design
place_design
phys_opt_design
route_design
file mkdir "$root/vivado/reports"
report_utilization -file "$root/vivado/reports/wp04_N${N}_post_impl_utilization.rpt"
report_timing_summary -file "$root/vivado/reports/wp04_N${N}_post_impl_timing.rpt"
report_power -file "$root/vivado/reports/wp04_N${N}_post_impl_power.rpt"
write_checkpoint -force "$root/vivado/reports/wp04_N${N}_routed.dcp"
set wns [get_property SLACK [get_timing_paths -setup -max_paths 1]]
puts "WP04_IMPLEMENTATION_COMPLETE N=$N WNS=$wns"
