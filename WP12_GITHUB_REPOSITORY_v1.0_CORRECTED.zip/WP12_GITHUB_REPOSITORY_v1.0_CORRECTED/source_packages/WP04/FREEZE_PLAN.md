# Freeze Plan

WP04 will be renamed/frozen only after:
- XSim `WP04_PASS`;
- repeated-pad negative test passes;
- routed implementation succeeds;
- timing/utilization/power evidence is reviewed;
- hashes are regenerated from the final validated files.
