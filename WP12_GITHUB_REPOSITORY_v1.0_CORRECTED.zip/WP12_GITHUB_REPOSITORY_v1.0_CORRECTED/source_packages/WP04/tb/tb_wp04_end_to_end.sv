`timescale 1ns/1ps
module tb_wp04_end_to_end;
  parameter int W=32, FRAC=16, N=64, AW=$clog2(N);
  logic clk=0; always #5 clk=~clk;
  logic rst_n=0;
  logic cfg_we; logic [1:0] cfg_sel; logic [AW-1:0] cfg_addr; logic signed [W-1:0] cfg_data;
  logic block_start; logic [31:0] block_id,pad_id; logic in_valid,in_ready; logic signed [W-1:0] plaintext_in; logic [W-1:0] pad_in;
  logic tx_valid; logic [AW-1:0] tx_index; logic [W-1:0] tx_data;
  logic out_valid; logic [AW-1:0] out_index; logic signed [W-1:0] plaintext_out; logic block_done,busy,block_rejected,pad_reuse_error,encoder_overflow_error,decoder_error,decoder_pivot_error,decoder_overflow_error; logic [31:0] decoder_cycles;

  logic [W-1:0] a_mem[0:N-2],b_mem[0:N-1],c_mem[0:N-2],p_mem[0:N-1],pad_mem[0:N-1],cipher_exp[0:N-1],rec_exp[0:N-1];
  string datadir;
  integer i,failures,tx_seen,rx_seen;

  wp04_top #(.W(W),.FRAC(FRAC),.N(N),.PAD_HISTORY_DEPTH(16)) dut(.*);

  task automatic cfg_write(input [1:0] sel,input integer addr,input logic [W-1:0] data);
    begin
      @(negedge clk); cfg_we=1; cfg_sel=sel; cfg_addr=addr[AW-1:0]; cfg_data=$signed(data);
      @(negedge clk); cfg_we=0;
    end
  endtask

  initial begin
    cfg_we=0; cfg_sel=0; cfg_addr=0; cfg_data=0; block_start=0; block_id=0; pad_id=0; in_valid=0; plaintext_in=0; pad_in=0;
    failures=0; tx_seen=0; rx_seen=0;
    if (!$value$plusargs("DATADIR=%s",datadir)) datadir="results/smoke_N64";
    $readmemh({datadir,"/a.mem"},a_mem); $readmemh({datadir,"/b.mem"},b_mem); $readmemh({datadir,"/c.mem"},c_mem);
    $readmemh({datadir,"/plaintext.mem"},p_mem); $readmemh({datadir,"/pad.mem"},pad_mem);
    $readmemh({datadir,"/cipher_expected.mem"},cipher_exp); $readmemh({datadir,"/recovered_expected.mem"},rec_exp);

    repeat(5) @(negedge clk); rst_n=1; repeat(3) @(negedge clk);

    for(i=0;i<N-1;i=i+1) cfg_write(2'd0,i,a_mem[i]);
    for(i=0;i<N;i=i+1)   cfg_write(2'd1,i,b_mem[i]);
    for(i=0;i<N-1;i=i+1) cfg_write(2'd2,i,c_mem[i]);

    @(negedge clk); block_id=32'h00000001; pad_id=32'hA5040001; block_start=1;
    @(negedge clk); block_start=0;
    if (!in_ready) begin $display("WP04_FAIL input not ready after accepted block_start"); failures=failures+1; end

    for(i=0;i<N;i=i+1) begin
      while(!in_ready) @(negedge clk);
      plaintext_in=$signed(p_mem[i]); pad_in=pad_mem[i]; in_valid=1;
      @(negedge clk); in_valid=0;
    end

    wait(block_done===1'b1); @(negedge clk);
    if (tx_seen!=N) begin $display("WP04_FAIL tx count %0d expected %0d",tx_seen,N); failures=failures+1; end
    if (rx_seen!=N) begin $display("WP04_FAIL rx count %0d expected %0d",rx_seen,N); failures=failures+1; end
    if (encoder_overflow_error || decoder_error || decoder_pivot_error || decoder_overflow_error) begin
      $display("WP04_FAIL status enc_ovf=%0d dec_err=%0d piv=%0d dec_ovf=%0d",encoder_overflow_error,decoder_error,decoder_pivot_error,decoder_overflow_error); failures=failures+1;
    end

    // Required negative test: same pad identifier must be rejected.
    @(negedge clk); block_id=32'h00000002; pad_id=32'hA5040001; block_start=1;
    @(negedge clk); block_start=0;
    @(posedge clk); #1;
    if (!(block_rejected && pad_reuse_error)) begin
      $display("WP04_FAIL repeated-pad negative test did not reject"); failures=failures+1;
    end else $display("WP04_PAD_REUSE_NEGATIVE_PASS");

    if (failures==0) begin
      $display("WP04_SUMMARY N=%0d TX_MATCH=%0d RX_MATCH=%0d FAILURES=0 DECODER_CYCLES=%0d",N,tx_seen,rx_seen,decoder_cycles);
      $display("WP04_PASS");
    end else begin
      $display("WP04_SUMMARY N=%0d TX_SEEN=%0d RX_SEEN=%0d FAILURES=%0d",N,tx_seen,rx_seen,failures);
      $display("WP04_FAIL");
    end
    $finish;
  end

  always @(posedge clk) begin
    #1;
    if (tx_valid) begin
      tx_seen=tx_seen+1;
      if (tx_data !== cipher_exp[tx_index]) begin
        $display("WP04_TX_MISMATCH idx=%0d got=%h exp=%h",tx_index,tx_data,cipher_exp[tx_index]); failures=failures+1;
      end
    end
    if (out_valid) begin
      rx_seen=rx_seen+1;
      if ($unsigned(plaintext_out) !== rec_exp[out_index]) begin
        $display("WP04_RX_MISMATCH idx=%0d got=%h exp=%h",out_index,$unsigned(plaintext_out),rec_exp[out_index]); failures=failures+1;
      end
    end
  end

  initial begin
    #50000000;
    $display("WP04_TIMEOUT"); $finish;
  end
endmodule
