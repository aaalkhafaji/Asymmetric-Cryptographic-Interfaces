# Issues / scientific boundaries to preserve

- Frozen WP02 currently uses provisional entropy parameters. Final min-entropy and extractor output length must come from WP08 physical-source analysis.
- Under the current configured 2048-bit extracted output, the extractor-backed end-to-end smoke test is N=64 for 32-bit pad words. Do not claim extractor-backed N=128 until a defensible 4096-bit output configuration is supported by WP08.
- The top-level pad-reuse detector stores a bounded history of 16 pad IDs. Describe it as an experimental reuse-detection mechanism, not production key lifecycle management.
- Vivado power, when generated, is an estimate unless physical board measurement is separately performed.
