`timescale 1ns/1ps
// WP03 Architecture C: timing-closed, resource-efficient fixed-point Thomas decoder.
// Design goals:
//   1) preserve the frozen Q16.16 arithmetic exactly (truncate toward zero),
//   2) eliminate long combinational divide/memory mux paths,
//   3) infer BRAM for all vector storage,
//   4) use one pipelined shared multiplier and one iterative divider,
//   5) provide clean valid/done boundaries for timing closure at 100 MHz.

module fx_divider_iterative_c #(
  parameter int W = 32,
  parameter int FRAC = 16
)(
  input  logic clk,
  input  logic rst_n,
  input  logic start,
  input  logic signed [W-1:0] num,
  input  logic signed [W-1:0] den,
  output logic signed [W-1:0] quotient,
  output logic busy,
  output logic done,
  output logic overflow,
  output logic divzero
);
  localparam int DW = W + FRAC;
  localparam int CW = (DW <= 2) ? 1 : $clog2(DW+1);

  // Shift-register restoring divider: no variable bit-select and no '/' operator.
  logic [DW-1:0] dividend_shift;
  logic [DW-1:0] quotient_shift;
  logic [W:0] remainder;
  logic [W-1:0] divisor;
  logic sign_neg;
  logic [CW-1:0] iter_left;

  logic [W:0] rem_shift;
  logic take_bit;
  logic [W:0] rem_next;
  logic [DW-1:0] quot_next;
  logic [DW-1:0] dividend_next;
  logic [DW-1:0] pos_limit, neg_limit;
  logic mag_overflow;
  logic [W-1:0] mag_lo;

  always_comb begin
    rem_shift = {remainder[W-1:0], dividend_shift[DW-1]};
    take_bit = (rem_shift >= {1'b0, divisor});
    rem_next = take_bit ? (rem_shift - {1'b0, divisor}) : rem_shift;
    quot_next = {quotient_shift[DW-2:0], take_bit};
    dividend_next = {dividend_shift[DW-2:0], 1'b0};

    pos_limit = '0;
    neg_limit = '0;
    pos_limit[W-2:0] = {(W-1){1'b1}};
    neg_limit[W-1] = 1'b1;
    mag_overflow = sign_neg ? (quot_next > neg_limit) : (quot_next > pos_limit);
    mag_lo = quot_next[W-1:0];
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      quotient <= '0;
      busy <= 1'b0;
      done <= 1'b0;
      overflow <= 1'b0;
      divzero <= 1'b0;
      dividend_shift <= '0;
      quotient_shift <= '0;
      remainder <= '0;
      divisor <= '0;
      sign_neg <= 1'b0;
      iter_left <= '0;
    end else begin
      done <= 1'b0;
      if (start && !busy) begin
        overflow <= 1'b0;
        divzero <= 1'b0;
        quotient <= '0;
        if (den == 0) begin
          divzero <= 1'b1;
          overflow <= 1'b1;
          done <= 1'b1;
          busy <= 1'b0;
        end else begin
          dividend_shift <= {(num[W-1] ? (~num + 1'b1) : num), {FRAC{1'b0}}};
          quotient_shift <= '0;
          remainder <= '0;
          divisor <= den[W-1] ? (~den + 1'b1) : den;
          sign_neg <= num[W-1] ^ den[W-1];
          iter_left <= DW;
          busy <= 1'b1;
        end
      end else if (busy) begin
        remainder <= rem_next;
        quotient_shift <= quot_next;
        dividend_shift <= dividend_next;
        if (iter_left == 1) begin
          busy <= 1'b0;
          done <= 1'b1;
          overflow <= mag_overflow;
          if (mag_overflow) quotient <= '0;
          else if (sign_neg) quotient <= -$signed(mag_lo);
          else quotient <= $signed(mag_lo);
          iter_left <= '0;
        end else begin
          iter_left <= iter_left - 1'b1;
        end
      end
    end
  end
endmodule

module fx_multiplier_pipe_c #(
  parameter int W = 32,
  parameter int FRAC = 16
)(
  input logic clk,
  input logic rst_n,
  input logic start,
  input logic signed [W-1:0] u,
  input logic signed [W-1:0] v,
  output logic signed [W-1:0] q,
  output logic overflow,
  output logic done
);
  logic signed [W-1:0] u_r, v_r;
  (* use_dsp = "yes" *) logic signed [2*W-1:0] prod_r;
  logic signed [2*W-1:0] scaled_r;
  logic v1, v2, v3;
  logic signed [W-1:0] q_lo;

  always_comb q_lo = scaled_r[W-1:0];

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      u_r <= '0; v_r <= '0; prod_r <= '0; scaled_r <= '0;
      q <= '0; overflow <= 1'b0; done <= 1'b0;
      v1 <= 1'b0; v2 <= 1'b0; v3 <= 1'b0;
    end else begin
      done <= 1'b0;
      v1 <= start;
      v2 <= v1;
      v3 <= v2;
      if (start) begin
        u_r <= u;
        v_r <= v;
      end
      if (v1) begin
        prod_r <= $signed(u_r) * $signed(v_r);
      end
      if (v2) begin
        // Exact truncation toward zero after Q multiplication.
        if (prod_r < 0)
          scaled_r <= -((-prod_r) >>> FRAC);
        else
          scaled_r <= prod_r >>> FRAC;
      end
      if (v3) begin
        q <= q_lo;
        overflow <= (scaled_r != {{W{q_lo[W-1]}}, q_lo});
        done <= 1'b1;
      end
    end
  end
endmodule

// 1-read/1-write synchronous RAM with an extra output register. The coding
// style is deliberately BRAM-friendly; the extra register breaks memory-to-
// arithmetic critical paths and can be absorbed into the BRAM output stage.
module wp03_bram_1r1w_c #(
  parameter int W = 32,
  parameter int N = 128,
  parameter int AW = $clog2(N)
)(
  input logic clk,
  input logic we,
  input logic [AW-1:0] waddr,
  input logic signed [W-1:0] wdata,
  input logic [AW-1:0] raddr,
  output logic signed [W-1:0] rdata
);
  (* ram_style = "block" *) logic signed [W-1:0] mem [0:N-1];
  logic signed [W-1:0] raw_q;
  always_ff @(posedge clk) begin
    if (we) mem[waddr] <= wdata;
    raw_q <= mem[raddr];
    rdata <= raw_q;
  end
endmodule

module tridiagonal_decoder #(
  parameter int W = 32,
  parameter int FRAC = 16,
  parameter int N = 128
)(
  input logic clk,
  input logic rst_n,
  input logic load_we,
  input logic [1:0] load_sel,
  input logic [$clog2(N)-1:0] load_addr,
  input logic signed [W-1:0] load_data,
  input logic start,
  input logic signed [W-1:0] pivot_tol,
  input logic [$clog2(N)-1:0] read_addr,
  output logic signed [W-1:0] read_data,
  output logic busy,
  output logic done,
  output logic error,
  output logic pivot_error,
  output logic overflow_error,
  output logic [31:0] cycles
);
  localparam int AW = $clog2(N);

  // RAM interfaces.
  logic a_we,b_we,c_we,d_we,x_we;
  logic [AW-1:0] a_waddr,b_waddr,c_waddr,d_waddr,x_waddr;
  logic [AW-1:0] a_raddr,b_raddr,c_raddr,d_raddr,x_raddr;
  logic signed [W-1:0] a_wdata,b_wdata,c_wdata,d_wdata,x_wdata;
  logic signed [W-1:0] a_q,b_q,c_q,d_q,x_q;

  wp03_bram_1r1w_c #(.W(W),.N(N),.AW(AW)) ram_a(.clk,.we(a_we),.waddr(a_waddr),.wdata(a_wdata),.raddr(a_raddr),.rdata(a_q));
  wp03_bram_1r1w_c #(.W(W),.N(N),.AW(AW)) ram_b(.clk,.we(b_we),.waddr(b_waddr),.wdata(b_wdata),.raddr(b_raddr),.rdata(b_q));
  wp03_bram_1r1w_c #(.W(W),.N(N),.AW(AW)) ram_c(.clk,.we(c_we),.waddr(c_waddr),.wdata(c_wdata),.raddr(c_raddr),.rdata(c_q));
  wp03_bram_1r1w_c #(.W(W),.N(N),.AW(AW)) ram_d(.clk,.we(d_we),.waddr(d_waddr),.wdata(d_wdata),.raddr(d_raddr),.rdata(d_q));
  wp03_bram_1r1w_c #(.W(W),.N(N),.AW(AW)) ram_x(.clk,.we(x_we),.waddr(x_waddr),.wdata(x_wdata),.raddr(x_raddr),.rdata(x_q));

  assign read_data = x_q;

  // Internal write requests for c', d', x.
  logic c_int_we,d_int_we,x_int_we;
  logic [AW-1:0] c_int_addr,d_int_addr,x_int_addr;
  logic signed [W-1:0] c_int_data,d_int_data,x_int_data;

  always_comb begin
    a_we = load_we && !busy && (load_sel==2'd0) && (load_addr < N-1);
    b_we = load_we && !busy && (load_sel==2'd1);
    c_we = (load_we && !busy && (load_sel==2'd2) && (load_addr < N-1)) || c_int_we;
    d_we = (load_we && !busy && (load_sel==2'd3)) || d_int_we;
    x_we = x_int_we;

    a_waddr = load_addr; b_waddr = load_addr;
    c_waddr = c_int_we ? c_int_addr : load_addr;
    d_waddr = d_int_we ? d_int_addr : load_addr;
    x_waddr = x_int_addr;
    a_wdata = load_data; b_wdata = load_data;
    c_wdata = c_int_we ? c_int_data : load_data;
    d_wdata = d_int_we ? d_int_data : load_data;
    x_wdata = x_int_data;
  end

  function automatic logic sub_overflow(
    input logic signed [W-1:0] u,
    input logic signed [W-1:0] v);
    logic signed [W:0] t;
    logic signed [W-1:0] lo;
    begin
      t = $signed(u) - $signed(v);
      lo = t[W-1:0];
      sub_overflow = (t != {lo[W-1],lo});
    end
  endfunction

  // Shared arithmetic units.
  logic mul_start,mul_done,mul_ovf;
  logic signed [W-1:0] mul_u,mul_v,mul_q;
  fx_multiplier_pipe_c #(.W(W),.FRAC(FRAC)) u_mul(.clk,.rst_n,.start(mul_start),.u(mul_u),.v(mul_v),.q(mul_q),.overflow(mul_ovf),.done(mul_done));

  logic div_start,div_busy,div_done,div_ovf,div_zero;
  logic signed [W-1:0] div_num,div_den,div_q;
  fx_divider_iterative_c #(.W(W),.FRAC(FRAC)) u_div(.clk,.rst_n,.start(div_start),.num(div_num),.den(div_den),.quotient(div_q),.busy(div_busy),.done(div_done),.overflow(div_ovf),.divzero(div_zero));

  typedef enum logic [5:0] {
    S_IDLE,
    S_INIT_REQ,S_INIT_WAIT1,S_INIT_WAIT2,S_INIT_CAP,
    S_INIT_C_DIV_START,S_INIT_C_DIV_WAIT,S_INIT_D_DIV_START,S_INIT_D_DIV_WAIT,
    S_FWD_PRE_REQ,S_FWD_PRE_WAIT1,S_FWD_PRE_WAIT2,S_FWD_PRE_CAP,
    S_FWD_PIV_MUL_START,S_FWD_PIV_MUL_WAIT,S_FWD_PIV_EVAL,
    S_FWD_CUR_REQ,S_FWD_CUR_WAIT1,S_FWD_CUR_WAIT2,S_FWD_CUR_CAP,
    S_FWD_NUM_MUL_START,S_FWD_NUM_MUL_WAIT,S_FWD_NUM_EVAL,
    S_FWD_C_DIV_START,S_FWD_C_DIV_WAIT,S_FWD_D_DIV_START,S_FWD_D_DIV_WAIT,
    S_BACK_LAST_REQ,S_BACK_LAST_WAIT1,S_BACK_LAST_WAIT2,S_BACK_LAST_CAP,
    S_BACK_REQ,S_BACK_WAIT1,S_BACK_WAIT2,S_BACK_CAP,
    S_BACK_MUL_START,S_BACK_MUL_WAIT,S_BACK_EVAL,
    S_FINISH,S_FAIL
  } state_t;
  state_t state;

  logic [AW-1:0] idx;
  logic signed [W-1:0] pivot;
  logic signed [W-1:0] a_hold,b_hold,c_hold,d_hold,dp_prev_hold,x_next_hold,num_hold;
  logic signed [W-1:0] pivot_candidate,num_candidate,back_candidate;

  // RAM read addresses. RAM output latency is two clocks; WAIT1/WAIT2 absorb it.
  always_comb begin
    a_raddr='0; b_raddr='0; c_raddr='0; d_raddr='0;
    x_raddr = busy ? '0 : read_addr;
    case(state)
      S_INIT_REQ,S_INIT_WAIT1,S_INIT_WAIT2,S_INIT_CAP: begin b_raddr='0; c_raddr='0; d_raddr='0; end
      S_FWD_PRE_REQ,S_FWD_PRE_WAIT1,S_FWD_PRE_WAIT2,S_FWD_PRE_CAP: begin
        a_raddr=idx-1'b1; b_raddr=idx; c_raddr=idx-1'b1; d_raddr=idx-1'b1;
      end
      S_FWD_CUR_REQ,S_FWD_CUR_WAIT1,S_FWD_CUR_WAIT2,S_FWD_CUR_CAP: begin c_raddr=idx; d_raddr=idx; end
      S_BACK_LAST_REQ,S_BACK_LAST_WAIT1,S_BACK_LAST_WAIT2,S_BACK_LAST_CAP: begin d_raddr=N-1; end
      S_BACK_REQ,S_BACK_WAIT1,S_BACK_WAIT2,S_BACK_CAP: begin
        c_raddr=idx; d_raddr=idx; x_raddr=idx+1'b1;
      end
      default: begin end
    endcase
  end

  always_comb begin
    mul_start=1'b0; mul_u='0; mul_v='0;
    case(state)
      S_FWD_PIV_MUL_START: begin mul_start=1'b1; mul_u=a_hold; mul_v=c_hold; end
      S_FWD_NUM_MUL_START: begin mul_start=1'b1; mul_u=a_hold; mul_v=dp_prev_hold; end
      S_BACK_MUL_START: begin mul_start=1'b1; mul_u=c_hold; mul_v=x_next_hold; end
      default: begin end
    endcase
  end

  always_comb begin
    div_start=1'b0; div_num='0; div_den=pivot;
    case(state)
      S_INIT_C_DIV_START: begin div_start=1'b1; div_num=c_hold; end
      S_INIT_D_DIV_START: begin div_start=1'b1; div_num=d_hold; end
      S_FWD_C_DIV_START: begin div_start=1'b1; div_num=c_hold; end
      S_FWD_D_DIV_START: begin div_start=1'b1; div_num=num_hold; end
      default: begin end
    endcase
  end

  always_comb begin
    pivot_candidate = $signed(b_hold) - $signed(mul_q);
    num_candidate   = $signed(d_hold) - $signed(mul_q);
    back_candidate  = $signed(d_hold) - $signed(mul_q);
  end

  always_comb begin
    c_int_we=1'b0; d_int_we=1'b0; x_int_we=1'b0;
    c_int_addr=idx; d_int_addr=idx; x_int_addr=idx;
    c_int_data=div_q; d_int_data=div_q; x_int_data=back_candidate;
    if(state==S_INIT_C_DIV_WAIT && div_done && !div_ovf && !div_zero) begin c_int_we=1'b1; c_int_addr='0; end
    if(state==S_INIT_D_DIV_WAIT && div_done && !div_ovf && !div_zero) begin d_int_we=1'b1; d_int_addr='0; end
    if(state==S_FWD_C_DIV_WAIT && div_done && !div_ovf && !div_zero) begin c_int_we=1'b1; c_int_addr=idx; end
    if(state==S_FWD_D_DIV_WAIT && div_done && !div_ovf && !div_zero) begin d_int_we=1'b1; d_int_addr=idx; end
    if(state==S_BACK_LAST_CAP) begin x_int_we=1'b1; x_int_addr=N-1; x_int_data=d_q; end
    if(state==S_BACK_EVAL && !mul_ovf && !sub_overflow(d_hold,mul_q)) begin x_int_we=1'b1; x_int_addr=idx; x_int_data=back_candidate; end
  end

  always_ff @(posedge clk) begin
    if(!rst_n) begin
      state<=S_IDLE; idx<='0; pivot<='0;
      a_hold<='0; b_hold<='0; c_hold<='0; d_hold<='0; dp_prev_hold<='0; x_next_hold<='0; num_hold<='0;
      busy<=1'b0; done<=1'b0; error<=1'b0; pivot_error<=1'b0; overflow_error<=1'b0; cycles<='0;
    end else begin
      done<=1'b0;
      if(busy) cycles<=cycles+1'b1;
      case(state)
        S_IDLE: begin
          busy<=1'b0;
          if(start) begin
            busy<=1'b1; cycles<='0; error<=1'b0; pivot_error<=1'b0; overflow_error<=1'b0; idx<='0; state<=S_INIT_REQ;
          end
        end
        S_INIT_REQ: state<=S_INIT_WAIT1;
        S_INIT_WAIT1: state<=S_INIT_WAIT2;
        S_INIT_WAIT2: state<=S_INIT_CAP;
        S_INIT_CAP: begin
          b_hold<=b_q; c_hold<=c_q; d_hold<=d_q;
          if((b_q<=pivot_tol)||(b_q<=0)) begin pivot_error<=1'b1; error<=1'b1; state<=S_FAIL; end
          else begin pivot<=b_q; if(N>1) state<=S_INIT_C_DIV_START; else state<=S_INIT_D_DIV_START; end
        end
        S_INIT_C_DIV_START: state<=S_INIT_C_DIV_WAIT;
        S_INIT_C_DIV_WAIT: if(div_done) begin
          if(div_ovf||div_zero) begin overflow_error<=1'b1; error<=1'b1; state<=S_FAIL; end
          else state<=S_INIT_D_DIV_START;
        end
        S_INIT_D_DIV_START: state<=S_INIT_D_DIV_WAIT;
        S_INIT_D_DIV_WAIT: if(div_done) begin
          if(div_ovf||div_zero) begin overflow_error<=1'b1; error<=1'b1; state<=S_FAIL; end
          else if(N==1) state<=S_BACK_LAST_REQ;
          else begin idx<=1; state<=S_FWD_PRE_REQ; end
        end

        S_FWD_PRE_REQ: state<=S_FWD_PRE_WAIT1;
        S_FWD_PRE_WAIT1: state<=S_FWD_PRE_WAIT2;
        S_FWD_PRE_WAIT2: state<=S_FWD_PRE_CAP;
        S_FWD_PRE_CAP: begin
          a_hold<=a_q; b_hold<=b_q; c_hold<=c_q; dp_prev_hold<=d_q;
          state<=S_FWD_PIV_MUL_START;
        end
        S_FWD_PIV_MUL_START: state<=S_FWD_PIV_MUL_WAIT;
        S_FWD_PIV_MUL_WAIT: if(mul_done) state<=S_FWD_PIV_EVAL;
        S_FWD_PIV_EVAL: begin
          if(mul_ovf||sub_overflow(b_hold,mul_q)) begin overflow_error<=1'b1; error<=1'b1; state<=S_FAIL; end
          else if((pivot_candidate<=pivot_tol)||(pivot_candidate<=0)) begin pivot_error<=1'b1; error<=1'b1; state<=S_FAIL; end
          else begin pivot<=pivot_candidate; state<=S_FWD_CUR_REQ; end
        end
        S_FWD_CUR_REQ: state<=S_FWD_CUR_WAIT1;
        S_FWD_CUR_WAIT1: state<=S_FWD_CUR_WAIT2;
        S_FWD_CUR_WAIT2: state<=S_FWD_CUR_CAP;
        S_FWD_CUR_CAP: begin c_hold<=c_q; d_hold<=d_q; state<=S_FWD_NUM_MUL_START; end
        S_FWD_NUM_MUL_START: state<=S_FWD_NUM_MUL_WAIT;
        S_FWD_NUM_MUL_WAIT: if(mul_done) state<=S_FWD_NUM_EVAL;
        S_FWD_NUM_EVAL: begin
          if(mul_ovf||sub_overflow(d_hold,mul_q)) begin overflow_error<=1'b1; error<=1'b1; state<=S_FAIL; end
          else begin num_hold<=num_candidate; if(idx<N-1) state<=S_FWD_C_DIV_START; else state<=S_FWD_D_DIV_START; end
        end
        S_FWD_C_DIV_START: state<=S_FWD_C_DIV_WAIT;
        S_FWD_C_DIV_WAIT: if(div_done) begin
          if(div_ovf||div_zero) begin overflow_error<=1'b1; error<=1'b1; state<=S_FAIL; end
          else state<=S_FWD_D_DIV_START;
        end
        S_FWD_D_DIV_START: state<=S_FWD_D_DIV_WAIT;
        S_FWD_D_DIV_WAIT: if(div_done) begin
          if(div_ovf||div_zero) begin overflow_error<=1'b1; error<=1'b1; state<=S_FAIL; end
          else if(idx==N-1) state<=S_BACK_LAST_REQ;
          else begin idx<=idx+1'b1; state<=S_FWD_PRE_REQ; end
        end

        S_BACK_LAST_REQ: state<=S_BACK_LAST_WAIT1;
        S_BACK_LAST_WAIT1: state<=S_BACK_LAST_WAIT2;
        S_BACK_LAST_WAIT2: state<=S_BACK_LAST_CAP;
        S_BACK_LAST_CAP: begin if(N==1) state<=S_FINISH; else begin idx<=N-2; state<=S_BACK_REQ; end end
        S_BACK_REQ: state<=S_BACK_WAIT1;
        S_BACK_WAIT1: state<=S_BACK_WAIT2;
        S_BACK_WAIT2: state<=S_BACK_CAP;
        S_BACK_CAP: begin c_hold<=c_q; d_hold<=d_q; x_next_hold<=x_q; state<=S_BACK_MUL_START; end
        S_BACK_MUL_START: state<=S_BACK_MUL_WAIT;
        S_BACK_MUL_WAIT: if(mul_done) state<=S_BACK_EVAL;
        S_BACK_EVAL: begin
          if(mul_ovf||sub_overflow(d_hold,mul_q)) begin overflow_error<=1'b1; error<=1'b1; state<=S_FAIL; end
          else if(idx==0) state<=S_FINISH;
          else begin idx<=idx-1'b1; state<=S_BACK_REQ; end
        end

        S_FINISH: begin busy<=1'b0; done<=1'b1; state<=S_IDLE; end
        S_FAIL: begin busy<=1'b0; done<=1'b1; state<=S_IDLE; end
        default: state<=S_IDLE;
      endcase
    end
  end
endmodule
