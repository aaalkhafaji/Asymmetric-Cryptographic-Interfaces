`timescale 1ns/1ps
// WP04 end-to-end integration.
// Authoritative ordering from frozen WP01:
// plaintext -> structural tridiagonal forward operator -> quantized structural word
// -> modular mask -> transmitted ciphertext; receiver unmask -> WP03 global solve.
module wp04_top #(
  parameter int W=32,
  parameter int FRAC=16,
  parameter int N=64,
  parameter int ID_W=32,
  parameter int PAD_HISTORY_DEPTH=16,
  parameter logic signed [W-1:0] PIVOT_TOL=32'sd16384
)(
  input logic clk,
  input logic rst_n,

  // Coefficient preload: sel 0=lower a[0..N-2], 1=diag b[0..N-1], 2=upper c[0..N-2].
  input logic cfg_we,
  input logic [1:0] cfg_sel,
  input logic [$clog2(N)-1:0] cfg_addr,
  input logic signed [W-1:0] cfg_data,

  // Block control and source/pad stream.
  input logic block_start,
  input logic [ID_W-1:0] block_id,
  input logic [ID_W-1:0] pad_id,
  input logic in_valid,
  output logic in_ready,
  input logic signed [W-1:0] plaintext_in,
  input logic [W-1:0] pad_in,

  // Transmitted representation observation.
  output logic tx_valid,
  output logic [$clog2(N)-1:0] tx_index,
  output logic [W-1:0] tx_data,

  // Authorized reconstructed plaintext stream.
  output logic out_valid,
  output logic [$clog2(N)-1:0] out_index,
  output logic signed [W-1:0] plaintext_out,
  output logic block_done,

  output logic busy,
  output logic block_rejected,
  output logic pad_reuse_error,
  output logic encoder_overflow_error,
  output logic decoder_error,
  output logic decoder_pivot_error,
  output logic decoder_overflow_error,
  output logic [31:0] decoder_cycles
);
  localparam int AW=$clog2(N);

  // Encoder-side coefficient copies. Decoder receives the same coefficients.
  (* ram_style="distributed" *) logic signed [W-1:0] a_mem[0:N-2];
  (* ram_style="distributed" *) logic signed [W-1:0] b_mem[0:N-1];
  (* ram_style="distributed" *) logic signed [W-1:0] c_mem[0:N-2];

  // Receiver-side captured ciphertext/pad. These are intentionally modeled as memories.
  (* ram_style="block" *) logic [W-1:0] cipher_mem[0:N-1];
  (* ram_style="block" *) logic [W-1:0] pad_mem[0:N-1];

  // Bounded experimental pad-ID history CAM. Reuse within the retained history is rejected.
  logic [ID_W-1:0] pad_hist[0:PAD_HISTORY_DEPTH-1];
  logic [$clog2(PAD_HISTORY_DEPTH+1)-1:0] pad_hist_count;
  integer hi;
  logic pad_seen;
  always_comb begin
    pad_seen=1'b0;
    for (hi=0; hi<PAD_HISTORY_DEPTH; hi=hi+1)
      if ((hi < pad_hist_count) && (pad_hist[hi] == pad_id)) pad_seen=1'b1;
  end

  typedef enum logic [3:0] {ST_IDLE,ST_CAPTURE,ST_FINAL,ST_WAIT_ENC,ST_UNMASK,
                            ST_DEC_START,ST_DEC_WAIT,ST_READ_REQ,ST_READ_W1,
                            ST_READ_W2,ST_READ_EMIT} state_t;
  state_t state;

  logic [AW-1:0] sample_count;
  logic signed [W-1:0] p_left,p_center;
  logic [W-1:0] pad_center;
  logic [AW:0] tx_count;
  logic [AW-1:0] unmask_idx;
  logic [AW-1:0] read_idx;
  logic [ID_W-1:0] active_block_id,active_pad_id;

  // Encoder request.
  logic enc_start;
  logic [AW-1:0] enc_idx;
  logic signed [W-1:0] enc_lower,enc_diag,enc_upper,enc_pl,enc_pc,enc_pr;
  logic [W-1:0] enc_pad;
  logic enc_valid,enc_ovf;
  logic [AW-1:0] enc_out_idx;
  logic signed [W-1:0] enc_struct;
  logic [W-1:0] enc_cipher;

  wp04_encoder #(.W(W),.FRAC(FRAC),.AW(AW)) u_encoder(
    .clk,.rst_n,.start(enc_start),.index_in(enc_idx),.lower(enc_lower),.diag(enc_diag),.upper(enc_upper),
    .p_left(enc_pl),.p_center(enc_pc),.p_right(enc_pr),.pad(enc_pad),
    .valid(enc_valid),.index_out(enc_out_idx),.structural(enc_struct),.ciphertext(enc_cipher),.overflow(enc_ovf));

  // Frozen WP03 decoder interface.
  logic dec_load_we;
  logic [1:0] dec_load_sel;
  logic [AW-1:0] dec_load_addr;
  logic signed [W-1:0] dec_load_data;
  logic dec_start,dec_busy,dec_done;
  logic [AW-1:0] dec_read_addr;
  logic signed [W-1:0] dec_read_data;

  tridiagonal_decoder #(.W(W),.FRAC(FRAC),.N(N)) u_decoder(
    .clk,.rst_n,
    .load_we(dec_load_we),.load_sel(dec_load_sel),.load_addr(dec_load_addr),.load_data(dec_load_data),
    .start(dec_start),.pivot_tol(PIVOT_TOL),.read_addr(dec_read_addr),.read_data(dec_read_data),
    .busy(dec_busy),.done(dec_done),.error(decoder_error),.pivot_error(decoder_pivot_error),
    .overflow_error(decoder_overflow_error),.cycles(decoder_cycles));

  always_comb begin
    in_ready = (state==ST_CAPTURE);
    busy = (state!=ST_IDLE);
    enc_start=1'b0; enc_idx='0; enc_lower='0; enc_diag='0; enc_upper='0;
    enc_pl='0; enc_pc='0; enc_pr='0; enc_pad='0;
    dec_load_we=1'b0; dec_load_sel='0; dec_load_addr='0; dec_load_data='0;
    dec_start=1'b0; dec_read_addr=read_idx;

    // Configuration loads are mirrored into frozen WP03 decoder while idle.
    if ((state==ST_IDLE) && cfg_we) begin
      dec_load_we=1'b1; dec_load_sel=cfg_sel; dec_load_addr=cfg_addr; dec_load_data=cfg_data;
    end

    // During capture, each new sample after the first completes one tridiagonal row.
    if ((state==ST_CAPTURE) && in_valid && in_ready && (sample_count!=0)) begin
      enc_start=1'b1;
      enc_idx=sample_count-1'b1;
      enc_pl=(sample_count==1) ? '0 : p_left;
      enc_pc=p_center;
      enc_pr=plaintext_in;
      enc_pad=pad_center;
      enc_lower=(sample_count==1) ? '0 : a_mem[sample_count-2];
      enc_diag=b_mem[sample_count-1];
      enc_upper=c_mem[sample_count-1];
    end

    // Final row uses the right Dirichlet boundary p_N=0.
    if (state==ST_FINAL) begin
      enc_start=1'b1;
      enc_idx=N-1;
      enc_pl=p_left;
      enc_pc=p_center;
      enc_pr='0;
      enc_pad=pad_center;
      enc_lower=a_mem[N-2];
      enc_diag=b_mem[N-1];
      enc_upper='0;
    end

    if (state==ST_UNMASK) begin
      dec_load_we=1'b1; dec_load_sel=2'd3; dec_load_addr=unmask_idx;
      dec_load_data=$signed(cipher_mem[unmask_idx] - pad_mem[unmask_idx]);
    end
    if (state==ST_DEC_START) dec_start=1'b1;
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state<=ST_IDLE; sample_count<='0; p_left<='0; p_center<='0; pad_center<='0;
      tx_count<='0; unmask_idx<='0; read_idx<='0;
      tx_valid<=1'b0; tx_index<='0; tx_data<='0;
      out_valid<=1'b0; out_index<='0; plaintext_out<='0; block_done<=1'b0;
      block_rejected<=1'b0; pad_reuse_error<=1'b0; encoder_overflow_error<=1'b0;
      pad_hist_count<='0; active_block_id<='0; active_pad_id<='0;
      for (hi=0;hi<PAD_HISTORY_DEPTH;hi=hi+1) pad_hist[hi]<='0;
    end else begin
      tx_valid<=1'b0; out_valid<=1'b0; block_done<=1'b0; block_rejected<=1'b0;

      // Keep encoder output observable and save ciphertext/pad pairing.
      if (enc_valid) begin
        tx_valid<=1'b1; tx_index<=enc_out_idx; tx_data<=enc_cipher;
        cipher_mem[enc_out_idx] <= enc_cipher;
        if (enc_ovf) encoder_overflow_error<=1'b1;
        tx_count<=tx_count+1'b1;
      end

      // Coefficient copies are only writable while idle.
      if ((state==ST_IDLE) && cfg_we) begin
        case (cfg_sel)
          2'd0: if (cfg_addr < N-1) a_mem[cfg_addr] <= cfg_data;
          2'd1: b_mem[cfg_addr] <= cfg_data;
          2'd2: if (cfg_addr < N-1) c_mem[cfg_addr] <= cfg_data;
          default: ;
        endcase
      end

      case (state)
        ST_IDLE: begin
          sample_count<='0; tx_count<='0; read_idx<='0; unmask_idx<='0;
          if (block_start) begin
            encoder_overflow_error<=1'b0; pad_reuse_error<=1'b0;
            if (pad_seen || (pad_hist_count==PAD_HISTORY_DEPTH)) begin
              block_rejected<=1'b1;
              pad_reuse_error<=pad_seen;
            end else begin
              active_block_id<=block_id; active_pad_id<=pad_id;
              pad_hist[pad_hist_count] <= pad_id;
              pad_hist_count <= pad_hist_count + 1'b1;
              state<=ST_CAPTURE;
            end
          end
        end
        ST_CAPTURE: begin
          if (in_valid && in_ready) begin
            pad_mem[sample_count] <= pad_in;
            if (sample_count==0) begin
              p_center<=plaintext_in; pad_center<=pad_in;
              sample_count<=1;
            end else begin
              p_left<=p_center; p_center<=plaintext_in; pad_center<=pad_in;
              if (sample_count==N-1) state<=ST_FINAL;
              else sample_count<=sample_count+1'b1;
            end
          end
        end
        ST_FINAL: state<=ST_WAIT_ENC;
        ST_WAIT_ENC: begin
          // tx_count reflects prior-cycle outputs; account for an output arriving now.
          if ((tx_count==N) || (enc_valid && (tx_count==N-1))) begin
            unmask_idx<='0; state<=ST_UNMASK;
          end
        end
        ST_UNMASK: begin
          if (unmask_idx==N-1) state<=ST_DEC_START;
          else unmask_idx<=unmask_idx+1'b1;
        end
        ST_DEC_START: state<=ST_DEC_WAIT;
        ST_DEC_WAIT: if (dec_done) begin read_idx<='0; state<=ST_READ_REQ; end
        ST_READ_REQ: state<=ST_READ_W1;
        ST_READ_W1: state<=ST_READ_W2;
        ST_READ_W2: state<=ST_READ_EMIT;
        ST_READ_EMIT: begin
          out_valid<=1'b1; out_index<=read_idx; plaintext_out<=dec_read_data;
          if (read_idx==N-1) begin block_done<=1'b1; state<=ST_IDLE; end
          else begin read_idx<=read_idx+1'b1; state<=ST_READ_REQ; end
        end
        default: state<=ST_IDLE;
      endcase
    end
  end
endmodule
