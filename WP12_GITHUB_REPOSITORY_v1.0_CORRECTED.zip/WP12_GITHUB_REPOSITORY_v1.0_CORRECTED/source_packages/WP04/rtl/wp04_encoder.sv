`timescale 1ns/1ps
// WP04 forward structural encoder + modular masking stage.
// Arithmetic: signed Q(W-FRAC).FRAC. Multiplication truncates toward zero,
// matching frozen WP03 arithmetic. Modular mask is bit-vector addition mod 2^W.
module wp04_encoder #(
  parameter int W=32,
  parameter int FRAC=16,
  parameter int AW=6
)(
  input  logic clk,
  input  logic rst_n,
  input  logic start,
  input  logic [AW-1:0] index_in,
  input  logic signed [W-1:0] lower,
  input  logic signed [W-1:0] diag,
  input  logic signed [W-1:0] upper,
  input  logic signed [W-1:0] p_left,
  input  logic signed [W-1:0] p_center,
  input  logic signed [W-1:0] p_right,
  input  logic [W-1:0] pad,
  output logic valid,
  output logic [AW-1:0] index_out,
  output logic signed [W-1:0] structural,
  output logic [W-1:0] ciphertext,
  output logic overflow
);
  logic signed [W-1:0] l_r,d_r,u_r,pl_r,pc_r,pr_r;
  logic [W-1:0] pad_r1,pad_r2,pad_r3;
  logic [AW-1:0] idx_r1,idx_r2,idx_r3;
  (* use_dsp = "yes" *) logic signed [2*W-1:0] prod_l,prod_d,prod_u;
  logic signed [2*W-1:0] scl_l,scl_d,scl_u;
  logic v1,v2,v3;

  function automatic logic signed [2*W-1:0] trunc_tz(input logic signed [2*W-1:0] x);
    logic signed [2*W-1:0] y;
    begin
      if (x < 0) y = -((-x) >>> FRAC);
      else       y = x >>> FRAC;
      trunc_tz = y;
    end
  endfunction

  logic signed [2*W+1:0] sum_ext;
  logic signed [W-1:0] sum_lo;
  always_comb begin
    sum_ext = $signed(scl_l) + $signed(scl_d) + $signed(scl_u);
    sum_lo = sum_ext[W-1:0];
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      l_r<='0; d_r<='0; u_r<='0; pl_r<='0; pc_r<='0; pr_r<='0;
      pad_r1<='0; pad_r2<='0; pad_r3<='0;
      idx_r1<='0; idx_r2<='0; idx_r3<='0;
      prod_l<='0; prod_d<='0; prod_u<='0;
      scl_l<='0; scl_d<='0; scl_u<='0;
      v1<=1'b0; v2<=1'b0; v3<=1'b0;
      valid<=1'b0; index_out<='0; structural<='0; ciphertext<='0; overflow<=1'b0;
    end else begin
      valid <= 1'b0;
      v1 <= start;
      v2 <= v1;
      v3 <= v2;
      if (start) begin
        l_r<=lower; d_r<=diag; u_r<=upper;
        pl_r<=p_left; pc_r<=p_center; pr_r<=p_right;
        pad_r1<=pad; idx_r1<=index_in;
      end
      if (v1) begin
        prod_l <= $signed(l_r) * $signed(pl_r);
        prod_d <= $signed(d_r) * $signed(pc_r);
        prod_u <= $signed(u_r) * $signed(pr_r);
        pad_r2 <= pad_r1; idx_r2 <= idx_r1;
      end
      if (v2) begin
        scl_l <= trunc_tz(prod_l);
        scl_d <= trunc_tz(prod_d);
        scl_u <= trunc_tz(prod_u);
        pad_r3 <= pad_r2; idx_r3 <= idx_r2;
      end
      if (v3) begin
        structural <= sum_lo;
        ciphertext <= $unsigned(sum_lo) + pad_r3; // modulo 2^W by truncation
        index_out <= idx_r3;
        overflow <= (sum_ext != {{(W+2){sum_lo[W-1]}},sum_lo});
        valid <= 1'b1;
      end
    end
  end
endmodule
