# WP04 — End-to-End RTL Integration (READY FOR VIVADO)

This package integrates the frozen WP01 mathematical ordering, frozen WP02 extractor/masking convention, and the frozen WP03 Architecture-C global tridiagonal decoder.

## Authoritative ordering
The frozen WP01 implementation defines:

`plaintext -> tridiagonal structural transform -> quantized structural word -> modular mask -> ciphertext`

Receiver:

`ciphertext -> modular unmask -> frozen WP03 global tridiagonal solver -> reconstructed plaintext`

This ordering supersedes any conceptual diagram that places masking before the structural operator.

## Included hardware
- `rtl/wp04_encoder.sv`: pipelined Q16.16 tridiagonal forward operator plus mod-2^32 masking.
- `rtl/wp04_top.sv`: block controller, coefficient loading, ciphertext/pad storage, unmasking, frozen WP03 decoder integration, output streaming, status signals, and bounded pad-ID reuse detector.
- `rtl/tridiagonal_decoder_wp03_frozen.sv`: copied unchanged from frozen WP03 Architecture C.

## Smoke configuration
The supplied golden vector uses `N=64`, `W=32`, `FRAC=16` and a 2048-bit Toeplitz extractor output from frozen WP02 packed into exactly 64 32-bit pad words.

The frozen WP02 default entropy declaration (`k=3072`, epsilon=2^-40) does **not** safely support a 4096-bit extracted pad, so extractor-backed `N=128` is intentionally not claimed at WP04. Final entropy/output sizing is deferred until WP08.

## Run in Vivado 2025.2
From the Tcl console:

```tcl
cd {C:/CWP04/WP04_End_to_End_RTL_Integration_READY}
set argv {64 results/smoke_N64}
source vivado/scripts/run_xsim_wp04.tcl
```

Expected final lines:

```text
WP04_PAD_REUSE_NEGATIVE_PASS
WP04_SUMMARY N=64 TX_MATCH=64 RX_MATCH=64 FAILURES=0 ...
WP04_PASS
WP04_XSIM_COMPLETE N=64
```

Do not run implementation until the XSim smoke test passes.

## After XSim passes
Run:

```tcl
close_project
cd {C:/CWP04/WP04_End_to_End_RTL_Integration_READY}
set argv {64}
source vivado/scripts/build_impl_wp04.tcl
```

WP04 is **not frozen yet**. It becomes frozen only after XSim end-to-end equivalence, repeated-pad rejection, and final implementation/report review pass.
