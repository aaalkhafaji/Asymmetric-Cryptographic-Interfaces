#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys, hashlib
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'reference_snapshots'))
import wp01_reference_pipeline_frozen as wp01
import wp02_frozen as wp02


def tz_div_int(num:int, den:int)->int:
    if den==0: raise ZeroDivisionError
    q=abs(num)//abs(den)
    return -q if (num<0) ^ (den<0) else q

def fx_mul(a:int,b:int,frac:int,w:int)->int:
    v=tz_div_int(a*b,1<<frac)
    lo=-(1<<(w-1)); hi=(1<<(w-1))-1
    if not (lo<=v<=hi): raise OverflowError(f'mul overflow {v}')
    return v

def fx_div(num:int,den:int,frac:int,w:int)->int:
    v=tz_div_int(num<<frac,den)
    lo=-(1<<(w-1)); hi=(1<<(w-1))-1
    if not (lo<=v<=hi): raise OverflowError(f'div overflow {v}')
    return v

def fx_sub(a:int,b:int,w:int)->int:
    v=a-b; lo=-(1<<(w-1)); hi=(1<<(w-1))-1
    if not (lo<=v<=hi): raise OverflowError(f'sub overflow {v}')
    return v

def quant_signed(x:np.ndarray,frac:int,w:int)->np.ndarray:
    z=np.rint(np.asarray(x,dtype=float)*(1<<frac)).astype(object)
    lo=-(1<<(w-1)); hi=(1<<(w-1))-1
    vals=np.array([int(v) for v in z],dtype=object)
    if any(v<lo or v>hi for v in vals): raise OverflowError('quantization overflow')
    return vals

def forward_fixed(a,b,c,p,frac,w):
    n=len(b); d=[]
    for i in range(n):
        s=fx_mul(int(b[i]),int(p[i]),frac,w)
        if i>0: s=fx_sub(s,-fx_mul(int(a[i-1]),int(p[i-1]),frac,w),w)  # s + term
        if i<n-1: s=fx_sub(s,-fx_mul(int(c[i]),int(p[i+1]),frac,w),w)
        d.append(s)
    return np.array(d,dtype=object)

def thomas_fixed(a,b,c,d,frac,w,pivot_tol):
    n=len(b)
    cp=[0]*n; dp=[0]*n
    if int(b[0])<=pivot_tol: raise ArithmeticError('pivot0')
    cp[0]=fx_div(int(c[0]),int(b[0]),frac,w) if n>1 else 0
    dp[0]=fx_div(int(d[0]),int(b[0]),frac,w)
    piv=[int(b[0])]
    for i in range(1,n):
        pivot=fx_sub(int(b[i]),fx_mul(int(a[i-1]),cp[i-1],frac,w),w)
        piv.append(pivot)
        if pivot<=pivot_tol: raise ArithmeticError(f'pivot{i}={pivot}')
        num=fx_sub(int(d[i]),fx_mul(int(a[i-1]),dp[i-1],frac,w),w)
        if i<n-1: cp[i]=fx_div(int(c[i]),pivot,frac,w)
        dp[i]=fx_div(num,pivot,frac,w)
    x=[0]*n; x[-1]=dp[-1]
    for i in range(n-2,-1,-1):
        x[i]=fx_sub(dp[i],fx_mul(cp[i],x[i+1],frac,w),w)
    return np.array(x,dtype=object),np.array(piv,dtype=object)

def uword(v:int,w:int)->int: return v & ((1<<w)-1)
def sword(v:int,w:int)->int:
    v &= (1<<w)-1
    return v-(1<<w) if v>=(1<<(w-1)) else v

def write_mem(path,vals,w):
    digits=(w+3)//4
    with open(path,'w') as f:
        for v in vals: f.write(f'{uword(int(v),w):0{digits}x}\n')

def sha256(p:Path): return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--N',type=int,default=64); ap.add_argument('--seed',type=int,default=20260905); ap.add_argument('--out',default=str(ROOT/'results/smoke_N64')); args=ap.parse_args()
    n=args.N; w=32; frac=16; scale=1<<frac; pivot_tol=16384
    if n<4: raise ValueError('N>=4 required')
    rng=np.random.default_rng(args.seed)
    # Frozen WP01 edge-wise operator convention, two interfaces / three positive regions.
    interfaces=[(n//3,0.42),(2*n//3,0.63)]
    A,edges=wp01.build_operator(n,region_betas=(1.7,0.8,1.25),interfaces=interfaces,normalized=True)
    af,bf,cf=np.diag(A,-1),np.diag(A),np.diag(A,1)
    a=quant_signed(af,frac,w); b=quant_signed(bf,frac,w); c=quant_signed(cf,frac,w)
    # Keep source magnitude moderate so WP04 validates integration, not overflow behavior.
    pf=rng.normal(0.0,0.02,n)
    p=quant_signed(pf,frac,w)
    d=forward_fixed(a,b,c,p,frac,w)

    # Use frozen WP02 extractor with a valid 2048-bit output and 32-bit packing.
    # This produces exactly 64 pad words for N=64. Entropy parameters remain provisional until WP08.
    if n*32>2048:
        raise ValueError('Current frozen WP02 default entropy/output supports at most N=64 32-bit pad words; use N<=64 for WP04 extractor-backed vectors.')
    cfg={"raw_bits":4096,"declared_min_entropy_bits":3072,"epsilon":2**-40,
         "requested_output_bits":2048,"pad_word_bits":32,"random_seed":args.seed,
         "source":{"type":"synthetic_bernoulli","p_one":0.5}}
    er=wp02.extract_pad(cfg,np.random.default_rng(args.seed ^ 0x5A17))
    pad=np.array([int(v) for v in er.pad_words[:n]],dtype=object)
    cipher=np.array([(uword(int(d[i]),w)+int(pad[i])) & ((1<<w)-1) for i in range(n)],dtype=object)
    unmasked=np.array([sword((int(cipher[i])-int(pad[i])) & ((1<<w)-1),w) for i in range(n)],dtype=object)
    assert all(int(unmasked[i])==int(d[i]) for i in range(n))
    recovered,piv=thomas_fixed(a,b,c,unmasked,frac,w,pivot_tol)

    out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    for name,vals in [('a.mem',a),('b.mem',b),('c.mem',c),('plaintext.mem',p),('pad.mem',pad),('structural_expected.mem',d),('cipher_expected.mem',cipher),('recovered_expected.mem',recovered)]: write_mem(out/name,vals,w)
    np.savez_compressed(out/'wp04_golden.npz',a=np.array(a,dtype=np.int64),b=np.array(b,dtype=np.int64),c=np.array(c,dtype=np.int64),plaintext=np.array(p,dtype=np.int64),pad=np.array(pad,dtype=np.uint64),structural=np.array(d,dtype=np.int64),cipher=np.array(cipher,dtype=np.uint64),recovered=np.array(recovered,dtype=np.int64),pivots=np.array(piv,dtype=np.int64),raw_bits=er.raw_bits,public_seed=er.public_seed,extracted_bits=er.extracted_bits)
    err_lsb=np.max(np.abs(np.array(recovered,dtype=np.int64)-np.array(p,dtype=np.int64)))
    meta={
      'wp':'WP04','status':'READY_FOR_XSIM','N':n,'W':w,'FRAC':frac,'seed':args.seed,'block_id':1,'pad_id':0xA5040001,
      'ordering':'plaintext -> tridiagonal structural operator -> modular mask; receiver unmask -> global tridiagonal solve',
      'wp02_extractor':{'raw_bits':4096,'declared_min_entropy_bits':3072,'epsilon':2**-40,'output_bits':2048,'pad_word_bits':32,'pad_words_available':int(er.pad_words.size),'note':'Entropy parameters are provisional until WP08; configuration is within frozen WP02 software gate.'},
      'fixed_point_reference':{'rounding_input_quantization':'numpy rint to Q16.16','multiply':'truncate toward zero','division':'truncate toward zero','masking':'mod 2^32'},
      'max_plaintext_to_recovered_difference_lsb':int(err_lsb),
      'min_fixed_point_pivot':int(min(piv)),'pivot_tol':pivot_tol,
      'golden_vector_sha256':sha256(out/'wp04_golden.npz')
    }
    (out/'metadata.json').write_text(json.dumps(meta,indent=2))
    print(json.dumps(meta,indent=2))

if __name__=='__main__': main()
