# Suggested Manuscript Integration Map

1. **Empirical Validation / Results opening**
   - Insert Table 1 (overall empirical validation overview).
   - Introduce the layered validation strategy.

2. **Global decoder subsection**
   - Insert Table 2.
   - Report 10,000/10,000, 0 failures, 0 LSB mismatch.

3. **Complete FPGA implementation subsection**
   - Replace the old forward-only hardware headline with Table 3 and Table 4.
   - Insert Fig. 1 and Fig. 2.
   - Report N=64 @ 130.005 MHz as the principal complete implementation.

4. **Robustness subsection**
   - Insert Table 5.
   - State 10/10 conditions and 8,960 exact checks.

5. **Ablation subsection**
   - Insert Table 6 and Fig. 3.
   - Insert Table 7 and Fig. 4.
   - Summarize masking ablation with Table 8.

6. **Discussion**
   - Use the limitations file verbatim as the factual boundary for claims.
   - Do not state physical entropy characterization.

7. **Conclusion**
   - Update the older statement that inverse-IIM hardware remains future work; the receiver/global decoder is now implemented and verified.
