# Critical Replacement Notes for the Existing Manuscript

The older manuscript/hardware section contains forward-core-only FPGA results that are now superseded by the completed end-to-end campaign.

Replace or revise empirical statements based on the older values:
- 385 LUTs / 304 registers
- 12 DSP48E1
- 120.48 MHz
- 0.127 W estimated power
- 4-cycle forward-core latency
- future work stating that the inverse receiver datapath remains to be implemented

Those numbers describe the earlier forward SPDE-IIM encryption core, not the completed end-to-end architecture.

For the revised manuscript, the primary end-to-end hardware result should be:
- Artix-7 XC7A100T-CSG324-1
- Vivado 2025.2
- signed Q16.16
- N = 64
- 130.005 MHz validated routed timing
- WNS = +0.157 ns
- 3,614 LUTs
- 132 LUTRAMs
- 6,079 registers
- 5 RAMB18
- 16 DSP48E1
- Vivado estimated total power = 0.159 W
- end-to-end block latency = 8,641 cycles ≈ 66.47 us at 130.005 MHz
- TX effective II = 1 cycle

The older forward-only result may be retained only if explicitly labeled as an earlier/smaller forward-core baseline, not as the main complete implementation.
