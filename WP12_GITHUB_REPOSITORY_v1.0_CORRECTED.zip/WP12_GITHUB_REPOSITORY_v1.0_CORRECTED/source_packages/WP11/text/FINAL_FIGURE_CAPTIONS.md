# Final Figure Captions

**Fig. 1. FPGA resource scaling at 100 MHz.** Post-route LUT and flip-flop utilization for the complete end-to-end architecture at N = 16, 32, and 64 on the Artix-7 XC7A100T-CSG324-1. The moderate growth with N reflects the resource-shared implementation strategy.

**Fig. 2. End-to-end latency scaling.** Measured RTL block latency and decoder latency in clock cycles for N = 16, 32, and 64. Both quantities scale approximately linearly with problem size.

**Fig. 3. Interface-aware reconstruction ablation.** Mean relative L2 reconstruction error for the proposed interface-aware operator and an ordinary interface-unaware stencil over four contrast conditions. The interface-aware formulation remains near numerical precision while the ordinary stencil degrades as contrast increases.

**Fig. 4. Fixed-point precision sensitivity.** Mean and maximum relative L2 reconstruction error for Q24.8, Q20.12, and Q16.16 across 500 cases per format. Q16.16 provides the lowest observed reconstruction error among the tested formats.

**Fig. 5. Scale of the empirical verification campaign.** Number of randomized systems, exact word comparisons, robustness checks, and masking words exercised in the major validation campaigns.
