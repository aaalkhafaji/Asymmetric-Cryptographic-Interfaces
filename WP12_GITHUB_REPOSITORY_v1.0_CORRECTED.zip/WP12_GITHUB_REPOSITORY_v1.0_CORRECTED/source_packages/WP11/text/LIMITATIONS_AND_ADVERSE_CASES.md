# Limitations and Adverse Cases

- No physical entropy source was included in the final experimental scope; WP07/WP08 were omitted by agreement.
- Therefore no physical min-entropy, temperature, gain, exposure, sensor-session, or multi-device entropy claims are made.
- Vivado power values are implementation estimates, not measured board power.
- The retained validated N=64 routed clock is 130.005 MHz. A higher 133.3 MHz trial did not meet timing, so 130.005 MHz is the appropriate validated point to report.
- Lower-precision formats showed substantial numerical degradation, particularly Q24.8.
- The ordinary interface-unaware stencil baseline degraded strongly with increasing contrast; this is a useful adverse comparative result rather than something to hide.
- The prior forward-only FPGA core remains useful only as a smaller hardware baseline; it must not be confused with the complete end-to-end implementation.
