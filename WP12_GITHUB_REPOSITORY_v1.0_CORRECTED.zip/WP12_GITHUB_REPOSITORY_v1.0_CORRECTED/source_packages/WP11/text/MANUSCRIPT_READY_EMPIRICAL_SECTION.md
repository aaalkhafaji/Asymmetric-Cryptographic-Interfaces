# Manuscript-Ready Empirical Results Section

## Empirical Validation and FPGA Realization

The empirical campaign was designed as a sequence of independent validation layers, beginning with a reference implementation and progressing through RTL equivalence, large-scale randomized testing, FPGA implementation, robustness analysis, and controlled ablations. The central objective was to verify that the implemented architecture realizes the intended interface-aware transform, modular masking path, and global tridiagonal reconstruction without introducing hardware-specific numerical discrepancies.

### Global decoder verification

The fixed-point tridiagonal decoder was verified using 10,000 randomized valid systems spanning N = 16, 32, 64, and 128. All 10,000 systems passed, with zero observed failures and a maximum RTL/reference mismatch of 0 LSB. The final Architecture C implementation required 955 LUTs, 612 registers, five RAMB18 blocks, and four DSP48E1 slices, and achieved post-route timing closure at 100 MHz with WNS = +2.002 ns. Vivado post-implementation estimated total power was 0.139 W.

### End-to-end randomized verification

The complete encoder–masking–decoder architecture was subjected to a large-scale end-to-end randomized campaign consisting of 100 XSim groups and 1,600 valid N = 64 blocks. Across the full campaign, 102,400 transmitter outputs and 102,400 reconstructed receiver outputs were compared against independently generated reference vectors, yielding 204,800 exact word-level comparisons with zero failures. In addition, all 100 deliberate repeated-pad negative tests were correctly rejected.

### FPGA scaling and timing characterization

The complete Q16.16 architecture was synthesized, placed, and routed in Vivado 2025.2 for an Artix-7 XC7A100T-CSG324-1 device. At a 100 MHz target clock, timing closure was achieved for N = 16, 32, and 64 with WNS values of +1.445 ns, +1.520 ns, and +1.228 ns, respectively. Resource utilization increased from 2,478 LUTs and 2,749 registers at N = 16 to 3,536 LUTs and 5,861 registers at N = 64, while RAMB18 and DSP48E1 usage remained fixed at five and sixteen blocks, respectively.

An explicit routed frequency sweep was used for the principal N = 64 configuration. The design achieved timing closure at 130.005 MHz (7.692 ns) with WNS = +0.157 ns. At this operating point, the implementation used 3,614 LUTs, 132 LUTRAMs, 6,079 registers, five RAMB18 blocks, and sixteen DSP48E1 slices. Vivado estimated total on-chip power was 0.159 W, consisting of 0.068 W dynamic and 0.091 W static power.

The measured RTL block latencies were 2,113, 4,289, and 8,641 cycles for N = 16, 32, and 64, respectively. At 130.005 MHz, the N = 64 block latency corresponds to approximately 66.47 microseconds. The transmitter maintains an effective initiation interval of one cycle.

### Controlled robustness

Controlled robustness was evaluated across ten conditions: baseline, low and high interface contrast, boundary-adjacent interfaces, closely spaced interfaces, low and high plaintext amplitude, and N = 16, 32, and 64. All ten conditions passed. The campaign comprised 8,960 exact word-level comparisons with zero failures, and all ten repeated-pad negative tests passed.

### Ablation studies

A 400-case N = 64 ablation compared the interface-aware formulation with an ordinary interface-unaware stencil. The interface-aware method achieved a mean relative L2 reconstruction error of 8.58e-15, whereas the ordinary stencil produced a mean relative L2 error of 0.211. The ordinary-stencil error increased with contrast, from 0.015 under the weakest condition to 0.447 under the highest-contrast condition, while the interface-aware formulation remained near numerical precision.

A 500-case-per-format precision study yielded mean relative L2 errors of 9.92 for Q24.8, 0.1468 for Q20.12, and 9.05e-3 for Q16.16. This result supports the Q16.16 representation selected for the final FPGA implementation.

Finally, the modular masking path was tested over 2,000 blocks comprising 128,000 32-bit words. Every word was recovered exactly after unmasking, while all 128,000 masked words differed from their corresponding unmasked inputs in the tested campaign.

### Scope and limitations

The reported robustness experiments characterize algorithmic, numerical, and RTL behavior under controlled parameter variation. Physical entropy acquisition and environmental sensor characterization were not part of the final experimental scope. Accordingly, the empirical results do not claim physical min-entropy, temperature robustness, gain/exposure robustness, or direct board-level power measurement. All power values reported here are Vivado post-implementation estimates.
