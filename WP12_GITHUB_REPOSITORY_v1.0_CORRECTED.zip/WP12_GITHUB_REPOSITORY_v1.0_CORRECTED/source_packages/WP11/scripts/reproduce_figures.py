from pathlib import Path
import csv, json
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
CSV=ROOT/"tables/csv"
FIG=ROOT/"figures"

def rows(name):
    with (CSV/name).open(newline="",encoding="utf-8") as f:
        return list(csv.DictReader(f))

# Fig 1
r=[x for x in rows("Table_3_FPGA_Scaling.csv") if float(x["clock_mhz"])==100.0]
N=[int(x["N"]) for x in r]
plt.figure(figsize=(7.2,4.6))
plt.plot(N,[int(x["lut"]) for x in r],marker="o",label="LUT")
plt.plot(N,[int(x["ff"]) for x in r],marker="s",label="FF")
plt.xlabel("Problem size N"); plt.ylabel("Resources used"); plt.title("FPGA Resource Scaling at 100 MHz")
plt.legend(); plt.grid(True,alpha=.25); plt.tight_layout()
plt.savefig(FIG/"Fig_1_FPGA_Resource_Scaling.png",dpi=300); plt.close()

# Fig 2
plt.figure(figsize=(7.2,4.6))
plt.plot(N,[int(x["block_cycles"]) for x in r],marker="o",label="Block latency")
plt.plot(N,[int(x["decoder_cycles"]) for x in r],marker="s",label="Decoder latency")
plt.xlabel("Problem size N"); plt.ylabel("Cycles"); plt.title("Latency Scaling of the End-to-End Architecture")
plt.legend(); plt.grid(True,alpha=.25); plt.tight_layout()
plt.savefig(FIG/"Fig_2_Latency_Scaling.png",dpi=300); plt.close()

# Fig 3
a=rows("Table_6_Interface_Ablation.csv"); labs=[x["contrast"] for x in a]; xx=range(len(a))
plt.figure(figsize=(7.2,4.6))
plt.semilogy(xx,[float(x["interface_aware_mean_rel_l2"]) for x in a],marker="o",label="Interface-aware")
plt.semilogy(xx,[float(x["ordinary_mean_rel_l2"]) for x in a],marker="s",label="Ordinary stencil")
plt.xticks(list(xx),labs); plt.xlabel("Interface contrast condition"); plt.ylabel("Mean relative L2 error")
plt.title("Interface-Aware vs Ordinary-Stencil Reconstruction"); plt.legend(); plt.grid(True,alpha=.25); plt.tight_layout()
plt.savefig(FIG/"Fig_3_Interface_Ablation.png",dpi=300); plt.close()

# Fig 4
p=rows("Table_7_Precision_Ablation.csv"); xx=range(len(p))
plt.figure(figsize=(7.2,4.6))
plt.semilogy(xx,[float(x["mean_rel_l2"]) for x in p],marker="o",label="Mean relative L2")
plt.semilogy(xx,[float(x["max_rel_l2"]) for x in p],marker="s",label="Max relative L2")
plt.xticks(list(xx),[x["precision"] for x in p]); plt.xlabel("Fixed-point format"); plt.ylabel("Relative L2 error")
plt.title("Precision Sensitivity"); plt.legend(); plt.grid(True,alpha=.25); plt.tight_layout()
plt.savefig(FIG/"Fig_4_Precision_Ablation.png",dpi=300); plt.close()

# Fig 5
campaigns=["WP03 systems","WP05 word checks","WP09 word checks","WP10 mask words"]
counts=[10000,204800,8960,128000]
plt.figure(figsize=(7.2,4.6)); plt.bar(campaigns,counts); plt.ylabel("Verified items / comparisons")
plt.title("Scale of the Empirical Verification Campaign"); plt.xticks(rotation=20,ha="right"); plt.tight_layout()
plt.savefig(FIG/"Fig_5_Verification_Scale.png",dpi=300); plt.close()

print("WP11_FIGURES_REPRODUCED")
