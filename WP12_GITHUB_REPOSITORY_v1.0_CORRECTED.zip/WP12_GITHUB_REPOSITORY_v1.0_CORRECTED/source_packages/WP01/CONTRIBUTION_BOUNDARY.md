# Contribution Boundary and Provenance

This assignment bundle implements or validates the **empirical/reproducibility layer** of the TIFS manuscript.

## Protected theoretical core
The following are attributed in the manuscript to **Adnan H. Abdulwahid** and should not be rewritten, re-derived, re-attributed, or materially altered by the assignee without the corresponding author's approval:

- conceptualization and mathematical methodology;
- SPDE/interface model and threat-model formulation;
- immersed-interface operator formulation;
- invertibility and spectral-stability analysis;
- leakage, privacy-amplification, and finite-group secrecy theorems;
- algorithmic formulation and original draft.

## Empirical-assignment scope
Faycal Znidi, Ram C. Neupane, and Elgaddafi Elamami are assigned empirical validation / implementation / experimental investigation / empirical reporting tasks. A coauthor should claim only the code, measurements, experiments, implementation, verification, or reporting they actually perform.

## Change-control rule
If an empirical result appears to contradict a theorem assumption or requires a theory change, **do not silently edit the theorem**. Record the issue in `handoff/ISSUES_FOR_CORRESPONDING_AUTHOR.md` with the exact dataset/run identifier, observation, and proposed question.
