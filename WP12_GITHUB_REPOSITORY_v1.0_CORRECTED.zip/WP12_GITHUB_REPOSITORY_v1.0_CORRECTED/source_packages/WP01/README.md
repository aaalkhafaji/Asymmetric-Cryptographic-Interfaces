# WP01 v2 COMPLETE — End-to-End Reference Implementation

This package is the completed Python/NumPy reference implementation for the frozen conservative interface assembly used by WP01 and later WP03 RTL validation.

**Authoritative mathematics:** `docs/MATHEMATICAL_ASSEMBLY_SPEC.md`  
**Completion report:** `COMPLETION_REPORT.md`  
**Status:** `handoff/STATUS.md`

## What is included

- edge-wise conservative interface transmissibility assembly;
- normalized symmetric positive-definite tridiagonal matrix `A=h^2B`;
- configurable source generation/loading;
- structural forward transform;
- configurable fixed-point quantization;
- injected pad interface and exact modular masking/unmasking;
- global Thomas tridiagonal solve;
- reconstruction-error reporting;
- 100,000-word modular validation;
- 120 randomized float solver comparisons against NumPy;
- fixed-point precision/conditioning sweep;
- 120 randomized end-to-end golden-vector blocks;
- stress-range validation;
- runtime scaling through N=4096;
- CSV/NPZ data, figures, logs, random seeds, software versions, and SHA-256 hashes.

## Reproduce the deterministic reference experiment

```bash
python scripts/run_reference_experiment.py \
  --config configs/default_reference.json \
  --out results/reference_example
```

The source can also be loaded from CSV or NPY by changing `source.mode` and `source.path` in the JSON configuration.

## Run the frozen self-test

```bash
python scripts/reference_pipeline.py --self-test --out results/starter_self_test
```

## Re-run the complete acceptance campaign

```bash
python scripts/wp01_complete_campaign.py --out results/WP01_COMPLETE
```

## Pad/extractor boundary

WP01 deliberately uses a synthetic uniform injected pad to exercise the cryptographic interface and modular arithmetic. It does **not** claim that this pad came from a validated physical entropy source. WP02 will implement/finalize privacy amplification after WP07/WP08 provide the measured min-entropy basis.

## Do not use superseded vectors

Any earlier vector based on modifying only one interface-adjacent row is obsolete. This package uses only the frozen edge-wise shared-transmissibility convention in `docs/MATHEMATICAL_ASSEMBLY_SPEC.md`.
