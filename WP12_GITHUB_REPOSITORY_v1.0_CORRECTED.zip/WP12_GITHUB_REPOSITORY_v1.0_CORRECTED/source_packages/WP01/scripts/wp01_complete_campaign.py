#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, os, platform, sys, time
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import reference_pipeline as rp

try:
    import matplotlib.pyplot as plt
except Exception:
    plt = None

MASTER_SEED = 20260904


def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write_csv(path: Path, rows, fieldnames):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w', newline='') as f:
        w=csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader(); w.writerows(rows)


def tridiag_from_edges(w):
    w=np.asarray(w,float); n=len(w)-1
    a=-w[1:n].copy(); b=w[:n]+w[1:n+1]; c=-w[1:n].copy()
    return a,b,c


def matvec_tridiag(a,b,c,x):
    y=b*x
    if len(x)>1:
        y[1:]+=a*x[:-1]; y[:-1]+=c*x[1:]
    return y


def thomas_fast(a,b,c,d,pivot_tol=0.0):
    a=np.asarray(a,float); b=np.asarray(b,float).copy(); c=np.asarray(c,float); d=np.asarray(d,float).copy()
    n=len(b); piv=np.empty(n,float); piv[0]=b[0]
    if piv[0] <= pivot_tol: raise ArithmeticError('pivot 0 below tolerance')
    for i in range(1,n):
        m=a[i-1]/b[i-1]
        b[i]-=m*c[i-1]; d[i]-=m*d[i-1]; piv[i]=b[i]
        if piv[i] <= pivot_tol: raise ArithmeticError(f'pivot {i} below tolerance')
    x=np.empty(n,float); x[-1]=d[-1]/b[-1]
    for i in range(n-2,-1,-1): x[i]=(d[i]-c[i]*x[i+1])/b[i]
    return x,piv


def random_case(rng, n=None, num_interfaces=None, beta_lo=.5, beta_hi=2.0, theta_lo=1/16, theta_hi=15/16):
    if n is None: n=int(rng.choice([16,32,64,128]))
    if num_interfaces is None: num_interfaces=int(rng.integers(1,4))
    # distinct interior edges, leave room from external boundary edges
    edges=np.sort(rng.choice(np.arange(1,n),size=num_interfaces,replace=False))
    thetas=rng.uniform(theta_lo,theta_hi,size=num_interfaces)
    betas=np.exp(rng.uniform(np.log(beta_lo),np.log(beta_hi),size=num_interfaces+1))
    interfaces=[(int(k),float(t)) for k,t in zip(edges,thetas)]
    w=rp.edge_weights_from_regions(n,betas,interfaces)
    a,b,c=tridiag_from_edges(w)
    return betas,interfaces,w,a,b,c


def validate_masking(out, rng, nwords=100_000, q=32):
    words=rng.integers(0,1<<q,size=nwords,dtype=np.uint64)
    keys=rng.integers(0,1<<q,size=nwords,dtype=np.uint64)
    cipher=rp.mask(words,keys,q); rec=rp.unmask(cipher,keys,q)
    mismatches=int(np.count_nonzero(words!=rec))
    result={'n_words':nwords,'q_bits':q,'mismatches':mismatches,'recovery_rate':float(1-mismatches/nwords),'pass':mismatches==0}
    (out/'mask_unmask_100k.json').write_text(json.dumps(result,indent=2))
    return result


def validate_float_solver(out, rng, cases=120):
    rows=[]; maxerr=0.0; pivot_viol=0; spd_fail=0; sym_fail=0
    for i in range(cases):
        n=int(rng.choice([16,32,64,128])); betas,interfaces,w,a,b,c=random_case(rng,n=n)
        A=rp.assemble_A_from_edges(w)
        rhs=rng.normal(size=n)
        xt,piv=thomas_fast(a,b,c,rhs); xd=np.linalg.solve(A,rhs)
        err=float(np.max(np.abs(xt-xd))); maxerr=max(maxerr,err)
        sym=bool(np.allclose(A,A.T,atol=0,rtol=0)); spd=bool(np.min(np.linalg.eigvalsh(A))>0)
        pivot_ok=bool(np.all(piv > np.min(w)-1e-12))
        if not pivot_ok:pivot_viol+=1
        if not spd:spd_fail+=1
        if not sym:sym_fail+=1
        rows.append({'case':i,'seed_stream':'master','N':n,'interfaces':len(interfaces),'min_w':float(np.min(w)),'min_pivot':float(np.min(piv)),'max_abs_error_vs_numpy':err,'symmetric':sym,'spd':spd,'pivot_bound_ok':pivot_ok})
    write_csv(out/'float_solver_vs_numpy.csv',rows,list(rows[0].keys()))
    result={'cases':cases,'max_abs_error_vs_numpy':maxerr,'tolerance':1e-10,'pivot_bound_violations':pivot_viol,'spd_failures':spd_fail,'symmetry_failures':sym_fail,'pass':maxerr<=1e-10 and pivot_viol==0 and spd_fail==0 and sym_fail==0}
    (out/'float_solver_summary.json').write_text(json.dumps(result,indent=2))
    return result


def fixed_point_sweep(out, rng):
    configs=[(16,8),(20,10),(24,12),(28,14),(32,16),(40,24)]
    rows=[]
    for q,frac in configs:
        for n in [16,32,64,128]:
            for rep in range(8):
                betas,interfaces,w,a,b,c=random_case(rng,n=n)
                P=rng.normal(0,.03,n); S=matvec_tridiag(a,b,c,P)
                try:
                    X,scale=rp.quantize_to_words(S,q,frac)
                    Sq=rp.words_to_signed(X,q,scale); Ph,_=thomas_fast(a,b,c,Sq)
                    err=float(np.max(np.abs(P-Ph))); rel=float(np.linalg.norm(P-Ph)/(np.linalg.norm(P)+1e-30)); overflow=False
                except OverflowError:
                    err=float('nan'); rel=float('nan'); overflow=True
                A=rp.assemble_A_from_edges(w)
                cond=float(np.linalg.cond(A))
                rows.append({'q_bits':q,'frac_bits':frac,'N':n,'rep':rep,'interfaces':len(interfaces),'condition_number_2':cond,'max_abs_reconstruction_error':err,'relative_l2_error':rel,'overflow':overflow})
    write_csv(out/'fixed_point_error_vs_precision_conditioning.csv',rows,list(rows[0].keys()))
    valid=[r for r in rows if not r['overflow']]
    summ=[]
    for q,frac in configs:
        rr=[r for r in valid if r['q_bits']==q and r['frac_bits']==frac]
        summ.append({'q_bits':q,'frac_bits':frac,'cases':len(rr),'overflow_cases':sum(r['overflow'] for r in rows if r['q_bits']==q and r['frac_bits']==frac),'median_max_abs_error':float(np.median([r['max_abs_reconstruction_error'] for r in rr])),'max_max_abs_error':float(np.max([r['max_abs_reconstruction_error'] for r in rr])),'median_relative_l2_error':float(np.median([r['relative_l2_error'] for r in rr]))})
    write_csv(out/'fixed_point_precision_summary.csv',summ,list(summ[0].keys()))
    return rows,summ


def e2e_randomized(out, rng, cases=120, q=32, frac=16):
    gdir=out/'golden_vectors'; gdir.mkdir(parents=True,exist_ok=True)
    rows=[]; failures=0
    for i in range(cases):
        case_seed=int(rng.integers(0,2**63-1)); crng=np.random.default_rng(case_seed)
        n=int(crng.choice([16,32,64,128])); betas,interfaces,w,a,b,c=random_case(crng,n=n)
        P=crng.normal(0,.03,n); S=matvec_tridiag(a,b,c,P)
        X,scale=rp.quantize_to_words(S,q,frac)
        K=crng.integers(0,1<<q,size=n,dtype=np.uint64); Y=rp.mask(X,K,q); X2=rp.unmask(Y,K,q)
        modular_exact=bool(np.array_equal(X,X2)); Sq=rp.words_to_signed(X2,q,scale); Ph,piv=thomas_fast(a,b,c,Sq)
        err=float(np.max(np.abs(P-Ph))); rel=float(np.linalg.norm(P-Ph)/(np.linalg.norm(P)+1e-30))
        A=rp.assemble_A_from_edges(w); inv_inf=float(np.linalg.norm(np.linalg.inv(A),ord=np.inf)); lsb=1.0/scale
        quant_bound=inv_inf*0.5*lsb*(1+1e-10)
        passed=modular_exact and err<=quant_bound+1e-12 and np.min(piv)>np.min(w)-1e-12
        if not passed: failures+=1
        # machine-readable full golden vector: every randomized E2E case
        npz=gdir/f'case_{i:03d}_seed_{case_seed}.npz'
        np.savez_compressed(npz, seed=np.array([case_seed],dtype=np.uint64), N=np.array([n]), betas=betas, interface_edges=np.array([k for k,_ in interfaces],dtype=np.int64), interface_thetas=np.array([t for _,t in interfaces]), edge_weights=w, lower=a, diag=b, upper=c, plaintext=P, structural_float=S, structural_words=X, pad=K, ciphertext=Y, structural_recovered=Sq, plaintext_recovered=Ph, pivots=piv, q=np.array([q]), frac=np.array([frac]))
        # CSV companion with row-wise core vector data
        csvp=gdir/f'case_{i:03d}_seed_{case_seed}.csv'
        with csvp.open('w',newline='') as f:
            cw=csv.writer(f); cw.writerow(['index','plaintext','structural_float','structural_word','pad','ciphertext','structural_recovered','plaintext_recovered'])
            for j in range(n): cw.writerow([j,P[j],S[j],int(X[j]),int(K[j]),int(Y[j]),Sq[j],Ph[j]])
        rows.append({'case':i,'seed':case_seed,'N':n,'interfaces':len(interfaces),'q_bits':q,'frac_bits':frac,'min_w':float(np.min(w)),'min_pivot':float(np.min(piv)),'condition_number_2':float(np.linalg.cond(A)),'max_abs_error':err,'relative_l2_error':rel,'theoretical_quantization_error_bound_inf':quant_bound,'mask_unmask_exact':modular_exact,'pass':passed,'npz':npz.name,'npz_sha256':sha256(npz),'csv':csvp.name,'csv_sha256':sha256(csvp)})
    write_csv(out/'randomized_e2e_120.csv',rows,list(rows[0].keys()))
    result={'cases':cases,'q_bits':q,'frac_bits':frac,'failures':failures,'max_abs_error':float(max(r['max_abs_error'] for r in rows)),'max_relative_l2_error':float(max(r['relative_l2_error'] for r in rows)),'all_mask_unmask_exact':all(r['mask_unmask_exact'] for r in rows),'all_within_declared_quantization_bound':all(r['max_abs_error']<=r['theoretical_quantization_error_bound_inf']+1e-12 for r in rows),'pass':failures==0}
    (out/'randomized_e2e_summary.json').write_text(json.dumps(result,indent=2))
    return result,rows


def stress_tests(out,rng,cases=80,q=32,frac=16):
    rows=[]
    for i in range(cases):
        n=int(rng.choice([16,32,64,128])); ni=int(rng.integers(1,4))
        # theta concentrated near either edge for half the cases
        if i%2==0:
            tiny=2**-10; theta_lo=tiny; theta_hi=min(0.02,15/16)
            # custom generate theta then mirror randomly
            edges=np.sort(rng.choice(np.arange(1,n),size=ni,replace=False)); betas=np.exp(rng.uniform(np.log(.25),np.log(4),size=ni+1)); ts=[]
            for _ in range(ni):
                t=float(rng.uniform(tiny,.02)); ts.append(t if rng.random()<.5 else 1-t)
            interfaces=[(int(k),t) for k,t in zip(edges,ts)]; w=rp.edge_weights_from_regions(n,betas,interfaces); a,b,c=tridiag_from_edges(w)
        else:
            betas,interfaces,w,a,b,c=random_case(rng,n=n,num_interfaces=ni,beta_lo=.25,beta_hi=4,theta_lo=2**-10,theta_hi=1-2**-10)
        P=rng.normal(0,.03,n); S=matvec_tridiag(a,b,c,P)
        status='PASS'; err=None
        try:
            X,scale=rp.quantize_to_words(S,q,frac); Sq=rp.words_to_signed(X,q,scale)
            wq=np.rint(w*scale)/scale; pivot_tol=max(8/scale,0.5*float(np.min(wq)))
            Ph,piv=thomas_fast(a,b,c,Sq,pivot_tol=0.0)
            # Float model reports whether proposed RTL guard would reject; do not apply to authoritative mathematical solve.
            guard_reject=bool(np.min(piv)<=pivot_tol)
            err=float(np.max(np.abs(P-Ph)))
        except Exception as e:
            status=f'FAIL:{type(e).__name__}'; guard_reject=True; piv=np.array([np.nan]); pivot_tol=np.nan
        rows.append({'case':i,'N':n,'interfaces':len(interfaces),'min_beta':float(np.min(betas)),'max_beta':float(np.max(betas)),'min_theta':float(min(t for _,t in interfaces)),'max_theta':float(max(t for _,t in interfaces)),'min_w':float(np.min(w)),'pivot_tol_recommended':float(pivot_tol),'min_exact_float_pivot':float(np.nanmin(piv)),'rtl_guard_would_reject':guard_reject,'max_abs_reconstruction_error':err,'status':status})
    write_csv(out/'stress_tests.csv',rows,list(rows[0].keys()))
    result={'cases':cases,'software_exceptions':sum(not r['status'].startswith('PASS') for r in rows),'recommended_rtl_guard_rejections':sum(r['rtl_guard_would_reject'] for r in rows),'note':'RTL guard rejection is an engineering finite-word condition, not a failure of SPD/invertibility.'}
    (out/'stress_summary.json').write_text(json.dumps(result,indent=2))
    return result,rows


def runtime_scaling(out,rng):
    rows=[]
    for n in [64,128,256,512,1024,2048,4096]:
        betas,interfaces,w,a,b,c=random_case(rng,n=n,num_interfaces=min(3,max(1,n//64)))
        P=rng.normal(0,.03,n)
        # warmup
        S=matvec_tridiag(a,b,c,P); thomas_fast(a,b,c,S)
        reps=15 if n<=512 else 8
        tv=[]; ts=[]
        for _ in range(reps):
            t=time.perf_counter(); S=matvec_tridiag(a,b,c,P); tv.append(time.perf_counter()-t)
            t=time.perf_counter(); Ph,_=thomas_fast(a,b,c,S); ts.append(time.perf_counter()-t)
        rows.append({'N':n,'repetitions':reps,'forward_matvec_median_ms':1000*float(np.median(tv)),'thomas_solve_median_ms':1000*float(np.median(ts)),'total_median_ms':1000*float(np.median(np.array(tv)+np.array(ts))),'max_float_reconstruction_error':float(np.max(np.abs(P-Ph)))})
    write_csv(out/'runtime_scaling.csv',rows,list(rows[0].keys()))
    return rows


def make_figures(out, fixed_rows, runtime_rows, e2e_rows):
    fdir=out/'figures'; fdir.mkdir(exist_ok=True)
    if plt is None: return []
    figs=[]
    # precision vs error
    fig=plt.figure(); ax=fig.add_subplot(111)
    for frac in sorted(set(r['frac_bits'] for r in fixed_rows)):
        rr=[r for r in fixed_rows if r['frac_bits']==frac and not r['overflow']]
        ax.scatter([r['condition_number_2'] for r in rr],[r['max_abs_reconstruction_error'] for r in rr],label=f'frac={frac}',s=18)
    ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel('2-norm condition number'); ax.set_ylabel('Max absolute reconstruction error'); ax.set_title('Fixed-point reconstruction error vs conditioning'); ax.legend(fontsize=8)
    p=fdir/'fixed_point_error_vs_conditioning.png'; fig.tight_layout(); fig.savefig(p,dpi=180); plt.close(fig); figs.append(p)
    # runtime
    fig=plt.figure(); ax=fig.add_subplot(111); ax.plot([r['N'] for r in runtime_rows],[r['thomas_solve_median_ms'] for r in runtime_rows],marker='o'); ax.set_xscale('log',base=2); ax.set_yscale('log'); ax.set_xlabel('N'); ax.set_ylabel('Median Thomas solve runtime (ms)'); ax.set_title('Reference Thomas-solver runtime scaling')
    p=fdir/'runtime_scaling.png'; fig.tight_layout(); fig.savefig(p,dpi=180); plt.close(fig); figs.append(p)
    # e2e error
    fig=plt.figure(); ax=fig.add_subplot(111); ax.scatter([r['condition_number_2'] for r in e2e_rows],[r['max_abs_error'] for r in e2e_rows],s=18); ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel('2-norm condition number'); ax.set_ylabel('Max absolute reconstruction error'); ax.set_title('Q16.16 randomized end-to-end reconstruction')
    p=fdir/'e2e_error_vs_conditioning.png'; fig.tight_layout(); fig.savefig(p,dpi=180); plt.close(fig); figs.append(p)
    return figs


def env_info():
    info={'python':sys.version.replace('\n',' '),'numpy':np.__version__,'platform':platform.platform(),'machine':platform.machine(),'processor':platform.processor()}
    if plt is not None:
        import matplotlib; info['matplotlib']=matplotlib.__version__
    return info


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',default='results/WP01_COMPLETE'); ap.add_argument('--seed',type=int,default=MASTER_SEED); args=ap.parse_args()
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True); rng=np.random.default_rng(args.seed)
    log=[]
    def note(s): print(s); log.append(s)
    note(f'WP01 complete campaign master_seed={args.seed}')
    start=time.time()
    m=validate_masking(out,rng); note(f"masking: pass={m['pass']} mismatches={m['mismatches']}")
    f=validate_float_solver(out,rng); note(f"float solver: pass={f['pass']} maxerr={f['max_abs_error_vs_numpy']:.3e}")
    fixed_rows,fixed_summ=fixed_point_sweep(out,rng); note('fixed-point sweep complete')
    e,e2e_rows=e2e_randomized(out,rng); note(f"e2e: pass={e['pass']} failures={e['failures']} maxerr={e['max_abs_error']:.3e}")
    st,stress_rows=stress_tests(out,rng); note(f"stress: software_exceptions={st['software_exceptions']} rtl_guard_rejections={st['recommended_rtl_guard_rejections']}")
    rt=runtime_scaling(out,rng); note('runtime scaling complete through N=4096')
    figs=make_figures(out,fixed_rows,rt,e2e_rows); note(f'figures generated={len(figs)}')
    env=env_info(); (out/'software_environment.json').write_text(json.dumps(env,indent=2))
    summary={'wp':'WP01','version':'2.0-frozen-complete','master_seed':args.seed,'authoritative_spec':'docs/MATHEMATICAL_ASSEMBLY_SPEC.md','masking':m,'float_solver':f,'randomized_e2e':e,'stress':st,'runtime_sizes':[r['N'] for r in rt],'fixed_point_configs':[{'q':s['q_bits'],'frac':s['frac_bits'],'cases':s['cases'],'overflow_cases':s['overflow_cases'],'median_max_abs_error':s['median_max_abs_error'],'max_max_abs_error':s['max_max_abs_error']} for s in fixed_summ],'elapsed_seconds':time.time()-start,'software_environment':env}
    (out/'WP01_FINAL_SUMMARY.json').write_text(json.dumps(summary,indent=2))
    # file manifest last (excluding itself)
    files=[p for p in out.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt']
    with (out/'SHA256SUMS.txt').open('w') as fh:
        for p in sorted(files): fh.write(f'{sha256(p)}  {p.relative_to(out).as_posix()}\n')
    note(f"overall acceptance pass={m['pass'] and f['pass'] and e['pass']}")
    (out/'campaign.log').write_text('\n'.join(log)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
