#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import reference_pipeline as rp


def sha256(p:Path): return hashlib.sha256(p.read_bytes()).hexdigest()

def load_source(cfg, rng, n):
    s=cfg.get('source',{})
    mode=s.get('mode','gaussian')
    if mode=='gaussian': return rng.normal(float(s.get('mean',0)),float(s.get('std',0.03)),n)
    if mode=='uniform': return rng.uniform(float(s.get('low',-0.05)),float(s.get('high',0.05)),n)
    if mode=='csv':
        x=np.loadtxt(s['path'],delimiter=',',dtype=float).reshape(-1)
        if len(x)!=n: raise ValueError(f'CSV source length {len(x)} != N={n}')
        return x
    if mode=='npy':
        x=np.load(s['path']).astype(float).reshape(-1)
        if len(x)!=n: raise ValueError(f'NPY source length {len(x)} != N={n}')
        return x
    raise ValueError(f'unsupported source mode: {mode}')

def main():
    ap=argparse.ArgumentParser(description='WP01 authoritative end-to-end reference experiment')
    ap.add_argument('--config',default='configs/default_reference.json'); ap.add_argument('--out',default='results/reference_example')
    args=ap.parse_args(); cfg=json.loads(Path(args.config).read_text()); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    seed=int(cfg['seed']); n=int(cfg['N']); rng=np.random.default_rng(seed)
    betas=cfg['region_betas']; interfaces=[(int(k),float(t)) for k,t in cfg['interfaces']]
    if cfg.get('dirichlet_endpoints',[0,0]) != [0.0,0.0] and cfg.get('dirichlet_endpoints',[0,0]) != [0,0]:
        raise ValueError('WP01/WP03 golden-vector campaign is frozen to homogeneous Dirichlet endpoints')
    A,w=rp.build_operator(n,betas,interfaces,normalized=True)
    P=load_source(cfg,rng,n); S=A@P
    fp=cfg['fixed_point']; q=int(fp['word_bits']); frac=int(fp['fractional_bits'])
    X,scale=rp.quantize_to_words(S,q,frac)
    padcfg=cfg.get('pad',{}); mode=padcfg.get('mode','synthetic_uniform_interface')
    if mode!='synthetic_uniform_interface': raise ValueError('WP01 supports injected/synthetic pad interface only; extractor is finalized in WP02')
    K=rng.integers(0,1<<q,size=n,dtype=np.uint64); Y=rp.mask(X,K,q); X2=rp.unmask(Y,K,q)
    Sq=rp.words_to_signed(X2,q,scale); a,b,c=rp.tridiagonals(A); Ph,piv=rp.thomas(a,b,c,Sq)
    abs_err=np.abs(P-Ph); rel_l2=float(np.linalg.norm(P-Ph)/(np.linalg.norm(P)+1e-30))
    np.savez_compressed(out/'reference_vectors.npz', plaintext=P, edge_weights=w, matrix_A=A, structural_float=S, structural_words=X, pad=K, ciphertext=Y, structural_recovered=Sq, plaintext_recovered=Ph, abs_error=abs_err, pivots=piv)
    np.savetxt(out/'reference_vectors.csv',np.c_[P,S,X,K,Y,Sq,Ph,abs_err],delimiter=',',header='plaintext,structural_float,structural_word,pad,ciphertext,structural_recovered,plaintext_recovered,abs_error',comments='')
    (out/'configuration.json').write_text(json.dumps(cfg,indent=2))
    summary={'seed':seed,'N':n,'interfaces':interfaces,'region_betas':betas,'q_bits':q,'frac_bits':frac,'pad_mode':mode,'pad_note':'WP01 injected pad interface; physical entropy extraction belongs to WP02/WP07/WP08.','matrix_symmetric':bool(np.allclose(A,A.T)),'matrix_spd':bool(np.min(np.linalg.eigvalsh(A))>0),'min_edge_weight':float(np.min(w)),'min_thomas_pivot':float(np.min(piv)),'condition_number_2':float(np.linalg.cond(A)),'max_abs_reconstruction_error':float(np.max(abs_err)),'relative_l2_reconstruction_error':rel_l2,'mask_unmask_exact':bool(np.array_equal(X,X2))}
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    files=[p for p in out.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt']
    with (out/'SHA256SUMS.txt').open('w') as f:
        for p in sorted(files): f.write(f'{sha256(p)}  {p.name}\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
