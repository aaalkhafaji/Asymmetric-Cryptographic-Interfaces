# WP01 v2 — Frozen conservative interface assembly

**Use `docs/MATHEMATICAL_ASSEMBLY_SPEC.md` as the authoritative convention. The earlier one-row-overwrite starter is superseded.**

# Starter Validation

Starter Python self-test executed successfully on 2026-09-03. Float solver error <2e-15; modular recovery exact. Fixed-point example intentionally shows quantization/conditioning error to be characterized by the assignee.
