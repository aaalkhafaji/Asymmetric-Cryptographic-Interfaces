# Acceptance Criteria

- 100% modular mask/unmask recovery over >= 100,000 random words.
- Tridiagonal solve matches `numpy.linalg.solve` to <= 1e-10 in float64 on test matrices.
- Fixed-point reconstruction error is reported versus word length and operator conditioning.
- >= 100 randomized end-to-end blocks pass declared tolerance.
- Golden vectors saved as CSV/NPZ with seed and SHA-256.
- Runtime scaling for N in at least {64,128,256,512,1024,2048,4096} is recorded.
