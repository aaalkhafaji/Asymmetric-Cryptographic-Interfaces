# Mathematical Assembly Specification — Frozen Convention for WP01/WP03

**Status:** AUTHORITATIVE FOR GOLDEN VECTORS AND RTL VERIFICATION  
**Version:** 2.0 (2026-09-04)

This document closes the ambiguity identified before freezing the reference model. The global operator is assembled **edge-wise** from positive transmissibilities. Do not overwrite only one matrix row at an interface.

## 1. Grid and unknowns
Use grid points `x_0,...,x_{N+1}` with `N` interior unknowns `P_1,...,P_N`. For the WP01/WP03 golden-vector campaign use homogeneous Dirichlet endpoints

`P_0 = P_{N+1} = 0`.

General nonzero fixed endpoints are a known affine RHS correction; see Section 6.

For hardware/golden-vector work use the dimensionless normalized matrix

`A = h^2 B`,

where `B=-L_{h,rho}` is the positive tridiagonal operator in the manuscript. Equivalently set `h=1` in the reference/RTL coefficients. This removes a global positive scale without changing the decoder solution when the RHS is scaled consistently.

## 2. Edge transmissibilities
For each grid edge `[x_j,x_{j+1}]`, define a positive edge weight `w_{j+1/2}`.

### No interface inside the edge
If the complete edge lies in material with permeability `beta_m>0`, set

`w_{j+1/2}=beta_m`.

### Exactly one interface inside the edge
If an interface lies at

`gamma = x_k + theta h`,  with `0 < theta < 1`, 

between left permeability `beta_minus` and right permeability `beta_plus`, define the conservative subcell transmissibility

`tau = [theta/beta_minus + (1-theta)/beta_plus]^{-1}`.

With `rho=beta_minus/beta_plus` and `d=theta+rho(1-theta)`, this is

`tau = beta_minus/d = beta_plus*rho/d`.

This is the coefficient shared by both rows adjacent to the interface edge.

For the current validation campaign, permit at most one interface per grid edge. If two physical interfaces fall in one cell, refine the mesh or explicitly use the serial-resistance generalization; do not silently apply two row overwrites.

## 3. Global matrix assembly
For each interior row `j=1,...,N`, let

`wL = w_{j-1/2}`, `wR = w_{j+1/2}`.

The normalized positive decoder matrix `A=h^2 B` is

- lower diagonal: `A[j,j-1] = -wL` (if `j>1`),
- main diagonal: `A[j,j] = wL+wR`,
- upper diagonal: `A[j,j+1] = -wR` (if `j<N`).

Thus `A` is symmetric, has positive diagonal, nonpositive off-diagonals, and is SPD for positive edge weights with fixed Dirichlet endpoints.

The physical-scale matrix is `B=A/h^2`.

## 4. Exact companion rows for an interface between x_k and x_{k+1}
Let the interface edge have `tau` as above. If the material immediately left has `beta_minus` and immediately right has `beta_plus`, then the two adjacent **B=-L** rows are

### Row k
`B[k,k-1] = -beta_minus/h^2`

`B[k,k]   = (beta_minus+tau)/h^2`

`B[k,k+1] = -tau/h^2`

### Row k+1
`B[k+1,k]   = -tau/h^2`

`B[k+1,k+1] = (tau+beta_plus)/h^2`

`B[k+1,k+2] = -beta_plus/h^2`.

If `beta_plus=1`, `rho=beta_minus/beta_plus`, and `d=theta+rho(1-theta)`, row `k` is exactly the negative of the representative manuscript `L` row:

`[-rho, rho(1+1/d), -rho/d]/h^2` for `B`.

The companion row is

`[-rho/d, 1+rho/d, -1]/h^2` for `B`.

## 5. Multiple interfaces
Apply the edge rule independently to each crossed edge. Then assemble every row from its left and right edge weights using Section 3.

Do **not** sequentially overwrite whole rows. A node can be adjacent to two modified edges; in that case its diagonal uses the sum of both modified edge weights.

For the present three-region/two-interface paper, choose the grid so `-alpha` and `+alpha` lie on distinct edges for the main WP01/WP03 campaign.

## 6. Boundary rows
For homogeneous Dirichlet endpoints the first and last rows are

`A[1,1]=w_{1/2}+w_{3/2}`, `A[1,2]=-w_{3/2}`,

`A[N,N-1]=-w_{N-1/2}`, `A[N,N]=w_{N-1/2}+w_{N+1/2}`.

The boundary-edge weights remain in the diagonal even though the endpoint unknowns are eliminated. This produces strict boundary diagonal dominance.

For nonzero fixed endpoints `P_0=g_L`, `P_{N+1}=g_R`, the interior matrix is unchanged. If `S=B_full P_full`, solve

`B P_int = S_int + (w_{1/2} g_L/h^2)e_1 + (w_{N+1/2} g_R/h^2)e_N`.

WP01/WP03 golden vectors use `g_L=g_R=0` to keep the structural map strictly linear.

## 7. Parameter ranges
### Mathematical admissibility
The theorem requires only:
- every region permeability `beta_m>0`,
- every subcell fraction `0<theta<1`,
- a connected 1-D grid,
- fixed Dirichlet endpoints.

### Nominal randomized hardware-validation range
Use these as an engineering validation domain, not as a theorem restriction:
- normalized region permeabilities: `beta_m in [0.5,2]` (log-uniform preferred),
- hence adjacent ratios are naturally no worse than about `[1/4,4]`,
- `theta in [1/16,15/16]`,
- `N in {16,32,64,128}` initially,
- 1–3 interfaces, on distinct interior edges.

### Stress range
Run separately and label as stress tests:
- `beta_m in [0.25,4]`,
- `theta` as close as `2^-10` to an edge,
- larger `N`/contrast as representable.

A stress failure does not redefine the mathematical theorem; it identifies a finite-word implementation boundary.

## 8. Thomas-pivot lower bound and hardware guard
For the normalized matrix `A`, write the Thomas modified diagonal pivots as `p_i`. Let

`w_min = min_j w_{j+1/2} > 0`.

In exact arithmetic all pivots are positive. In fact, the conservative chain gives the stronger induction bound

`p_i > w_{i+1/2} >= w_min`.

Proof sketch: `p_1=w_{1/2}+w_{3/2}>w_{3/2}`. If `p_{i-1}>w_{i-1/2}`, then

`p_i=w_{i-1/2}+w_{i+1/2}-w_{i-1/2}^2/p_{i-1} > w_{i+1/2}`.

Therefore an exact valid configuration never has a zero Thomas pivot.

For fixed-point RTL, use the exact bound as a design margin, but keep the runtime threshold explicitly an engineering guard. Recommended initial rule for normalized Q-format coefficients:

`pivot_tol = max(8*LSB, 0.5*w_min_quantized)`.

Flag a configuration as numerically invalid if a modified pivot is `<= pivot_tol`, if division cannot be represented safely, or if overflow occurs. Record the failing vector. Do not silently clamp a bad pivot and continue.

If the RTL keeps the physical `h^-2` factor inside the matrix, scale both `w_min` and `pivot_tol` by `h^-2` consistently. Prefer the normalized `A=h^2 B` implementation.

## 9. Golden-vector authority
WP01 v2 is the authoritative numerical assembly. WP03 should consume vectors generated from WP01 v2. Any older WP01 vector generated by a one-row overwrite is superseded and must not be used to freeze RTL.
