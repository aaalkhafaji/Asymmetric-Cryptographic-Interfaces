# Clarification answered before WP01/WP03 freeze

1. An interface strictly between x_k and x_{k+1} modifies the shared edge transmissibility and therefore affects **both rows k and k+1**.
2. Exact coefficients are given in `docs/MATHEMATICAL_ASSEMBLY_SPEC.md`.
3. Rows whose adjacent edges do not cross an interface use the standard local-material discretization unchanged.
4. Multiple interfaces are assembled edge-wise independently; never overwrite whole rows sequentially.
5. Dirichlet boundary edges remain in the first/last diagonal. Golden vectors use zero endpoints; nonzero endpoints are known RHS corrections.
6. Theory allows every positive permeability. Nominal hardware tests use normalized beta in [0.5,2], theta in [1/16,15/16]; stress tests extend beta to [0.25,4] and theta near cell edges.
7. Exact Thomas pivots satisfy p_i > w_min for the normalized conservative matrix. Initial fixed-point guard: max(8 LSB, 0.5*w_min_quantized); flag rather than clamp.
