# Authorship and Intellectual-Contribution Provenance

This file is included to preserve the contribution division declared by the corresponding author when this submission bundle was revised.

## Declared contribution division

- **Adnan H. Abdulwahid:** conceptualization; mathematical methodology; formal analysis; theoretical development; algorithmic formulation; and writing of the original draft.
- **Faycal Znidi, Ram C. Neupane, and Elgaddafi Elamami:** work on the empirical validation section, including empirical validation / implementation / experimental investigation and reporting associated with that section.

The revised manuscript was edited to keep the mathematical/security theory and the empirical-validation evidence conceptually separated. Hardware results originating in the empirical material were retained and were not relabeled as theoretical work.

## Important submission step

IEEE requires all listed authors to agree on authorship and the accuracy of the reported results. Before submission, **all coauthors should confirm that the wording above accurately reflects their contributions**. If any coauthor requests a more granular CRediT division within the empirical-validation section, update both this file and the manuscript contribution statement consistently.

## Revision provenance

The revision does not claim new physical measurements that were absent from the uploaded bundle. Synthetic reproducibility experiments added during revision are explicitly labeled as model-validation/reproducibility checks and are not presented as coauthor-generated physical experiments.
