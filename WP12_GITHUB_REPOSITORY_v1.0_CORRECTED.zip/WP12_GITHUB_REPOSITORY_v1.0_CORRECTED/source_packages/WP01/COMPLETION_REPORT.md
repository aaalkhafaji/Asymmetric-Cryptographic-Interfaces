# WP01 Completion Report — End-to-End Python Reference Implementation

**Frozen mathematical authority:** `docs/MATHEMATICAL_ASSEMBLY_SPEC.md`  
**Campaign master seed:** `20260904`  
**Status:** COMPLETE

## Acceptance results

| Requirement | Result | Status |
|---|---:|---|
| Modular mask/unmask over >=100,000 words | 100,000 tested; 0 mismatches | PASS |
| Thomas vs `numpy.linalg.solve` <=1e-10 | 120 cases; max error `1.6712e-11` | PASS |
| Fixed-point error vs precision/conditioning | Q16.8, Q20.10, Q24.12, Q28.14, Q32.16, Q40.24 reported | PASS |
| >=100 randomized end-to-end blocks | 120 cases; 0 failures | PASS |
| Golden vectors with seed and SHA-256 | 120 CSV + 120 NPZ vector sets with per-file hashes | PASS |
| Runtime scaling through required sizes | N=64,128,256,512,1024,2048,4096 | PASS |

## Key numerical results

- 100% exact modular recovery over 100,000 random 32-bit words.
- 120/120 randomized nominal conservative-interface matrices were symmetric, SPD, and satisfied the Thomas-pivot lower-bound check.
- Maximum float64 Thomas-vs-NumPy discrepancy: `1.6711965145077556e-11`.
- 120/120 randomized Q16.16 end-to-end blocks passed the declared propagated quantization-error bound.
- Worst Q16.16 end-to-end maximum absolute reconstruction error: `2.220963353033345e-3`.
- Worst Q16.16 end-to-end relative L2 reconstruction error: `4.934896476260788e-2`.
- 80 stress-range software cases completed with zero software exceptions and zero proposed guard rejections in the float reference model.

## Fixed-point precision finding

The experiment confirms the expected conditioning/precision tradeoff. Median maximum absolute error across the tested randomized cases was approximately:

- Q16.8: `3.066e-2`
- Q20.10: `1.294e-2`
- Q24.12: `3.380e-3`
- Q28.14: `8.999e-4`
- Q32.16: `1.573e-4`
- Q40.24: `6.212e-7`

This result should guide WP03 rather than being interpreted as a change to the mathematical theorem.

## Runtime scaling

The O(N) Thomas reference solver was timed through N=4096. Median solve time on the recorded software environment increased from about `0.085 ms` at N=64 to about `4.99 ms` at N=4096. These are **software reference timings**, not FPGA measurements.

## Reproducibility

Run the deterministic reference example:

```bash
python scripts/run_reference_experiment.py --config configs/default_reference.json --out results/reference_example
```

Run the frozen starter self-test:

```bash
python scripts/reference_pipeline.py --self-test --out results/starter_self_test
```

Run the complete WP01 campaign:

```bash
python scripts/wp01_complete_campaign.py --out results/WP01_COMPLETE
```

All machine-readable results, golden vectors, seeds, environment information, figures, logs, and SHA-256 manifests are included in the package.

## Scientific boundary

WP01 validates the independent numerical reference, quantization, injected-pad interface, exact modular masking/unmasking, and global tridiagonal recovery. The actual physical entropy source and privacy-amplification extractor are not claimed here; those belong to WP07/WP08 and WP02 respectively.
