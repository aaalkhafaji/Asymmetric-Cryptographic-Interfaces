# WP01 v2 — Frozen conservative interface assembly

**Use `docs/MATHEMATICAL_ASSEMBLY_SPEC.md` as the authoritative convention. The earlier one-row-overwrite starter is superseded.**

# Tasks

1. Validate construction of the tridiagonal interface operator against the manuscript.
2. Implement forward transform `S=B P`.
3. Quantize structural words to a declared fixed-point representation.
4. Call the extractor/masking interface from WP02.
5. Recover masked structural words exactly modulo `2^q`.
6. Solve the tridiagonal system globally for the plaintext.
7. Report reconstruction error before and after quantization.
8. Provide deterministic golden vectors for RTL packages.
9. Add MATLAB parity tests if MATLAB is used by the empirical team.

Do not replace the global solve with a local inverse stencil.
