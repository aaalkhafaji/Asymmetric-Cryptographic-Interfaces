# Handoff Rules

Return this folder with:

1. `STATUS.md` completed;
2. all source code/scripts used;
3. raw outputs and machine-readable summaries;
4. exact software/tool versions;
5. seeds for stochastic experiments;
6. checksums for data/results;
7. failed runs retained or documented (do not cherry-pick);
8. `ISSUES_FOR_CORRESPONDING_AUTHOR.md` listing anything that may change a manuscript claim;
9. no manual edits to generated tables/figures without also preserving the generating script.

Do not report a result as measured hardware evidence if it is simulated or estimated. Do not report an entropy source as NIST-certified unless a formal validation has actually occurred.
