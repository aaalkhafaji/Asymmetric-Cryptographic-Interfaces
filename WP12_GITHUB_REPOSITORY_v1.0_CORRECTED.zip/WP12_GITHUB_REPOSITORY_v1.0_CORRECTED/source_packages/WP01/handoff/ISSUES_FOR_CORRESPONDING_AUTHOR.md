# Issues for Corresponding Author

## Blocking issues

None. WP01 v2 can be frozen under `docs/MATHEMATICAL_ASSEMBLY_SPEC.md` and used as the numerical authority for WP03.

## Implementation observations for WP03

1. **Q16.16 conditioning sensitivity.** The 120 randomized nominal end-to-end blocks all pass the declared quantization-propagation bound, with zero modular failures. The worst observed absolute plaintext reconstruction error is about `2.221e-3`, and the worst observed relative L2 error is about `4.935e-2`. This is not a mathematical failure; it is finite-word error amplification by ill-conditioned valid operators.

2. **Precision sweep.** Increasing fractional precision strongly reduces reconstruction error. Across the completed sweep, the median maximum absolute error decreases from about `3.07e-2` at Q16.8 to `6.21e-7` at Q40.24. WP03 should therefore retain configurable precision and report accuracy/resource tradeoffs rather than assuming one Q-format is universally sufficient.

3. **Pivot guard.** All nominal and completed stress-model systems remained mathematically valid, and no tested case violated the exact positive-pivot property. The recommended RTL runtime guard from the frozen mathematical specification should still be implemented because the RTL divider/arithmetic will introduce finite-word effects not present in the float64 WP01 solve.

4. **Extractor boundary.** WP01 intentionally injects a synthetic uniform pad only to validate the pad interface and exact modular masking/unmasking. It does not make a physical-entropy or extractor claim. WP02 should replace this pad provider after WP07/WP08 establish defensible extractor parameters.
