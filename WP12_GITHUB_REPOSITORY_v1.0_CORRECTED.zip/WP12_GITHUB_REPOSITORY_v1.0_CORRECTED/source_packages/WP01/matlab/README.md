# MATLAB parity task

If MATLAB is used, implement the same functions and golden-vector contract as `scripts/reference_pipeline.py`. Compare every MATLAB output to the supplied CSV within declared floating-point tolerance.
