# WP10 Scientific Notes
- Interface-unaware stencil is an ablation baseline, not a competing cryptosystem.
- Precision sweep is software-only unless lower-precision RTL is separately synthesized and verified.
- Masking ablation demonstrates functional transparency only, not physical entropy quality or cryptographic strength.
- External Ascon comparison is intentionally deferred unless implemented or sourced under a matched FPGA/tool methodology.
- WP07/WP08 remain out of scope.
