# WP10 Status
- Package: READY
- Interface-aware vs ordinary stencil smoke: PENDING
- Full interface ablation: PENDING
- Precision sensitivity: PENDING
- Masking transparency: PENDING
- Frozen hardware baseline table: PREPARED
- WP10 frozen: NO
