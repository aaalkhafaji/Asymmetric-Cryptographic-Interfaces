# WP10 — Ablations / Baselines READY

This WP is mainly computational; no Vivado run is required for the first ablation.

## FIRST STEP ONLY
Extract to:
`C:\CWP10\WP10_Ablations_and_Baselines_READY`

Open Windows Command Prompt:
```
cd C:\CWP10\WP10_Ablations_and_Baselines_READY
python python\run_interface_ablation.py --cases 40 --out results\interface_smoke
```

Expected final line:
`WP10_INTERFACE_ABLATION_PASS`

Send the printed summary before running the full campaign.
