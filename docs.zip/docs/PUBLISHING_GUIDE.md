# GitHub + Zenodo Publishing Guide

## 1. Resolve the license first
The source WP12 archive did not contain an explicit license. Before making either destination public, the authors should agree on the license(s) for code/RTL and for data/documentation. See `LICENSE_SELECTION_REQUIRED.md`.

## 2. GitHub
Use the prepared `WP12_GITHUB_REPOSITORY_v1.0_CORRECTED.zip` as the repository contents. It intentionally excludes the bulky raw `archival_evidence/` tree while retaining source packages, RTL/reference material, consolidated data, figures, corrected outputs, manifests, and a compact mirror of the headline WP06 Vivado reports.

Recommended release tag: `v1.0.0`.

Do not commit the 225-MB full Zenodo ZIP into normal Git history. The GitHub repository records its SHA-256 in `ZENODO_FULL_ARCHIVE_SHA256.txt`.

## 3. Zenodo
Upload `WP12_ZENODO_FULL_v1.0_CORRECTED.zip` as the complete reproducibility artifact. The archive contains the full WP05/WP09 raw XSim evidence and WP06 archival evidence in addition to all browseable repository material.

Use `.zenodo.json` as the metadata starting point. Zenodo will mint a DOI after deposition/publication.

## 4. After Zenodo mints the DOI
Update the GitHub README and `CITATION.cff` with the DOI, then make a small metadata-only GitHub commit/tag if desired. Do not rebuild or silently alter the already deposited Zenodo ZIP; version any later scientific correction explicitly.

## 5. Integrity
Before upload, compare the ZIP against its companion `.sha256` file. After download from the public repository, users can run:

```bash
python scripts/verify_public_release.py
```

The expected final marker is:

```text
PUBLIC_RELEASE_VERIFY_PASS
```
