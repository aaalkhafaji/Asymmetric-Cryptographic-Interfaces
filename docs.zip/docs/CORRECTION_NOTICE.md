# Correction Notice — WP10 Q16.16 Precision Ablation

## What was corrected
The immutable source archive `WP12_FINAL_FROZEN.zip` contains a transcription error in derived WP10/WP11 summaries for the **Q16.16 mean relative L2 error**. The source package reported approximately `9.50e-4` in some derived files.

The exact frozen script was re-run with the archived command parameters:

```bash
python python/run_precision_ablation.py --cases 500 --seed 20260910
```

The reproducible Q16.16 result is:

- cases: 500
- mean relative L2 error: **0.00905040766776842552** (about **9.05e-3**)
- maximum relative L2 error: **0.05207473149848442**

Q24.8 and Q20.12 reproduce unchanged.

## Preservation rule
The original frozen packages in `frozen_packages/` are retained **byte-for-byte** and are not rewritten. Public-facing derived outputs in `data/`, `figures/`, `latex/`, and `source_packages/WP11/` have been corrected. A corrected WP10 package is supplied under `corrected_packages/`.

## Provenance
- Original WP12 SHA-256: `21cf97ae3ef8db104c9ab18ec37e0984fca506a72d75f241bcf5aff1fe66716b`
- Correction-overlay SHA-256: `a657b1814752be37f8fa898667151ee56fdb498a4c46e549f00c7ed7fce373ca`
- Verified rerun output: `corrections/WP10_precision_q16_16/WP10_RERUN_OUTPUT_verified.json`
