# Release Notes — v1.0.0

This is the first corrected public reproducibility release derived from the immutable WP12 final frozen archive.

### Verified provenance
- Original WP12 archive: `21cf97ae3ef8db104c9ab18ec37e0984fca506a72d75f241bcf5aff1fe66716b`
- Original archive ZIP integrity: verified before release construction
- Precision correction overlay: `a657b1814752be37f8fa898667151ee56fdb498a4c46e549f00c7ed7fce373ca`

### Public correction
The Q16.16 500-case mean relative L2 error is corrected to `0.00905040766776842552` (approximately `9.05e-3`). See `docs/CORRECTION_NOTICE.md`.

### Evidence scope
The complete Zenodo/full artifact includes raw XSim and Vivado evidence. The GitHub bundle mirrors key reports but omits the ~310 MB expanded `archival_evidence/` directory to keep normal repository use practical.
