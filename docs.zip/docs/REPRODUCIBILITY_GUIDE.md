# Reproducibility Guide

## Portable software reproduction
Requires Python 3 with `numpy` and `matplotlib`.

```bash
python -m pip install -r requirements.txt
python scripts/reproduce_all.py
python scripts/verify_public_release.py
```

Expected terminal markers include:

```text
REPRODUCE_TABLES_PASS
REPRODUCE_FIGURES_PASS
WP12_VALIDATION_PASS
WP12_REPRODUCE_ALL_PASS
PUBLIC_RELEASE_VERIFY_PASS
```

## Corrected precision experiment
The exact corrected Q16.16 result can be independently regenerated from the frozen WP10 script preserved in `frozen_packages/WP10_FINAL_FROZEN.zip`; see `docs/CORRECTION_NOTICE.md`.

## FPGA evidence
The complete archive includes the raw 100-group WP05 XSim campaign, the ten WP09 robustness XSim directories, and the archived WP06 post-route reports/checkpoint for the 130.005-MHz N=64 benchmark. A compact set of headline WP06 reports is mirrored under `evidence/key_reports/WP06_N64_130MHz/` for GitHub browsing.

The 130.005-MHz value is an internal routed-core benchmark operating point under the archived benchmark constraints; it is not a board-I/O timing certification. Reported power is a Vivado post-implementation estimate rather than measured board power.

## Physical entropy scope
WP07/WP08 physical sensor acquisition/source characterization were not performed because suitable raw sensor entropy data were unavailable. The downstream digital transceiver is experimentally validated; source-specific entropy quality remains a conditional assumption of the security theorem.
