# Repository Map

| Path | Purpose | GitHub | Full Zenodo artifact |
|---|---|---:|---:|
| `data/` | Consolidated tables/JSON used by reproduction scripts | yes | yes |
| `figures/` | Publication-ready generated figures | yes | yes |
| `latex/` | LaTeX-ready tables/sections and preview material | yes | yes |
| `scripts/` | Table/figure/release verification scripts | yes | yes |
| `source_packages/` | Exploded WP01–WP06, WP09–WP11 sources used by the campaign | yes | yes |
| `frozen_packages/` | Original immutable work-package ZIPs | yes | yes |
| `corrected_packages/` | Corrected public WP10 derivative | yes | yes |
| `corrections/` | Correction overlay, rerun logs, and provenance | yes | yes |
| `evidence/key_reports/` | Small headline Vivado reports mirrored from the raw archive | yes | yes |
| `archival_evidence/` | Full WP05/WP09 raw XSim archives and WP06 raw implementation evidence | no (normally) | yes |
| `manifest/` | Release hashes and inventory | yes | yes |
| `provenance/` | Original WP12 and overlay hashes/manifests | yes | yes |

The GitHub bundle intentionally omits the bulky `archival_evidence/` tree. The complete frozen evidence is carried by the Zenodo/full archive and identified by its release SHA-256.
